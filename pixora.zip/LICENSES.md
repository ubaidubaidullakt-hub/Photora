# Licenses & Attributions

PIXORA is licensed under the Apache License, Version 2.0.

```
Copyright 2026 PIXORA Contributors

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
```

## Third-Party Libraries & Licenses

- **React & React DOM**: MIT License (Copyright Meta Platforms, Inc.)
- **Lucide React**: ISC License (Copyright Lucide Contributors)
- **JSZip**: MIT License / Dual GPLv3 (Copyright Stuart Knightley, David Duponchel, Franz Buchinger, António Afonso)
- **Tailwind CSS**: MIT License (Copyright Tailwind Labs, Inc.)
- **Motion**: MIT License (Copyright Motion Software)
- **TypeScript**: Apache License 2.0 (Copyright Microsoft Corporation)
- **Vite**: MIT License (Copyright Yuxi (Evan) You & Vite Contributors)
