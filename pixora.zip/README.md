# PIXORA — Complete Professional Photo Editing Platform

PIXORA is a complete, browser-based photo and graphics editing application engineered with a familiar Adobe Photoshop workflow, layer architecture, masks, image adjustments, procedural filters, vector tools, touch gestures, timeline animation, and non-AI conventional image-processing math.

---

## 1. Architecture Overview

PIXORA is organized into 22 decoupled core systems:
1. **Application Shell (`src/App.tsx`)**: Coordinates state, responsive layouts, active tool, panel docking, and global hotkeys.
2. **Canvas Rendering Engine (`src/engine/canvasRenderer.ts`)**: High-performance layer compositing, 16 Photoshop blend modes, clipping masks, layer masks with density/feathering, layer styles (Drop Shadow, Stroke, Color Overlay), marching ants selection contours, and transform bounding box.
3. **Image Processing Engine (`src/engine/imageProcessing.ts`)**: 100% offline, mathematical pixel manipulation algorithms without AI. Includes separable Gaussian blur, motion blur, radial blur, unsharp mask, high pass, median, twirl, ripple, mosaic, emboss, Sobel edge detection, Perlin/value-noise procedural clouds, lens flare, levels, curves LUT, HSL, vibrance, color balance, and scanline flood fill.
4. **Selection Engine (`src/engine/selectionEngine.ts`)**: Rectangular marquee, elliptical marquee, freehand & polygonal lasso, magic wand flood selection, selection inversion, expansion, contraction, feathering, and coordinate point containment.
5. **Layer System (`src/components/panels/LayersPanel.tsx`)**: Multi-type layer stack (Pixel, Text, Shape, Adjustment, Group), layer visibility, locking, opacity & fill opacity, 16 blend modes, mask editing mode, duplicate, merge down, and flatten.
6. **Properties System (`src/components/panels/PropertiesPanel.tsx`)**: Live transform readouts (X, Y, Width, Height) and mask feather/density controls.
7. **History & Time Travel Engine (`src/engine/historyEngine.ts`)**: Non-destructive snapshot chains, jump-to-state undo/redo, and memory-capped state pruning.
8. **Import & Export Engine (`src/engine/importExport.ts`)**: PNG (lossless with alpha), JPEG (quality control), WebP, BMP, SVG, layered `.pixora` JSON project files, and downloadable full-project ZIP bundle generation.
9. **Timeline Engine (`src/components/panels/TimelinePanel.tsx`)**: Frame-based animation with frame delay, loop settings, playback controls, and frame addition/deletion.
10. **Automated Test Suite (`src/tests/testSuite.ts` & `src/components/dialogs/AutomatedTestModal.tsx`)**: Automated verification test matrix covering startup, layers, compositing, blend modes, masks, filters, adjustments, selections, flood fill, history, and non-AI compliance.

---

## 2. Getting Started & Installation

### Prerequisites
- Node.js 18+ or 20+
- npm 9+

### Development Server
```bash
npm install
npm run dev
```
Open `http://localhost:3000` in your web browser.

### Production Build
```bash
npm run build
npm run preview
```

### Type Checking & Linting
```bash
npm run lint
```

---

## 3. Tool Reference & Keyboard Shortcuts

| Tool | Shortcut | Description |
|---|---|---|
| **Move Tool** | `V` | Reposition layers and selections across the canvas |
| **Rectangular Marquee** | `M` | Select rectangular regions with optional feathering |
| **Elliptical Marquee** | `M` | Select circular or elliptical regions |
| **Lasso Tool** | `L` | Freehand boundary selection |
| **Magic Wand** | `W` | Contiguous or global color tolerance selection |
| **Crop Tool** | `C` | Reframe canvas with presets (1:1, 16:9, 4:3, 9:16) |
| **Eyedropper** | `I` | Sample RGB color from anywhere on canvas |
| **Spot Healing Brush** | `J` | Local neighborhood pixel smoothing & blemish removal |
| **Clone Stamp** | `S` | Alt+Click to define source point, paint to duplicate pixels |
| **Brush Tool** | `B` | Continuous antialiased painting with size, hardness & flow |
| **Eraser Tool** | `E` | Alpha cutout on pixel layers or white/black on masks |
| **Paint Bucket** | `G` | Fast scanline flood fill with tolerance settings |
| **Gradient Tool** | `G` | Linear, radial, angle, reflected, and diamond color ramps |
| **Blur / Sharpen / Smudge** | `R` | Localized convolution and smearing brushes |
| **Dodge / Burn / Sponge** | `O` | Exposure lightening, darkening, and saturation adjustment |
| **Horizontal Type** | `T` | Vector text with fonts, sizes, alignment, and formatting |
| **Vector Shapes** | `U` | Rectangles, rounded rects, ellipses, polygons, lines |
| **Hand Tool** | `H` | Pan document viewport (or hold Spacebar) |
| **Zoom Tool** | `Z` | Click to zoom in, Alt+Click to zoom out, or Mouse Wheel |
| **Swap Colors** | `X` | Swap foreground and background colors |
| **Default Colors** | `D` | Reset foreground to black and background to white |
| **Undo / Redo** | `Ctrl+Z` / `Ctrl+Shift+Z` | Step backward and forward through history stack |
| **Select All / Deselect** | `Ctrl+A` / `Ctrl+D` | Select full document or clear active selection |
| **Inverse Selection** | `Ctrl+Shift+I` | Invert active selection mask |
| **Duplicate Layer** | `Ctrl+J` | Clone active layer |
| **Merge Down** | `Ctrl+E` | Merge active layer into underlying layer |
| **Fit Screen / 100%** | `Ctrl+0` / `Ctrl+1` | Reset zoom to viewport or 1:1 pixel scale |
| **Rulers Toggle** | `Ctrl+R` | Show or hide horizontal and vertical pixel rulers |

---

## 4. File-Format Compatibility

- **PNG**: Full 32-bit RGBA lossless support with alpha transparency.
- **JPEG**: 24-bit RGB with configurable compression quality (1% to 100%).
- **WebP**: Modern web image format with lossless/lossy compression.
- **BMP**: Standard 24-bit uncompressed Windows DIB bitmap.
- **SVG**: Vector wrapper with embedded high-resolution raster graphic.
- **PIXORA Project (`.pixora`)**: Layered JSON format saving all layers, masks, effects, guides, blend modes, and document metadata.
- **Project ZIP Archive**: One-click complete project bundle containing source code, documentation, and tests.

---

## 5. Non-AI Compliance Verification

PIXORA strictly complies with the zero-AI directive:
- No external AI APIs, generative fill, AI models, or neural networks.
- All 15+ filters utilize conventional mathematical convolution kernels, lookup tables (LUTs), coordinate transform reverse mapping, and multi-octave value noise.
- Selection tools use geometric math and BFS scanline flood fill algorithms.
- Retouching tools execute direct pixel buffer interpolation and Poisson-like edge averaging.

---

## 6. Known Limitations

- CMYK color separation preview is mapped through standard sRGB canvas color spaces (standard across browser HTML5 Canvas 2D contexts).
- Hardware-accelerated WebGL shader pipeline falls back to multi-core CPU canvas image data buffers for universal mobile/tablet browser compatibility.
