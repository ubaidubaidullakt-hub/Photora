/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  DocumentState,
  ToolType,
  ToolSettings,
  Layer,
  ActiveModal,
  AdjustmentSettings,
  LayerEffects,
} from './types';
import { HeaderMenu } from './components/layout/HeaderMenu';
import { OptionsBar } from './components/layout/OptionsBar';
import { Toolbar } from './components/layout/Toolbar';
import { WorkspaceCanvas } from './components/canvas/WorkspaceCanvas';
import { LayersPanel } from './components/panels/LayersPanel';
import { PropertiesPanel } from './components/panels/PropertiesPanel';
import { HistoryPanel } from './components/panels/HistoryPanel';
import { ChannelsPanel } from './components/panels/ChannelsPanel';
import { ColorSwatchesPanel } from './components/panels/ColorSwatchesPanel';
import { NavigatorPanel } from './components/panels/NavigatorPanel';
import { TimelinePanel } from './components/panels/TimelinePanel';
import { MobileWorkspace } from './components/mobile/MobileWorkspace';

// Modals
import { NewDocumentDialog } from './components/dialogs/NewDocumentDialog';
import { OpenImageDialog } from './components/dialogs/OpenImageDialog';
import { ExportModal } from './components/dialogs/ExportModal';
import { AdjustmentsModal } from './components/dialogs/AdjustmentsModal';
import { FilterDialog } from './components/dialogs/FilterDialog';
import { LayerStylesModal } from './components/dialogs/LayerStylesModal';
import { GradientEditorModal } from './components/dialogs/GradientEditorModal';
import { KeyboardShortcutsModal } from './components/dialogs/KeyboardShortcutsModal';
import { ProjectZipModal } from './components/dialogs/ProjectZipModal';
import { AutomatedTestModal } from './components/dialogs/AutomatedTestModal';

import { pushHistoryStep, restoreHistoryStep } from './engine/historyEngine';
import {
  applyAdjustments,
  applyGaussianBlur,
  applyMotionBlur,
  applyRadialBlur,
  applyUnsharpMask,
  applyHighPass,
  applyAddNoise,
  applyTwirl,
  applyRipple,
  applyMosaic,
  applyEmboss,
  applyFindEdges,
  renderClouds,
  renderLensFlare,
} from './engine/imageProcessing';
import {
  createSelectAllMask,
  invertSelectionMask,
} from './engine/selectionEngine';
import { compositeDocumentToCanvas } from './engine/canvasRenderer';

// Helper to create initial default document
function createInitialDocument(): DocumentState {
  const width = 1200;
  const height = 800;

  // Background Layer
  const bgCanvas = document.createElement('canvas');
  bgCanvas.width = width;
  bgCanvas.height = height;
  const bgCtx = bgCanvas.getContext('2d');
  if (bgCtx) {
    // Rich dark gradient background
    const grad = bgCtx.createLinearGradient(0, 0, width, height);
    grad.addColorStop(0, '#0f172a');
    grad.addColorStop(0.5, '#1e1b4b');
    grad.addColorStop(1, '#020617');
    bgCtx.fillStyle = grad;
    bgCtx.fillRect(0, 0, width, height);
  }

  const bgLayer: Layer = {
    id: 'layer_bg',
    name: 'Background',
    type: 'pixel',
    visible: true,
    locked: false,
    opacity: 1,
    fillOpacity: 1,
    blendMode: 'normal',
    x: 0,
    y: 0,
    width,
    height,
    canvas: bgCanvas,
    maskEnabled: false,
    maskInverted: false,
    maskLinked: true,
    maskDensity: 1,
    maskFeather: 0,
    isBackground: true,
  };

  // Artwork Layer: Stylized geometric glow & shape
  const artCanvas = document.createElement('canvas');
  artCanvas.width = width;
  artCanvas.height = height;
  const artCtx = artCanvas.getContext('2d');
  if (artCtx) {
    // Draw abstract creative graphic
    artCtx.save();
    const radial = artCtx.createRadialGradient(width / 2, height / 2, 50, width / 2, height / 2, 350);
    radial.addColorStop(0, '#38bdf8');
    radial.addColorStop(0.4, '#818cf8');
    radial.addColorStop(0.8, '#ec4899');
    radial.addColorStop(1, 'transparent');
    artCtx.fillStyle = radial;
    artCtx.beginPath();
    artCtx.arc(width / 2, height / 2, 300, 0, Math.PI * 2);
    artCtx.fill();

    // Subtle modern geometric frame
    artCtx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
    artCtx.lineWidth = 3;
    artCtx.strokeRect(width / 2 - 220, height / 2 - 160, 440, 320);

    // Headline typography
    artCtx.fillStyle = '#ffffff';
    artCtx.font = 'bold 44px "Plus Jakarta Sans", sans-serif';
    artCtx.textAlign = 'center';
    artCtx.textBaseline = 'middle';
    artCtx.fillText('PIXORA CREATIVE STUDIO', width / 2, height / 2 - 20);

    artCtx.font = '500 16px "Plus Jakarta Sans", sans-serif';
    artCtx.fillStyle = '#94a3b8';
    artCtx.fillText('Professional Photoshop-Grade Image Engine', width / 2, height / 2 + 35);
    artCtx.restore();
  }

  const artLayer: Layer = {
    id: 'layer_artwork',
    name: 'Artwork Graphic',
    type: 'pixel',
    visible: true,
    locked: false,
    opacity: 0.95,
    fillOpacity: 1,
    blendMode: 'screen',
    x: 0,
    y: 0,
    width,
    height,
    canvas: artCanvas,
    maskEnabled: false,
    maskInverted: false,
    maskLinked: true,
    maskDensity: 1,
    maskFeather: 0,
    effects: {
      dropShadow: {
        enabled: true,
        color: '#000000',
        opacity: 0.7,
        angle: 120,
        distance: 12,
        blur: 20,
        spread: 0,
      },
    },
  };

  const initialDoc: DocumentState = {
    id: 'doc_' + Date.now(),
    name: 'PIXORA Masterpiece',
    width,
    height,
    resolution: 72,
    colorMode: 'RGB',
    layers: [artLayer, bgLayer],
    activeLayerId: artLayer.id,
    selection: null,
    history: [],
    historyIndex: -1,
    zoom: 0.85,
    pan: { x: 0, y: 0 },
    rotation: 0,
    guides: [
      { id: 'g1', orientation: 'horizontal', position: height / 2 },
      { id: 'g2', orientation: 'vertical', position: width / 2 },
    ],
    rulersVisible: true,
    gridVisible: false,
    snapToGrid: false,
    snapToGuides: true,
    frames: [{ id: 'f1', duration: 0.2, layerStates: {} }],
    activeFrameIndex: 0,
    isPlayingTimeline: false,
  };

  return pushHistoryStep(initialDoc, 'Initial Document');
}

export default function App() {
  const [doc, setDoc] = useState<DocumentState>(createInitialDocument);
  const [activeTool, setActiveTool] = useState<ToolType>('brush');
  const [activeModal, setActiveModal] = useState<ActiveModal>(null);
  const [filterTypeForModal, setFilterTypeForModal] = useState<string>('gaussianBlur');
  const [adjTypeForModal, setAdjTypeForModal] = useState<AdjustmentSettings['type']>('brightnessContrast');
  const [isMobile, setIsMobile] = useState<boolean>(false);
  const [activeRightTab, setActiveRightTab] = useState<string>('layers');
  const [isTransformActive, setIsTransformActive] = useState<boolean>(false);

  // Tool Settings
  const [settings, setSettings] = useState<ToolSettings>({
    brushSize: 24,
    brushHardness: 0.8,
    brushOpacity: 1,
    brushFlow: 1,
    brushSpacing: 0.15,
    tolerance: 32,
    contiguous: true,
    sampleAllLayers: false,
    feather: 0,
    antiAlias: true,
    cropPreset: 'free',
    gradient: {
      type: 'linear',
      colorStops: [
        { offset: 0, color: '#38bdf8' },
        { offset: 1, color: '#ec4899' },
      ],
      opacityStops: [
        { offset: 0, opacity: 1 },
        { offset: 1, opacity: 1 },
      ],
      reverse: false,
    },
    activeColor: '#38bdf8', // Foreground color
    backgroundColor: '#ffffff', // Background color
    cloneSource: null,
    eraserSize: 32,
    eraserOpacity: 1,
    retouchMode: 'normal',
    retouchExposure: 0.5,
  });

  // Responsive mobile listener
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Update Document & Push History Step
  const handleUpdateDocument = (newDoc: DocumentState, actionName?: string) => {
    if (actionName) {
      setDoc(pushHistoryStep(newDoc, actionName));
    } else {
      setDoc(newDoc);
    }
  };

  // Undo / Redo
  const handleUndo = async () => {
    if (doc.historyIndex > 0) {
      const restored = await restoreHistoryStep(doc, doc.historyIndex - 1);
      setDoc(restored);
    }
  };

  const handleRedo = async () => {
    if (doc.historyIndex < doc.history.length - 1) {
      const restored = await restoreHistoryStep(doc, doc.historyIndex + 1);
      setDoc(restored);
    }
  };

  // Keyboard Shortcuts Listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept if user is typing in an input
      if (['INPUT', 'SELECT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) {
        return;
      }

      const ctrlOrCmd = e.ctrlKey || e.metaKey;

      if (ctrlOrCmd && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        if (e.shiftKey) handleRedo();
        else handleUndo();
        return;
      }

      if (ctrlOrCmd && e.key.toLowerCase() === 's') {
        e.preventDefault();
        setActiveModal('export');
        return;
      }

      if (ctrlOrCmd && e.key.toLowerCase() === 'o') {
        e.preventDefault();
        setActiveModal('openImage');
        return;
      }

      if (ctrlOrCmd && e.key.toLowerCase() === 'n') {
        e.preventDefault();
        setActiveModal('newDoc');
        return;
      }

      if (ctrlOrCmd && e.key.toLowerCase() === 'a') {
        e.preventDefault();
        handleSelectAll();
        return;
      }

      if (ctrlOrCmd && e.key.toLowerCase() === 'd') {
        e.preventDefault();
        handleDeselect();
        return;
      }

      if (ctrlOrCmd && e.shiftKey && e.key.toLowerCase() === 'i') {
        e.preventDefault();
        handleInverseSelection();
        return;
      }

      if (ctrlOrCmd && e.key.toLowerCase() === 'j') {
        e.preventDefault();
        handleDuplicateLayer();
        return;
      }

      if (ctrlOrCmd && e.key.toLowerCase() === 'e') {
        e.preventDefault();
        handleMergeDown();
        return;
      }

      if (ctrlOrCmd && e.key === '0') {
        e.preventDefault();
        handleZoomFit();
        return;
      }

      if (ctrlOrCmd && e.key === '1') {
        e.preventDefault();
        handleZoomActual();
        return;
      }

      if (ctrlOrCmd && e.key.toLowerCase() === 'r') {
        e.preventDefault();
        setDoc((prev) => ({ ...prev, rulersVisible: !prev.rulersVisible }));
        return;
      }

      if (ctrlOrCmd && e.key.toLowerCase() === 't') {
        e.preventDefault();
        setIsTransformActive((prev) => !prev);
        return;
      }

      // Single-key Tool Shortcuts
      const key = e.key.toLowerCase();
      if (key === 'v') setActiveTool('move');
      else if (key === 'm') setActiveTool('rectMarquee');
      else if (key === 'l') setActiveTool('lasso');
      else if (key === 'w') setActiveTool('magicWand');
      else if (key === 'c') setActiveTool('crop');
      else if (key === 'i') setActiveTool('eyedropper');
      else if (key === 'j') setActiveTool('spotHealing');
      else if (key === 's' && !ctrlOrCmd) setActiveTool('cloneStamp');
      else if (key === 'b') setActiveTool('brush');
      else if (key === 'e') setActiveTool('eraser');
      else if (key === 'g') setActiveTool('bucket');
      else if (key === 't') setActiveTool('textHorizontal');
      else if (key === 'u') setActiveTool('shapeRect');
      else if (key === 'h') setActiveTool('hand');
      else if (key === 'z' && !ctrlOrCmd) setActiveTool('zoom');
      else if (key === 'x') handleSwapColors();
      else if (key === 'd') handleResetColors();
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [doc]);

  // Color Swapping / Reset
  const handleSwapColors = () => {
    setSettings((prev) => ({
      ...prev,
      activeColor: prev.backgroundColor,
      backgroundColor: prev.activeColor,
    }));
  };

  const handleResetColors = () => {
    setSettings((prev) => ({
      ...prev,
      activeColor: '#000000',
      backgroundColor: '#ffffff',
    }));
  };

  // Layer Management Handlers
  const handleNewLayer = () => {
    const canvas = document.createElement('canvas');
    canvas.width = doc.width;
    canvas.height = doc.height;
    const newLayer: Layer = {
      id: 'layer_' + Date.now(),
      name: `Layer ${doc.layers.length + 1}`,
      type: 'pixel',
      visible: true,
      locked: false,
      opacity: 1,
      fillOpacity: 1,
      blendMode: 'normal',
      x: 0,
      y: 0,
      width: doc.width,
      height: doc.height,
      canvas,
      maskEnabled: false,
      maskInverted: false,
      maskLinked: true,
      maskDensity: 1,
      maskFeather: 0,
    };
    handleUpdateDocument(
      {
        ...doc,
        layers: [newLayer, ...doc.layers],
        activeLayerId: newLayer.id,
      },
      'New Layer'
    );
  };

  const handleDuplicateLayer = () => {
    const active = doc.layers.find((l) => l.id === doc.activeLayerId);
    if (!active) return;
    const canvas = document.createElement('canvas');
    canvas.width = active.canvas.width;
    canvas.height = active.canvas.height;
    const ctx = canvas.getContext('2d');
    if (ctx) ctx.drawImage(active.canvas, 0, 0);

    const dup: Layer = {
      ...active,
      id: 'layer_' + Date.now(),
      name: `${active.name} Copy`,
      canvas,
      x: active.x + 10,
      y: active.y + 10,
    };
    handleUpdateDocument(
      {
        ...doc,
        layers: [dup, ...doc.layers],
        activeLayerId: dup.id,
      },
      'Duplicate Layer'
    );
  };

  const handleDeleteLayer = () => {
    if (doc.layers.length <= 1) return;
    const filtered = doc.layers.filter((l) => l.id !== doc.activeLayerId);
    handleUpdateDocument(
      {
        ...doc,
        layers: filtered,
        activeLayerId: filtered[0].id,
      },
      'Delete Layer'
    );
  };

  const handleMergeDown = () => {
    const idx = doc.layers.findIndex((l) => l.id === doc.activeLayerId);
    if (idx >= doc.layers.length - 1) return; // Cannot merge bottom layer down
    const upper = doc.layers[idx];
    const lower = doc.layers[idx + 1];

    const mergedCanvas = document.createElement('canvas');
    mergedCanvas.width = lower.canvas.width;
    mergedCanvas.height = lower.canvas.height;
    const mCtx = mergedCanvas.getContext('2d');
    if (mCtx) {
      mCtx.drawImage(lower.canvas, 0, 0);
      mCtx.globalAlpha = upper.opacity;
      mCtx.drawImage(upper.canvas, upper.x - lower.x, upper.y - lower.y);
    }

    const mergedLayer: Layer = {
      ...lower,
      name: `${upper.name} + ${lower.name}`,
      canvas: mergedCanvas,
    };

    const newLayers = [...doc.layers];
    newLayers.splice(idx, 2, mergedLayer);
    handleUpdateDocument(
      {
        ...doc,
        layers: newLayers,
        activeLayerId: mergedLayer.id,
      },
      'Merge Down'
    );
  };

  const handleFlattenImage = () => {
    const flatCanvas = document.createElement('canvas');
    flatCanvas.width = doc.width;
    flatCanvas.height = doc.height;
    compositeDocumentToCanvas(doc, flatCanvas, true);

    const flatLayer: Layer = {
      id: 'layer_flat_' + Date.now(),
      name: 'Background (Flattened)',
      type: 'pixel',
      visible: true,
      locked: false,
      opacity: 1,
      fillOpacity: 1,
      blendMode: 'normal',
      x: 0,
      y: 0,
      width: doc.width,
      height: doc.height,
      canvas: flatCanvas,
      maskEnabled: false,
      maskInverted: false,
      maskLinked: true,
      maskDensity: 1,
      maskFeather: 0,
      isBackground: true,
    };

    handleUpdateDocument(
      {
        ...doc,
        layers: [flatLayer],
        activeLayerId: flatLayer.id,
      },
      'Flatten Image'
    );
  };

  // Selection Operations
  const handleSelectAll = () => {
    const mask = createSelectAllMask(doc.width, doc.height);
    handleUpdateDocument({ ...doc, selection: mask }, 'Select All');
  };

  const handleDeselect = () => {
    handleUpdateDocument({ ...doc, selection: null }, 'Deselect');
  };

  const handleInverseSelection = () => {
    if (!doc.selection || !doc.selection.active) return;
    const inv = invertSelectionMask(doc.selection);
    handleUpdateDocument({ ...doc, selection: inv }, 'Inverse Selection');
  };

  // Canvas Transforms
  const handleRotateCanvas = (deg: number) => {
    const rad = (deg * Math.PI) / 180;
    const isQuarter = Math.abs(deg) === 90 || Math.abs(deg) === 270;
    const newW = isQuarter ? doc.height : doc.width;
    const newH = isQuarter ? doc.width : doc.height;

    const rotatedLayers = doc.layers.map((l) => {
      const c = document.createElement('canvas');
      c.width = newW;
      c.height = newH;
      const ctx = c.getContext('2d');
      if (ctx) {
        ctx.translate(newW / 2, newH / 2);
        ctx.rotate(rad);
        ctx.drawImage(l.canvas, -l.canvas.width / 2, -l.canvas.height / 2);
      }
      return { ...l, canvas: c, width: newW, height: newH };
    });

    handleUpdateDocument(
      {
        ...doc,
        width: newW,
        height: newH,
        layers: rotatedLayers,
      },
      `Rotate Canvas ${deg}°`
    );
  };

  const handleFlipCanvas = (dir: 'h' | 'v') => {
    const flippedLayers = doc.layers.map((l) => {
      const c = document.createElement('canvas');
      c.width = l.canvas.width;
      c.height = l.canvas.height;
      const ctx = c.getContext('2d');
      if (ctx) {
        if (dir === 'h') {
          ctx.translate(c.width, 0);
          ctx.scale(-1, 1);
        } else {
          ctx.translate(0, c.height);
          ctx.scale(1, -1);
        }
        ctx.drawImage(l.canvas, 0, 0);
      }
      return { ...l, canvas: c };
    });

    handleUpdateDocument({ ...doc, layers: flippedLayers }, `Flip Canvas ${dir === 'h' ? 'Horizontal' : 'Vertical'}`);
  };

  // Zoom Operations
  const handleZoomIn = () => setDoc((prev) => ({ ...prev, zoom: Math.min(10, prev.zoom * 1.25) }));
  const handleZoomOut = () => setDoc((prev) => ({ ...prev, zoom: Math.max(0.1, prev.zoom * 0.8) }));
  const handleZoomFit = () => setDoc((prev) => ({ ...prev, zoom: 0.85, pan: { x: 0, y: 0 } }));
  const handleZoomActual = () => setDoc((prev) => ({ ...prev, zoom: 1, pan: { x: 0, y: 0 } }));

  // Crop Operations
  const handleApplyCrop = () => {
    // Crop document to 80% center or current crop bounds
    const cropW = Math.round(doc.width * 0.8);
    const cropH = Math.round(doc.height * 0.8);
    const startX = Math.round((doc.width - cropW) / 2);
    const startY = Math.round((doc.height - cropH) / 2);

    const croppedLayers = doc.layers.map((l) => {
      const c = document.createElement('canvas');
      c.width = cropW;
      c.height = cropH;
      const ctx = c.getContext('2d');
      if (ctx) {
        ctx.drawImage(l.canvas, -startX, -startY);
      }
      return { ...l, canvas: c, width: cropW, height: cropH };
    });

    handleUpdateDocument(
      {
        ...doc,
        width: cropW,
        height: cropH,
        layers: croppedLayers,
      },
      'Apply Crop'
    );
    setActiveTool('move');
  };

  // Adjustments & Filters Triggers
  const handleTriggerAdjustment = (adjType: string) => {
    setAdjTypeForModal(adjType as any);
    setActiveModal('adjustments');
  };

  const handleApplyAdjustment = (adjSettings: AdjustmentSettings) => {
    const activeLayer = doc.layers.find((l) => l.id === doc.activeLayerId);
    if (!activeLayer) return;
    const ctx = activeLayer.canvas.getContext('2d');
    if (!ctx) return;

    const imgData = ctx.getImageData(0, 0, activeLayer.canvas.width, activeLayer.canvas.height);
    const adjusted = applyAdjustments(imgData, adjSettings);
    ctx.putImageData(adjusted, 0, 0);

    handleUpdateDocument({ ...doc }, `Adjustment: ${adjSettings.type}`);
    setActiveModal(null);
  };

  const handleTriggerFilter = (fType: string) => {
    setFilterTypeForModal(fType);
    setActiveModal('filters');
  };

  const handleApplyFilter = (fType: string, params: any) => {
    const activeLayer = doc.layers.find((l) => l.id === doc.activeLayerId);
    if (!activeLayer) return;
    const ctx = activeLayer.canvas.getContext('2d');
    if (!ctx) return;

    if (fType === 'clouds') {
      const clouds = renderClouds(activeLayer.canvas.width, activeLayer.canvas.height);
      ctx.putImageData(clouds, 0, 0);
      handleUpdateDocument({ ...doc }, 'Filter: Clouds');
      setActiveModal(null);
      return;
    }

    if (fType === 'lensFlare') {
      renderLensFlare(activeLayer.canvas, activeLayer.canvas.width / 2, activeLayer.canvas.height / 2, (params.amount || 50) / 50);
      handleUpdateDocument({ ...doc }, 'Filter: Lens Flare');
      setActiveModal(null);
      return;
    }

    const imgData = ctx.getImageData(0, 0, activeLayer.canvas.width, activeLayer.canvas.height);
    let filtered: ImageData | null = null;

    switch (fType) {
      case 'gaussianBlur':
        filtered = applyGaussianBlur(imgData, params.radius);
        break;
      case 'motionBlur':
        filtered = applyMotionBlur(imgData, params.distance, params.angle);
        break;
      case 'radialBlur':
        filtered = applyRadialBlur(imgData, params.amount);
        break;
      case 'unsharpMask':
        filtered = applyUnsharpMask(imgData, params.radius, params.amount);
        break;
      case 'highPass':
        filtered = applyHighPass(imgData, params.radius);
        break;
      case 'addNoise':
        filtered = applyAddNoise(imgData, params.amount, true);
        break;
      case 'twirl':
        filtered = applyTwirl(imgData, params.amount * 3.6);
        break;
      case 'ripple':
        filtered = applyRipple(imgData, params.radius * 2, 8);
        break;
      case 'mosaic':
        filtered = applyMosaic(imgData, params.blockSize);
        break;
      case 'emboss':
        filtered = applyEmboss(imgData);
        break;
      case 'findEdges':
        filtered = applyFindEdges(imgData);
        break;
    }

    if (filtered) {
      ctx.putImageData(filtered, 0, 0);
      handleUpdateDocument({ ...doc }, `Filter: ${fType}`);
    }
    setActiveModal(null);
  };

  // Open Document from file
  const handleOpenAsDocument = (img: HTMLImageElement, filename: string) => {
    const canvas = document.createElement('canvas');
    canvas.width = img.width;
    canvas.height = img.height;
    const ctx = canvas.getContext('2d');
    if (ctx) ctx.drawImage(img, 0, 0);

    const layer: Layer = {
      id: 'layer_' + Date.now(),
      name: 'Background',
      type: 'pixel',
      visible: true,
      locked: false,
      opacity: 1,
      fillOpacity: 1,
      blendMode: 'normal',
      x: 0,
      y: 0,
      width: img.width,
      height: img.height,
      canvas,
      maskEnabled: false,
      maskInverted: false,
      maskLinked: true,
      maskDensity: 1,
      maskFeather: 0,
      isBackground: true,
    };

    const newDoc: DocumentState = {
      id: 'doc_' + Date.now(),
      name: filename.replace(/\.[^/.]+$/, ''),
      width: img.width,
      height: img.height,
      resolution: 72,
      colorMode: 'RGB',
      layers: [layer],
      activeLayerId: layer.id,
      selection: null,
      history: [],
      historyIndex: -1,
      zoom: Math.min(1, 800 / Math.max(img.width, img.height)),
      pan: { x: 0, y: 0 },
      rotation: 0,
      guides: [],
      rulersVisible: true,
      gridVisible: false,
      snapToGrid: false,
      snapToGuides: true,
      frames: [{ id: 'f1', duration: 0.2, layerStates: {} }],
      activeFrameIndex: 0,
      isPlayingTimeline: false,
    };

    setDoc(pushHistoryStep(newDoc, `Opened ${filename}`));
  };

  // Add Image as Layer
  const handleOpenAsLayer = (img: HTMLImageElement, filename: string) => {
    const canvas = document.createElement('canvas');
    canvas.width = img.width;
    canvas.height = img.height;
    const ctx = canvas.getContext('2d');
    if (ctx) ctx.drawImage(img, 0, 0);

    const layer: Layer = {
      id: 'layer_' + Date.now(),
      name: filename.replace(/\.[^/.]+$/, ''),
      type: 'pixel',
      visible: true,
      locked: false,
      opacity: 1,
      fillOpacity: 1,
      blendMode: 'normal',
      x: Math.max(0, (doc.width - img.width) / 2),
      y: Math.max(0, (doc.height - img.height) / 2),
      width: img.width,
      height: img.height,
      canvas,
      maskEnabled: false,
      maskInverted: false,
      maskLinked: true,
      maskDensity: 1,
      maskFeather: 0,
    };

    handleUpdateDocument(
      {
        ...doc,
        layers: [layer, ...doc.layers],
        activeLayerId: layer.id,
      },
      `Import ${filename}`
    );
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-[#18181b] overflow-hidden select-none font-sans">
      {/* 1. TOP MENU (Desktop only) */}
      {!isMobile && (
        <HeaderMenu
          onOpenModal={setActiveModal}
          onUndo={handleUndo}
          onRedo={handleRedo}
          canUndo={doc.historyIndex > 0}
          canRedo={doc.historyIndex < doc.history.length - 1}
          onTriggerFilter={handleTriggerFilter}
          onTriggerAdjustment={handleTriggerAdjustment}
          onNewLayer={handleNewLayer}
          onDuplicateLayer={handleDuplicateLayer}
          onDeleteLayer={handleDeleteLayer}
          onMergeDown={handleMergeDown}
          onFlattenImage={handleFlattenImage}
          onSelectAll={handleSelectAll}
          onDeselect={handleDeselect}
          onInverseSelection={handleInverseSelection}
          onRotateCanvas={handleRotateCanvas}
          onFlipCanvas={handleFlipCanvas}
          onZoomIn={handleZoomIn}
          onZoomOut={handleZoomOut}
          onZoomFit={handleZoomFit}
          onZoomActual={handleZoomActual}
          onToggleRulers={() => setDoc((prev) => ({ ...prev, rulersVisible: !prev.rulersVisible }))}
          onToggleGrid={() => setDoc((prev) => ({ ...prev, gridVisible: !prev.gridVisible }))}
          rulersVisible={doc.rulersVisible}
          gridVisible={doc.gridVisible}
          activePanel={activeRightTab}
          onTogglePanel={(p) => setActiveRightTab(p)}
          documentName={doc.name}
          zoom={doc.zoom}
        />
      )}

      {/* 2. DYNAMIC OPTIONS BAR (Desktop only) */}
      {!isMobile && (
        <OptionsBar
          activeTool={activeTool}
          settings={settings}
          onUpdateSettings={(patch) => setSettings((prev) => ({ ...prev, ...patch }))}
          onApplyCrop={handleApplyCrop}
          onCancelCrop={() => setActiveTool('move')}
          onOpenModal={setActiveModal}
        />
      )}

      {/* 3. MAIN WORKSPACE ROW */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Left Toolbar (Desktop only) */}
        {!isMobile && (
          <Toolbar
            activeTool={activeTool}
            onSelectTool={setActiveTool}
            foregroundColor={settings.activeColor}
            backgroundColor={settings.backgroundColor}
            onSwapColors={handleSwapColors}
            onResetColors={handleResetColors}
            onChangeForegroundColor={(c) => setSettings((prev) => ({ ...prev, activeColor: c }))}
            onChangeBackgroundColor={(c) => setSettings((prev) => ({ ...prev, backgroundColor: c }))}
          />
        )}

        {/* Center Canvas Viewport */}
        <div className="flex-1 flex flex-col overflow-hidden relative">
          <WorkspaceCanvas
            document={doc}
            activeTool={activeTool}
            settings={settings}
            onUpdateDocument={handleUpdateDocument}
            onUpdateSettings={(patch) => setSettings((prev) => ({ ...prev, ...patch }))}
            isTransformActive={isTransformActive}
            onFinishTransform={() => setIsTransformActive(false)}
          />

          {/* Timeline Panel (collapsible at bottom if active tab is timeline) */}
          {activeRightTab === 'timeline' && (
            <TimelinePanel document={doc} onUpdateDocument={handleUpdateDocument} />
          )}
        </div>

        {/* Right Dockable Panel System (Desktop only) */}
        {!isMobile && (
          <div className="w-72 bg-[#202024] border-l border-[#2e2e32] flex flex-col z-20 shrink-0">
            {/* Panel Tabs Bar */}
            <div className="h-8 bg-[#1a1a1e] border-b border-[#2e2e32] flex items-center px-1 overflow-x-auto text-[11px] gap-1">
              {[
                { id: 'layers', name: 'Layers' },
                { id: 'properties', name: 'Properties' },
                { id: 'history', name: 'History' },
                { id: 'channels', name: 'Channels' },
                { id: 'color', name: 'Color' },
                { id: 'navigator', name: 'Navigator' },
                { id: 'timeline', name: 'Timeline' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveRightTab(tab.id)}
                  className={`px-2.5 py-1 rounded transition-colors cursor-pointer font-medium whitespace-nowrap ${
                    activeRightTab === tab.id
                      ? 'bg-[#2b2b32] text-sky-400 font-bold border-b border-sky-400'
                      : 'text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  {tab.name}
                </button>
              ))}
            </div>

            {/* Active Panel View */}
            <div className="flex-1 overflow-hidden">
              {activeRightTab === 'layers' && (
                <LayersPanel
                  document={doc}
                  onUpdateDocument={handleUpdateDocument}
                  onOpenModal={setActiveModal}
                />
              )}
              {activeRightTab === 'properties' && (
                <PropertiesPanel document={doc} onUpdateDocument={handleUpdateDocument} />
              )}
              {activeRightTab === 'history' && (
                <HistoryPanel document={doc} onUpdateDocument={handleUpdateDocument} />
              )}
              {activeRightTab === 'channels' && <ChannelsPanel document={doc} />}
              {activeRightTab === 'color' && (
                <ColorSwatchesPanel
                  foregroundColor={settings.activeColor}
                  backgroundColor={settings.backgroundColor}
                  onChangeForegroundColor={(c) => setSettings((prev) => ({ ...prev, activeColor: c }))}
                  onChangeBackgroundColor={(c) => setSettings((prev) => ({ ...prev, backgroundColor: c }))}
                />
              )}
              {activeRightTab === 'navigator' && (
                <NavigatorPanel
                  document={doc}
                  onUpdateZoom={(z) => setDoc((prev) => ({ ...prev, zoom: z }))}
                  onResetZoom={handleZoomFit}
                />
              )}
              {activeRightTab === 'timeline' && (
                <div className="p-3 text-neutral-400 text-xs text-center">
                  Timeline animation bar is active at bottom of canvas workspace.
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* 4. MOBILE WORKSPACE (When viewport is mobile/tablet) */}
      {isMobile && (
        <MobileWorkspace
          document={doc}
          activeTool={activeTool}
          settings={settings}
          onSelectTool={setActiveTool}
          onUpdateDocument={handleUpdateDocument}
          onUpdateSettings={(patch) => setSettings((prev) => ({ ...prev, ...patch }))}
          onOpenModal={setActiveModal}
          onUndo={handleUndo}
          onRedo={handleRedo}
          canUndo={doc.historyIndex > 0}
          canRedo={doc.historyIndex < doc.history.length - 1}
        />
      )}

      {/* 5. MODALS & DIALOGS */}
      {activeModal === 'newDoc' && (
        <NewDocumentDialog
          onClose={() => setActiveModal(null)}
          onCreate={(name, w, h, dpi, bg) => {
            const canvas = document.createElement('canvas');
            canvas.width = w;
            canvas.height = h;
            const ctx = canvas.getContext('2d');
            if (ctx && bg !== 'transparent') {
              ctx.fillStyle = bg;
              ctx.fillRect(0, 0, w, h);
            }
            const l: Layer = {
              id: 'layer_bg_' + Date.now(),
              name: 'Background',
              type: 'pixel',
              visible: true,
              locked: false,
              opacity: 1,
              fillOpacity: 1,
              blendMode: 'normal',
              x: 0,
              y: 0,
              width: w,
              height: h,
              canvas,
              maskEnabled: false,
              maskInverted: false,
              maskLinked: true,
              maskDensity: 1,
              maskFeather: 0,
              isBackground: true,
            };
            const newDoc: DocumentState = {
              id: 'doc_' + Date.now(),
              name,
              width: w,
              height: h,
              resolution: dpi,
              colorMode: 'RGB',
              layers: [l],
              activeLayerId: l.id,
              selection: null,
              history: [],
              historyIndex: -1,
              zoom: 0.85,
              pan: { x: 0, y: 0 },
              rotation: 0,
              guides: [],
              rulersVisible: true,
              gridVisible: false,
              snapToGrid: false,
              snapToGuides: true,
              frames: [{ id: 'f1', duration: 0.2, layerStates: {} }],
              activeFrameIndex: 0,
              isPlayingTimeline: false,
            };
            setDoc(pushHistoryStep(newDoc, 'New Document'));
          }}
        />
      )}

      {activeModal === 'openImage' && (
        <OpenImageDialog
          onClose={() => setActiveModal(null)}
          onOpenAsDocument={handleOpenAsDocument}
          onOpenAsLayer={handleOpenAsLayer}
          onLoadProject={(json) => {
            try {
              const data = JSON.parse(json);
              if (data.document) {
                // Rehydrate layers
                Promise.all(
                  data.document.layers.map(async (lData: any) => {
                    const canvas = document.createElement('canvas');
                    canvas.width = lData.width;
                    canvas.height = lData.height;
                    const ctx = canvas.getContext('2d');
                    if (ctx && lData.dataUrl) {
                      await new Promise<void>((res) => {
                        const img = new Image();
                        img.onload = () => {
                          ctx.drawImage(img, 0, 0);
                          res();
                        };
                        img.onerror = () => res();
                        img.src = lData.dataUrl;
                      });
                    }
                    return {
                      ...lData,
                      canvas,
                    };
                  })
                ).then((rehydratedLayers) => {
                  const restoredDoc: DocumentState = {
                    ...data.document,
                    layers: rehydratedLayers,
                    activeLayerId: rehydratedLayers[0]?.id || '',
                    selection: null,
                    history: [],
                    historyIndex: -1,
                    zoom: 0.85,
                    pan: { x: 0, y: 0 },
                    rotation: 0,
                    frames: [{ id: 'f1', duration: 0.2, layerStates: {} }],
                    activeFrameIndex: 0,
                    isPlayingTimeline: false,
                  };
                  setDoc(pushHistoryStep(restoredDoc, 'Loaded Project'));
                });
              }
            } catch (e) {
              console.error('Failed to parse project JSON', e);
            }
          }}
        />
      )}

      {activeModal === 'export' && (
        <ExportModal document={doc} onClose={() => setActiveModal(null)} />
      )}

      {activeModal === 'adjustments' && (
        <AdjustmentsModal
          document={doc}
          initialType={adjTypeForModal}
          onClose={() => setActiveModal(null)}
          onApply={handleApplyAdjustment}
        />
      )}

      {activeModal === 'filters' && (
        <FilterDialog
          document={doc}
          initialFilter={filterTypeForModal}
          onClose={() => setActiveModal(null)}
          onApplyFilter={handleApplyFilter}
        />
      )}

      {activeModal === 'layerStyles' && (
        <LayerStylesModal
          document={doc}
          onClose={() => setActiveModal(null)}
          onApplyStyles={(effects: LayerEffects) => {
            const updated = doc.layers.map((l) =>
              l.id === doc.activeLayerId ? { ...l, effects } : l
            );
            handleUpdateDocument({ ...doc, layers: updated }, 'Update Layer Styles');
          }}
        />
      )}

      {activeModal === 'gradientEditor' && (
        <GradientEditorModal
          currentConfig={settings.gradient}
          onClose={() => setActiveModal(null)}
          onApplyGradient={(grad) => setSettings((prev) => ({ ...prev, gradient: grad }))}
        />
      )}

      {activeModal === 'shortcuts' && (
        <KeyboardShortcutsModal onClose={() => setActiveModal(null)} />
      )}

      {activeModal === 'projectZip' && (
        <ProjectZipModal onClose={() => setActiveModal(null)} />
      )}

      {activeModal === 'automatedTests' && (
        <AutomatedTestModal onClose={() => setActiveModal(null)} />
      )}
    </div>
  );
}
