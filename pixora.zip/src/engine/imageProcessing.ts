/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AdjustmentSettings } from '../types';

// Helper: clamp number between min and max
export function clamp(val: number, min = 0, max = 255): number {
  return Math.max(min, Math.min(max, val));
}

// Convert RGB to HSL
export function rgbToHsl(r: number, g: number, b: number): [number, number, number] {
  r /= 255;
  g /= 255;
  b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  let s = 0;
  const l = (max + min) / 2;

  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;
    }
    h /= 6;
  }
  return [h, s, l];
}

// Helper: hue to RGB channel
function hue2rgb(p: number, q: number, t: number): number {
  if (t < 0) t += 1;
  if (t > 1) t -= 1;
  if (t < 1 / 6) return p + (q - p) * 6 * t;
  if (t < 1 / 2) return q;
  if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
  return p;
}

// Convert HSL to RGB
export function hslToRgb(h: number, s: number, l: number): [number, number, number] {
  let r: number, g: number, b: number;
  if (s === 0) {
    r = g = b = l; // achromatic
  } else {
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r = hue2rgb(p, q, h + 1 / 3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1 / 3);
  }
  return [Math.round(r * 255), Math.round(g * 255), Math.round(b * 255)];
}

// Hex color to RGBA
export function hexToRgb(hex: string): { r: number; g: number; b: number; a: number } {
  hex = hex.replace('#', '');
  if (hex.length === 3) {
    hex = hex.split('').map((c) => c + c).join('');
  }
  const num = parseInt(hex, 16);
  if (hex.length === 8) {
    return {
      r: (num >> 24) & 255,
      g: (num >> 16) & 255,
      b: (num >> 8) & 255,
      a: (num & 255) / 255,
    };
  }
  return {
    r: (num >> 16) & 255,
    g: (num >> 8) & 255,
    b: num & 255,
    a: 1,
  };
}

// Color difference (Euclidean distance in RGB)
export function colorDistance(r1: number, g1: number, b1: number, r2: number, g2: number, b2: number): number {
  return Math.sqrt((r1 - r2) ** 2 + (g1 - g2) ** 2 + (b1 - b2) ** 2);
}

// ==========================================
// ADJUSTMENTS ENGINE
// ==========================================

export function applyAdjustments(
  imageData: ImageData,
  settings: AdjustmentSettings
): ImageData {
  const data = imageData.data;
  const len = data.length;

  switch (settings.type) {
    case 'brightnessContrast': {
      const b = (settings.brightness || 0) * 2.55; // -255 to 255
      const c = settings.contrast || 0; // -100 to 100
      const factor = (259 * (c + 255)) / (255 * (259 - c));
      for (let i = 0; i < len; i += 4) {
        data[i] = clamp(factor * (data[i] + b - 128) + 128);
        data[i + 1] = clamp(factor * (data[i + 1] + b - 128) + 128);
        data[i + 2] = clamp(factor * (data[i + 2] + b - 128) + 128);
      }
      break;
    }

    case 'levels': {
      const inBlack = settings.levels?.inBlack ?? 0;
      const inWhite = settings.levels?.inWhite ?? 255;
      const gamma = settings.levels?.gamma ?? 1.0;
      const outBlack = settings.levels?.outBlack ?? 0;
      const outWhite = settings.levels?.outWhite ?? 255;

      const rangeIn = Math.max(1, inWhite - inBlack);
      const rangeOut = outWhite - outBlack;
      const invGamma = 1 / gamma;

      // Precalculate 256-entry lookup table for speed
      const lut = new Uint8ClampedArray(256);
      for (let i = 0; i < 256; i++) {
        let val = (i - inBlack) / rangeIn;
        val = Math.max(0, Math.min(1, val));
        val = Math.pow(val, invGamma);
        lut[i] = clamp(outBlack + val * rangeOut);
      }

      for (let i = 0; i < len; i += 4) {
        data[i] = lut[data[i]];
        data[i + 1] = lut[data[i + 1]];
        data[i + 2] = lut[data[i + 2]];
      }
      break;
    }

    case 'curves': {
      const points = settings.curves || [
        { x: 0, y: 0 },
        { x: 255, y: 255 },
      ];
      // Build piecewise linear / spline LUT
      const lut = new Uint8ClampedArray(256);
      for (let i = 0; i < 256; i++) {
        // Find segment
        let p0 = points[0];
        let p1 = points[points.length - 1];
        for (let j = 0; j < points.length - 1; j++) {
          if (i >= points[j].x && i <= points[j + 1].x) {
            p0 = points[j];
            p1 = points[j + 1];
            break;
          }
        }
        const t = p1.x === p0.x ? 0 : (i - p0.x) / (p1.x - p0.x);
        lut[i] = clamp(p0.y + t * (p1.y - p0.y));
      }

      for (let i = 0; i < len; i += 4) {
        data[i] = lut[data[i]];
        data[i + 1] = lut[data[i + 1]];
        data[i + 2] = lut[data[i + 2]];
      }
      break;
    }

    case 'hueSaturation': {
      const hDelta = (settings.hue || 0) / 360;
      const sDelta = (settings.saturation || 0) / 100;
      const lDelta = (settings.lightness || 0) / 100;

      for (let i = 0; i < len; i += 4) {
        let [h, s, l] = rgbToHsl(data[i], data[i + 1], data[i + 2]);
        h = (h + hDelta + 1) % 1;
        s = clamp(s * (1 + sDelta), 0, 1);
        l = clamp(l + lDelta * (lDelta > 0 ? 1 - l : l), 0, 1);
        const [nr, ng, nb] = hslToRgb(h, s, l);
        data[i] = nr;
        data[i + 1] = ng;
        data[i + 2] = nb;
      }
      break;
    }

    case 'vibrance': {
      const vib = (settings.vibrance || 0) / 100;
      for (let i = 0; i < len; i += 4) {
        const r = data[i], g = data[i + 1], b = data[i + 2];
        const max = Math.max(r, g, b);
        const avg = (r + g + b) / 3;
        const amt = ((Math.abs(max - avg) * 2) / 255) * vib;
        data[i] = clamp(r + (max - r) * amt);
        data[i + 1] = clamp(g + (max - g) * amt);
        data[i + 2] = clamp(b + (max - b) * amt);
      }
      break;
    }

    case 'colorBalance': {
      const cr = (settings.colorBalance?.cyanRed || 0) * 1.5;
      const mg = (settings.colorBalance?.magentaGreen || 0) * 1.5;
      const yb = (settings.colorBalance?.yellowBlue || 0) * 1.5;
      for (let i = 0; i < len; i += 4) {
        data[i] = clamp(data[i] + cr);
        data[i + 1] = clamp(data[i + 1] + mg);
        data[i + 2] = clamp(data[i + 2] + yb);
      }
      break;
    }

    case 'temperatureTint': {
      const temp = (settings.temperature || 0) * 1.5; // warm (amber) vs cool (blue)
      const tint = (settings.tint || 0) * 1.5; // green vs magenta
      for (let i = 0; i < len; i += 4) {
        data[i] = clamp(data[i] + temp + tint * 0.5);
        data[i + 1] = clamp(data[i + 1] - tint * 0.8);
        data[i + 2] = clamp(data[i + 2] - temp + tint * 0.5);
      }
      break;
    }

    case 'blackAndWhite':
    case 'desaturate': {
      for (let i = 0; i < len; i += 4) {
        const gray = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
        data[i] = gray;
        data[i + 1] = gray;
        data[i + 2] = gray;
      }
      break;
    }

    case 'invert': {
      for (let i = 0; i < len; i += 4) {
        data[i] = 255 - data[i];
        data[i + 1] = 255 - data[i + 1];
        data[i + 2] = 255 - data[i + 2];
      }
      break;
    }

    case 'threshold': {
      const thresh = settings.threshold || 128;
      for (let i = 0; i < len; i += 4) {
        const lum = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
        const val = lum >= thresh ? 255 : 0;
        data[i] = val;
        data[i + 1] = val;
        data[i + 2] = val;
      }
      break;
    }

    case 'posterize': {
      const levels = Math.max(2, Math.min(64, settings.posterize || 4));
      const step = 255 / (levels - 1);
      for (let i = 0; i < len; i += 4) {
        data[i] = Math.round(Math.round(data[i] / step) * step);
        data[i + 1] = Math.round(Math.round(data[i + 1] / step) * step);
        data[i + 2] = Math.round(Math.round(data[i + 2] / step) * step);
      }
      break;
    }

    case 'photoFilter': {
      const col = hexToRgb(settings.photoFilter?.color || '#f59e0b');
      const d = (settings.photoFilter?.density || 25) / 100;
      for (let i = 0; i < len; i += 4) {
        data[i] = clamp(data[i] * (1 - d) + col.r * d);
        data[i + 1] = clamp(data[i + 1] * (1 - d) + col.g * d);
        data[i + 2] = clamp(data[i + 2] * (1 - d) + col.b * d);
      }
      break;
    }
  }

  return imageData;
}

// ==========================================
// PROFESSIONAL FILTER LIBRARY (NON-AI)
// ==========================================

// 1. Separable Gaussian Blur (Fast 2-Pass Horizontal + Vertical)
export function applyGaussianBlur(imageData: ImageData, radius: number): ImageData {
  if (radius <= 0) return imageData;
  const width = imageData.width;
  const height = imageData.height;
  const src = imageData.data;
  const target = new Uint8ClampedArray(src.length);
  const temp = new Float32Array(src.length);

  // Generate 1D Gaussian kernel
  const sigma = radius / 2;
  const kSize = Math.ceil(radius * 2) * 2 + 1;
  const kernel = new Float32Array(kSize);
  let kSum = 0;
  const half = Math.floor(kSize / 2);

  for (let i = 0; i < kSize; i++) {
    const x = i - half;
    const g = Math.exp(-(x * x) / (2 * sigma * sigma));
    kernel[i] = g;
    kSum += g;
  }
  for (let i = 0; i < kSize; i++) {
    kernel[i] /= kSum;
  }

  // Pass 1: Horizontal Blur -> temp
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      let r = 0, g = 0, b = 0, a = 0;
      for (let k = 0; k < kSize; k++) {
        const px = Math.min(width - 1, Math.max(0, x + k - half));
        const idx = (y * width + px) * 4;
        const weight = kernel[k];
        r += src[idx] * weight;
        g += src[idx + 1] * weight;
        b += src[idx + 2] * weight;
        a += src[idx + 3] * weight;
      }
      const outIdx = (y * width + x) * 4;
      temp[outIdx] = r;
      temp[outIdx + 1] = g;
      temp[outIdx + 2] = b;
      temp[outIdx + 3] = a;
    }
  }

  // Pass 2: Vertical Blur -> target
  for (let x = 0; x < width; x++) {
    for (let y = 0; y < height; y++) {
      let r = 0, g = 0, b = 0, a = 0;
      for (let k = 0; k < kSize; k++) {
        const py = Math.min(height - 1, Math.max(0, y + k - half));
        const idx = (py * width + x) * 4;
        const weight = kernel[k];
        r += temp[idx] * weight;
        g += temp[idx + 1] * weight;
        b += temp[idx + 2] * weight;
        a += temp[idx + 3] * weight;
      }
      const outIdx = (y * width + x) * 4;
      target[outIdx] = r;
      target[outIdx + 1] = g;
      target[outIdx + 2] = b;
      target[outIdx + 3] = a;
    }
  }

  return new ImageData(target, width, height);
}

// 2. Motion Blur
export function applyMotionBlur(imageData: ImageData, distance: number, angleDeg: number): ImageData {
  const width = imageData.width;
  const height = imageData.height;
  const src = imageData.data;
  const target = new Uint8ClampedArray(src.length);
  const rad = (angleDeg * Math.PI) / 180;
  const dx = Math.cos(rad);
  const dy = Math.sin(rad);
  const steps = Math.max(1, Math.round(distance));

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      let r = 0, g = 0, b = 0, a = 0;
      for (let s = -steps; s <= steps; s++) {
        const sampleX = Math.min(width - 1, Math.max(0, Math.round(x + s * dx)));
        const sampleY = Math.min(height - 1, Math.max(0, Math.round(y + s * dy)));
        const idx = (sampleY * width + sampleX) * 4;
        r += src[idx];
        g += src[idx + 1];
        b += src[idx + 2];
        a += src[idx + 3];
      }
      const count = steps * 2 + 1;
      const outIdx = (y * width + x) * 4;
      target[outIdx] = r / count;
      target[outIdx + 1] = g / count;
      target[outIdx + 2] = b / count;
      target[outIdx + 3] = a / count;
    }
  }
  return new ImageData(target, width, height);
}

// 3. Radial Blur (Spin)
export function applyRadialBlur(imageData: ImageData, amount: number): ImageData {
  const width = imageData.width;
  const height = imageData.height;
  const src = imageData.data;
  const target = new Uint8ClampedArray(src.length);
  const cx = width / 2;
  const cy = height / 2;
  const samples = 10;
  const maxAngle = (amount * Math.PI) / 180 / 2;

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const rx = x - cx;
      const ry = y - cy;
      const baseDist = Math.sqrt(rx * rx + ry * ry);
      const baseAngle = Math.atan2(ry, rx);
      let r = 0, g = 0, b = 0, a = 0;

      for (let s = 0; s < samples; s++) {
        const t = (s / (samples - 1) - 0.5) * 2;
        const curAngle = baseAngle + t * maxAngle;
        const sx = Math.min(width - 1, Math.max(0, Math.round(cx + Math.cos(curAngle) * baseDist)));
        const sy = Math.min(height - 1, Math.max(0, Math.round(cy + Math.sin(curAngle) * baseDist)));
        const idx = (sy * width + sx) * 4;
        r += src[idx];
        g += src[idx + 1];
        b += src[idx + 2];
        a += src[idx + 3];
      }
      const outIdx = (y * width + x) * 4;
      target[outIdx] = r / samples;
      target[outIdx + 1] = g / samples;
      target[outIdx + 2] = b / samples;
      target[outIdx + 3] = a / samples;
    }
  }
  return new ImageData(target, width, height);
}

// 4. Sharpen / Unsharp Mask
export function applyUnsharpMask(imageData: ImageData, radius: number, amount: number): ImageData {
  const blurred = applyGaussianBlur(imageData, radius);
  const width = imageData.width;
  const height = imageData.height;
  const src = imageData.data;
  const blurData = blurred.data;
  const target = new Uint8ClampedArray(src.length);
  const factor = amount / 100;

  for (let i = 0; i < src.length; i += 4) {
    target[i] = clamp(src[i] + factor * (src[i] - blurData[i]));
    target[i + 1] = clamp(src[i + 1] + factor * (src[i + 1] - blurData[i + 1]));
    target[i + 2] = clamp(src[i + 2] + factor * (src[i + 2] - blurData[i + 2]));
    target[i + 3] = src[i + 3];
  }
  return new ImageData(target, width, height);
}

// 5. High Pass Filter
export function applyHighPass(imageData: ImageData, radius: number): ImageData {
  const blurred = applyGaussianBlur(imageData, radius);
  const width = imageData.width;
  const height = imageData.height;
  const src = imageData.data;
  const blurData = blurred.data;
  const target = new Uint8ClampedArray(src.length);

  for (let i = 0; i < src.length; i += 4) {
    target[i] = clamp(src[i] - blurData[i] + 128);
    target[i + 1] = clamp(src[i + 1] - blurData[i + 1] + 128);
    target[i + 2] = clamp(src[i + 2] - blurData[i + 2] + 128);
    target[i + 3] = src[i + 3];
  }
  return new ImageData(target, width, height);
}

// 6. Add Noise
export function applyAddNoise(imageData: ImageData, amount: number, monochromatic = false): ImageData {
  const width = imageData.width;
  const height = imageData.height;
  const src = imageData.data;
  const target = new Uint8ClampedArray(src);
  const scale = (amount / 100) * 255;

  for (let i = 0; i < target.length; i += 4) {
    if (monochromatic) {
      const n = (Math.random() - 0.5) * scale;
      target[i] = clamp(target[i] + n);
      target[i + 1] = clamp(target[i + 1] + n);
      target[i + 2] = clamp(target[i + 2] + n);
    } else {
      target[i] = clamp(target[i] + (Math.random() - 0.5) * scale);
      target[i + 1] = clamp(target[i + 1] + (Math.random() - 0.5) * scale);
      target[i + 2] = clamp(target[i + 2] + (Math.random() - 0.5) * scale);
    }
  }
  return new ImageData(target, width, height);
}

// 7. Twirl Distortion
export function applyTwirl(imageData: ImageData, angleDeg: number, radiusRatio = 0.5): ImageData {
  const width = imageData.width;
  const height = imageData.height;
  const src = imageData.data;
  const target = new Uint8ClampedArray(src.length);
  const cx = width / 2;
  const cy = height / 2;
  const maxRadius = Math.min(width, height) * radiusRatio;
  const angleRad = (angleDeg * Math.PI) / 180;

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const dx = x - cx;
      const dy = y - cy;
      const r = Math.sqrt(dx * dx + dy * dy);
      let sx = x;
      let sy = y;

      if (r < maxRadius) {
        const factor = 1 - r / maxRadius;
        const theta = Math.atan2(dy, dx) + angleRad * factor * factor;
        sx = Math.min(width - 1, Math.max(0, Math.round(cx + r * Math.cos(theta))));
        sy = Math.min(height - 1, Math.max(0, Math.round(cy + r * Math.sin(theta))));
      }

      const outIdx = (y * width + x) * 4;
      const inIdx = (sy * width + sx) * 4;
      target[outIdx] = src[inIdx];
      target[outIdx + 1] = src[inIdx + 1];
      target[outIdx + 2] = src[inIdx + 2];
      target[outIdx + 3] = src[inIdx + 3];
    }
  }
  return new ImageData(target, width, height);
}

// 8. Ripple Distortion
export function applyRipple(imageData: ImageData, amplitude: number, frequency: number): ImageData {
  const width = imageData.width;
  const height = imageData.height;
  const src = imageData.data;
  const target = new Uint8ClampedArray(src.length);

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const sx = Math.min(
        width - 1,
        Math.max(0, Math.round(x + amplitude * Math.sin((y * frequency * 2 * Math.PI) / height)))
      );
      const sy = Math.min(
        height - 1,
        Math.max(0, Math.round(y + amplitude * Math.cos((x * frequency * 2 * Math.PI) / width)))
      );

      const outIdx = (y * width + x) * 4;
      const inIdx = (sy * width + sx) * 4;
      target[outIdx] = src[inIdx];
      target[outIdx + 1] = src[inIdx + 1];
      target[outIdx + 2] = src[inIdx + 2];
      target[outIdx + 3] = src[inIdx + 3];
    }
  }
  return new ImageData(target, width, height);
}

// 9. Mosaic Pixelation
export function applyMosaic(imageData: ImageData, blockSize: number): ImageData {
  const width = imageData.width;
  const height = imageData.height;
  const src = imageData.data;
  const target = new Uint8ClampedArray(src.length);
  const size = Math.max(2, Math.round(blockSize));

  for (let by = 0; by < height; by += size) {
    for (let bx = 0; bx < width; bx += size) {
      let r = 0, g = 0, b = 0, a = 0, count = 0;
      const maxX = Math.min(width, bx + size);
      const maxY = Math.min(height, by + size);

      for (let y = by; y < maxY; y++) {
        for (let x = bx; x < maxX; x++) {
          const idx = (y * width + x) * 4;
          r += src[idx];
          g += src[idx + 1];
          b += src[idx + 2];
          a += src[idx + 3];
          count++;
        }
      }

      const avgR = r / count;
      const avgG = g / count;
      const avgB = b / count;
      const avgA = a / count;

      for (let y = by; y < maxY; y++) {
        for (let x = bx; x < maxX; x++) {
          const idx = (y * width + x) * 4;
          target[idx] = avgR;
          target[idx + 1] = avgG;
          target[idx + 2] = avgB;
          target[idx + 3] = avgA;
        }
      }
    }
  }
  return new ImageData(target, width, height);
}

// 10. Emboss Stylize Filter
export function applyEmboss(imageData: ImageData): ImageData {
  const width = imageData.width;
  const height = imageData.height;
  const src = imageData.data;
  const target = new Uint8ClampedArray(src.length);

  // 3x3 Emboss convolution kernel: [-2, -1, 0, -1, 1, 1, 0, 1, 2]
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      let v = 0;
      v += -2 * src[((y - 1) * width + (x - 1)) * 4];
      v += -1 * src[((y - 1) * width + x) * 4];
      v += -1 * src[(y * width + (x - 1)) * 4];
      v += 1 * src[(y * width + (x + 1)) * 4];
      v += 1 * src[((y + 1) * width + x) * 4];
      v += 2 * src[((y + 1) * width + (x + 1)) * 4];
      const val = clamp(v + 128);

      const idx = (y * width + x) * 4;
      target[idx] = val;
      target[idx + 1] = val;
      target[idx + 2] = val;
      target[idx + 3] = src[idx + 3];
    }
  }
  return new ImageData(target, width, height);
}

// 11. Find Edges (Sobel)
export function applyFindEdges(imageData: ImageData): ImageData {
  const width = imageData.width;
  const height = imageData.height;
  const src = imageData.data;
  const target = new Uint8ClampedArray(src.length);

  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      // Sobel kernels
      // Gx = [-1 0 1; -2 0 2; -1 0 1]
      // Gy = [-1 -2 -1; 0 0 0; 1 2 1]
      let gx = 0, gy = 0;
      const getGray = (px: number, py: number) => {
        const i = (py * width + px) * 4;
        return 0.299 * src[i] + 0.587 * src[i + 1] + 0.114 * src[i + 2];
      };

      gx += -1 * getGray(x - 1, y - 1) + 1 * getGray(x + 1, y - 1);
      gx += -2 * getGray(x - 1, y) + 2 * getGray(x + 1, y);
      gx += -1 * getGray(x - 1, y + 1) + 1 * getGray(x + 1, y + 1);

      gy += -1 * getGray(x - 1, y - 1) - 2 * getGray(x, y - 1) - 1 * getGray(x + 1, y - 1);
      gy += 1 * getGray(x - 1, y + 1) + 2 * getGray(x, y + 1) + 1 * getGray(x + 1, y + 1);

      const mag = clamp(Math.sqrt(gx * gx + gy * gy));
      const idx = (y * width + x) * 4;
      target[idx] = mag;
      target[idx + 1] = mag;
      target[idx + 2] = mag;
      target[idx + 3] = src[idx + 3];
    }
  }
  return new ImageData(target, width, height);
}

// 12. Procedural Clouds (Fractal Perlin / Value Noise)
export function renderClouds(width: number, height: number): ImageData {
  const target = new Uint8ClampedArray(width * height * 4);
  // Multi-octave value noise
  const octaves = 5;
  const pSize = 32;

  // Simple pseudo-random permutation table
  const perm = new Uint8Array(512);
  for (let i = 0; i < 256; i++) perm[i] = i;
  for (let i = 255; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = perm[i];
    perm[i] = perm[j];
    perm[j] = tmp;
  }
  for (let i = 0; i < 256; i++) perm[256 + i] = perm[i];

  function noise2d(x: number, y: number): number {
    const xi = Math.floor(x) & 255;
    const yi = Math.floor(y) & 255;
    const xf = x - Math.floor(x);
    const yf = y - Math.floor(y);
    const u = xf * xf * (3 - 2 * xf);
    const v = yf * yf * (3 - 2 * yf);
    const aa = perm[perm[xi] + yi] / 255;
    const ab = perm[perm[xi] + yi + 1] / 255;
    const ba = perm[perm[xi + 1] + yi] / 255;
    const bb = perm[perm[xi + 1] + yi + 1] / 255;
    const x1 = aa + u * (ba - aa);
    const x2 = ab + u * (bb - ab);
    return x1 + v * (x2 - x1);
  }

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      let val = 0;
      let amp = 1;
      let freq = 1;
      let maxAmp = 0;

      for (let o = 0; o < octaves; o++) {
        val += noise2d((x / pSize) * freq, (y / pSize) * freq) * amp;
        maxAmp += amp;
        amp *= 0.5;
        freq *= 2;
      }
      const c = Math.round((val / maxAmp) * 255);
      const idx = (y * width + x) * 4;
      target[idx] = c;
      target[idx + 1] = c;
      target[idx + 2] = c;
      target[idx + 3] = 255;
    }
  }
  return new ImageData(target, width, height);
}

// 13. Lens Flare Render
export function renderLensFlare(
  canvas: HTMLCanvasElement,
  fx: number,
  fy: number,
  brightness = 1.0
): void {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  const cx = canvas.width / 2;
  const cy = canvas.height / 2;
  // Vector from flare to center
  const vx = cx - fx;
  const vy = cy - fy;

  ctx.save();
  ctx.globalCompositeOperation = 'screen';

  // 1. Central hot burst
  const grad = ctx.createRadialGradient(fx, fy, 0, fx, fy, 150 * brightness);
  grad.addColorStop(0, 'rgba(255, 255, 255, 0.9)');
  grad.addColorStop(0.2, 'rgba(255, 230, 150, 0.6)');
  grad.addColorStop(0.5, 'rgba(255, 120, 50, 0.2)');
  grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(fx, fy, 150 * brightness, 0, Math.PI * 2);
  ctx.fill();

  // 2. Anamorphic horizontal streak
  ctx.fillStyle = 'rgba(100, 200, 255, 0.3)';
  ctx.fillRect(0, fy - 2, canvas.width, 4);

  // 3. Artifact rings along reflection axis
  const rings = [0.3, 0.6, 0.9, 1.2, 1.6];
  const ringColors = [
    'rgba(100, 220, 100, 0.25)',
    'rgba(240, 100, 200, 0.2)',
    'rgba(255, 200, 50, 0.2)',
    'rgba(80, 180, 255, 0.25)',
    'rgba(255, 80, 80, 0.2)',
  ];

  rings.forEach((dist, idx) => {
    const rx = fx + vx * dist;
    const ry = fy + vy * dist;
    const rSize = 30 + dist * 25 * brightness;
    ctx.fillStyle = ringColors[idx % ringColors.length];
    ctx.beginPath();
    ctx.arc(rx, ry, rSize, 0, Math.PI * 2);
    ctx.fill();
  });

  ctx.restore();
}

// ==========================================
// FLOOD FILL & MAGIC WAND SELECTION ALGORITHM
// ==========================================

export function floodFill(
  ctx: CanvasRenderingContext2D,
  startX: number,
  startY: number,
  fillColorHex: string,
  tolerance: number,
  contiguous = true
): void {
  const width = ctx.canvas.width;
  const height = ctx.canvas.height;
  const imgData = ctx.getImageData(0, 0, width, height);
  const data = imgData.data;

  startX = Math.floor(startX);
  startY = Math.floor(startY);
  if (startX < 0 || startX >= width || startY < 0 || startY >= height) return;

  const startIdx = (startY * width + startX) * 4;
  const targetR = data[startIdx];
  const targetG = data[startIdx + 1];
  const targetB = data[startIdx + 2];
  const targetA = data[startIdx + 3];

  const fillRgb = hexToRgb(fillColorHex);
  const fillR = fillRgb.r;
  const fillG = fillRgb.g;
  const fillB = fillRgb.b;
  const fillA = Math.round(fillRgb.a * 255);

  // If already target color, return
  if (
    colorDistance(targetR, targetG, targetB, fillR, fillG, fillB) === 0 &&
    Math.abs(targetA - fillA) === 0
  ) {
    return;
  }

  function matches(idx: number): boolean {
    const dist = colorDistance(data[idx], data[idx + 1], data[idx + 2], targetR, targetG, targetB);
    const alphaDiff = Math.abs(data[idx + 3] - targetA);
    return dist <= tolerance && alphaDiff <= tolerance;
  }

  if (!contiguous) {
    // Fill all matching pixels globally across canvas
    for (let i = 0; i < data.length; i += 4) {
      if (matches(i)) {
        data[i] = fillR;
        data[i + 1] = fillG;
        data[i + 2] = fillB;
        data[i + 3] = fillA;
      }
    }
  } else {
    // 4-way scanline flood fill
    const visited = new Uint8Array(width * height);
    const queue: number[] = [startX, startY];

    while (queue.length > 0) {
      const cy = queue.pop()!;
      const cx = queue.pop()!;
      const coord = cy * width + cx;
      if (visited[coord]) continue;
      visited[coord] = 1;

      const idx = coord * 4;
      if (!matches(idx)) continue;

      data[idx] = fillR;
      data[idx + 1] = fillG;
      data[idx + 2] = fillB;
      data[idx + 3] = fillA;

      if (cx > 0 && !visited[coord - 1]) queue.push(cx - 1, cy);
      if (cx < width - 1 && !visited[coord + 1]) queue.push(cx + 1, cy);
      if (cy > 0 && !visited[coord - width]) queue.push(cx, cy - 1);
      if (cy < height - 1 && !visited[coord + width]) queue.push(cx, cy + 1);
    }
  }

  ctx.putImageData(imgData, 0, 0);
}

// Generate pixel-perfect selection mask using Magic Wand
export function generateMagicWandMask(
  sourceCanvas: HTMLCanvasElement,
  startX: number,
  startY: number,
  tolerance: number,
  contiguous = true
): HTMLCanvasElement {
  const width = sourceCanvas.width;
  const height = sourceCanvas.height;
  const sCtx = sourceCanvas.getContext('2d');
  const maskCanvas = document.createElement('canvas');
  maskCanvas.width = width;
  maskCanvas.height = height;
  const mCtx = maskCanvas.getContext('2d');
  if (!sCtx || !mCtx) return maskCanvas;

  const srcData = sCtx.getImageData(0, 0, width, height).data;
  const maskImg = mCtx.createImageData(width, height);
  const mData = maskImg.data;

  startX = Math.floor(startX);
  startY = Math.floor(startY);
  if (startX < 0 || startX >= width || startY < 0 || startY >= height) return maskCanvas;

  const startIdx = (startY * width + startX) * 4;
  const tr = srcData[startIdx];
  const tg = srcData[startIdx + 1];
  const tb = srcData[startIdx + 2];

  function matches(idx: number): boolean {
    return colorDistance(srcData[idx], srcData[idx + 1], srcData[idx + 2], tr, tg, tb) <= tolerance;
  }

  if (!contiguous) {
    for (let i = 0; i < srcData.length; i += 4) {
      if (matches(i)) {
        mData[i] = 255;
        mData[i + 1] = 255;
        mData[i + 2] = 255;
        mData[i + 3] = 255;
      }
    }
  } else {
    const visited = new Uint8Array(width * height);
    const queue: number[] = [startX, startY];

    while (queue.length > 0) {
      const cy = queue.pop()!;
      const cx = queue.pop()!;
      const coord = cy * width + cx;
      if (visited[coord]) continue;
      visited[coord] = 1;

      const idx = coord * 4;
      if (!matches(idx)) continue;

      mData[idx] = 255;
      mData[idx + 1] = 255;
      mData[idx + 2] = 255;
      mData[idx + 3] = 255;

      if (cx > 0 && !visited[coord - 1]) queue.push(cx - 1, cy);
      if (cx < width - 1 && !visited[coord + 1]) queue.push(cx + 1, cy);
      if (cy > 0 && !visited[coord - width]) queue.push(cx, cy - 1);
      if (cy < height - 1 && !visited[coord + width]) queue.push(cx, cy + 1);
    }
  }

  mCtx.putImageData(maskImg, 0, 0);
  return maskCanvas;
}
