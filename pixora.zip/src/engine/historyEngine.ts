/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { DocumentState, HistoryStep, Layer } from '../types';

const MAX_HISTORY_STEPS = 30;

// Capture current document state as a history snapshot
export function createHistorySnapshot(doc: DocumentState, actionName: string): HistoryStep {
  const layersSnapshot = doc.layers.map((layer) => ({
    id: layer.id,
    name: layer.name,
    type: layer.type,
    visible: layer.visible,
    locked: layer.locked,
    opacity: layer.opacity,
    blendMode: layer.blendMode,
    x: layer.x,
    y: layer.y,
    width: layer.width,
    height: layer.height,
    dataUrl: layer.canvas.toDataURL(),
    maskDataUrl: layer.maskCanvas ? layer.maskCanvas.toDataURL() : undefined,
    textData: layer.textData ? { ...layer.textData } : undefined,
    shapeData: layer.shapeData ? { ...layer.shapeData } : undefined,
    adjustmentData: layer.adjustmentData ? { ...layer.adjustmentData } : undefined,
    effects: layer.effects ? JSON.parse(JSON.stringify(layer.effects)) : undefined,
  }));

  return {
    id: 'hist_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
    name: actionName,
    timestamp: Date.now(),
    layersSnapshot,
    activeLayerId: doc.activeLayerId,
    width: doc.width,
    height: doc.height,
  };
}

// Push a new step to history, truncating any redo forward history, pruning to MAX_HISTORY_STEPS
export function pushHistoryStep(doc: DocumentState, actionName: string): DocumentState {
  const step = createHistorySnapshot(doc, actionName);
  const truncated = doc.history.slice(0, doc.historyIndex + 1);
  truncated.push(step);

  let finalHistory = truncated;
  if (finalHistory.length > MAX_HISTORY_STEPS) {
    finalHistory = finalHistory.slice(finalHistory.length - MAX_HISTORY_STEPS);
  }

  return {
    ...doc,
    history: finalHistory,
    historyIndex: finalHistory.length - 1,
  };
}

// Restore document state from a history snapshot
export async function restoreHistoryStep(
  doc: DocumentState,
  targetIndex: number
): Promise<DocumentState> {
  if (targetIndex < 0 || targetIndex >= doc.history.length) return doc;
  const snapshot = doc.history[targetIndex];

  // Reconstruct layers asynchronously
  const restoredLayers: Layer[] = await Promise.all(
    snapshot.layersSnapshot.map(async (lSnap) => {
      const canvas = document.createElement('canvas');
      canvas.width = lSnap.width;
      canvas.height = lSnap.height;
      const ctx = canvas.getContext('2d');

      if (ctx && lSnap.dataUrl) {
        await new Promise<void>((resolve) => {
          const img = new Image();
          img.onload = () => {
            ctx.drawImage(img, 0, 0);
            resolve();
          };
          img.onerror = () => resolve();
          img.src = lSnap.dataUrl;
        });
      }

      let maskCanvas: HTMLCanvasElement | undefined;
      if (lSnap.maskDataUrl) {
        maskCanvas = document.createElement('canvas');
        maskCanvas.width = lSnap.width;
        maskCanvas.height = lSnap.height;
        const mCtx = maskCanvas.getContext('2d');
        if (mCtx) {
          await new Promise<void>((resolve) => {
            const mImg = new Image();
            mImg.onload = () => {
              mCtx.drawImage(mImg, 0, 0);
              resolve();
            };
            mImg.onerror = () => resolve();
            mImg.src = lSnap.maskDataUrl!;
          });
        }
      }

      const layer: Layer = {
        id: lSnap.id,
        name: lSnap.name,
        type: lSnap.type,
        visible: lSnap.visible,
        locked: lSnap.locked,
        opacity: lSnap.opacity,
        fillOpacity: 1,
        blendMode: lSnap.blendMode,
        x: lSnap.x,
        y: lSnap.y,
        width: lSnap.width,
        height: lSnap.height,
        canvas,
        maskCanvas,
        maskEnabled: !!maskCanvas,
        maskInverted: false,
        maskLinked: true,
        maskDensity: 1,
        maskFeather: 0,
        textData: lSnap.textData,
        shapeData: lSnap.shapeData,
        adjustmentData: lSnap.adjustmentData,
        effects: lSnap.effects,
      };

      return layer;
    })
  );

  return {
    ...doc,
    width: snapshot.width,
    height: snapshot.height,
    layers: restoredLayers,
    activeLayerId: snapshot.activeLayerId,
    historyIndex: targetIndex,
  };
}
