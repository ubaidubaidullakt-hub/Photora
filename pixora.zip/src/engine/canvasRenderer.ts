/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { getCompositeOperation } from './blendModes';
import { DocumentState, Layer, SelectionMask } from '../types';

// Render a text layer onto its internal canvas
export function renderTextLayer(layer: Layer): void {
  if (layer.type !== 'text' || !layer.textData) return;
  const ctx = layer.canvas.getContext('2d');
  if (!ctx) return;
  const t = layer.textData;

  ctx.clearRect(0, 0, layer.canvas.width, layer.canvas.height);
  ctx.save();
  ctx.fillStyle = t.color;
  ctx.font = `${t.italic ? 'italic ' : ''}${t.bold ? 'bold ' : ''}${t.fontSize}px ${t.fontFamily}`;
  ctx.textAlign = t.align;
  ctx.textBaseline = 'top';

  const lines = t.text.split('\n');
  const lineHeight = t.fontSize * (t.lineHeight || 1.2);
  let startX = 0;
  if (t.align === 'center') startX = layer.canvas.width / 2;
  if (t.align === 'right') startX = layer.canvas.width;

  lines.forEach((line, index) => {
    ctx.fillText(line, startX, index * lineHeight);
    if (t.underline) {
      const textMetrics = ctx.measureText(line);
      const textWidth = textMetrics.width;
      let lineX = startX;
      if (t.align === 'center') lineX = startX - textWidth / 2;
      if (t.align === 'right') lineX = startX - textWidth;
      ctx.fillRect(lineX, index * lineHeight + t.fontSize + 2, textWidth, Math.max(1, t.fontSize / 15));
    }
  });

  ctx.restore();
}

// Render a shape layer onto its internal canvas
export function renderShapeLayer(layer: Layer): void {
  if (layer.type !== 'shape' || !layer.shapeData) return;
  const ctx = layer.canvas.getContext('2d');
  if (!ctx) return;
  const s = layer.shapeData;
  const w = layer.canvas.width;
  const h = layer.canvas.height;

  ctx.clearRect(0, 0, w, h);
  ctx.save();
  ctx.fillStyle = s.fillColor;
  ctx.strokeStyle = s.strokeColor;
  ctx.lineWidth = s.strokeWidth;

  const inset = s.strokeWidth / 2;
  const drawW = Math.max(0, w - s.strokeWidth);
  const drawH = Math.max(0, h - s.strokeWidth);

  switch (s.shapeType) {
    case 'rect': {
      if (s.fillColor && s.fillColor !== 'transparent') {
        ctx.fillRect(inset, inset, drawW, drawH);
      }
      if (s.strokeWidth > 0 && s.strokeColor !== 'transparent') {
        ctx.strokeRect(inset, inset, drawW, drawH);
      }
      break;
    }

    case 'rounded-rect': {
      const r = Math.min(drawW / 2, drawH / 2, s.cornerRadius || 12);
      ctx.beginPath();
      ctx.roundRect(inset, inset, drawW, drawH, r);
      if (s.fillColor && s.fillColor !== 'transparent') ctx.fill();
      if (s.strokeWidth > 0 && s.strokeColor !== 'transparent') ctx.stroke();
      break;
    }

    case 'ellipse': {
      ctx.beginPath();
      ctx.ellipse(w / 2, h / 2, Math.max(1, drawW / 2), Math.max(1, drawH / 2), 0, 0, Math.PI * 2);
      if (s.fillColor && s.fillColor !== 'transparent') ctx.fill();
      if (s.strokeWidth > 0 && s.strokeColor !== 'transparent') ctx.stroke();
      break;
    }

    case 'polygon': {
      const sides = Math.max(3, s.polygonSides || 5);
      const cx = w / 2;
      const cy = h / 2;
      const radius = Math.min(drawW / 2, drawH / 2);
      ctx.beginPath();
      for (let i = 0; i < sides; i++) {
        const angle = (i * 2 * Math.PI) / sides - Math.PI / 2;
        const px = cx + radius * Math.cos(angle);
        const py = cy + radius * Math.sin(angle);
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      if (s.fillColor && s.fillColor !== 'transparent') ctx.fill();
      if (s.strokeWidth > 0 && s.strokeColor !== 'transparent') ctx.stroke();
      break;
    }

    case 'line': {
      ctx.beginPath();
      ctx.moveTo(inset, inset);
      ctx.lineTo(w - inset, h - inset);
      ctx.stroke();
      break;
    }

    case 'path': {
      if (s.points && s.points.length > 0) {
        ctx.beginPath();
        ctx.moveTo(s.points[0].x, s.points[0].y);
        for (let i = 1; i < s.points.length; i++) {
          const pt = s.points[i];
          const prev = s.points[i - 1];
          if (prev.handleOut && pt.handleIn) {
            ctx.bezierCurveTo(prev.handleOut.x, prev.handleOut.y, pt.handleIn.x, pt.handleIn.y, pt.x, pt.y);
          } else {
            ctx.lineTo(pt.x, pt.y);
          }
        }
        if (s.closed) ctx.closePath();
        if (s.fillColor && s.fillColor !== 'transparent') ctx.fill();
        if (s.strokeWidth > 0 && s.strokeColor !== 'transparent') ctx.stroke();
      }
      break;
    }
  }

  ctx.restore();
}

// Composite the full document (all visible layers) onto a destination canvas
export function compositeDocumentToCanvas(
  doc: DocumentState,
  targetCanvas: HTMLCanvasElement,
  includeBackgroundPattern = false
): void {
  targetCanvas.width = doc.width;
  targetCanvas.height = doc.height;
  const ctx = targetCanvas.getContext('2d');
  if (!ctx) return;

  ctx.clearRect(0, 0, doc.width, doc.height);

  if (includeBackgroundPattern) {
    // Fill white or default if desired, otherwise transparent
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, doc.width, doc.height);
  }

  // Iterate layers from bottom (index 0) to top (last index)
  for (const layer of doc.layers) {
    if (!layer.visible) continue;

    // Refresh dynamic layers if necessary
    if (layer.type === 'text') renderTextLayer(layer);
    if (layer.type === 'shape') renderShapeLayer(layer);

    // Prepare layer buffer with mask if active
    let layerImageSource: CanvasImageSource = layer.canvas;

    if (layer.maskCanvas && layer.maskEnabled) {
      // Create temporary masked buffer
      const maskedBuffer = document.createElement('canvas');
      maskedBuffer.width = layer.canvas.width;
      maskedBuffer.height = layer.canvas.height;
      const mCtx = maskedBuffer.getContext('2d');
      if (mCtx) {
        mCtx.drawImage(layer.canvas, 0, 0);
        mCtx.globalCompositeOperation = 'destination-in';
        mCtx.globalAlpha = layer.maskDensity;
        if (layer.maskFeather > 0) {
          mCtx.filter = `blur(${layer.maskFeather}px)`;
        }
        mCtx.drawImage(layer.maskCanvas, 0, 0);
        mCtx.filter = 'none';
        layerImageSource = maskedBuffer;
      }
    }

    ctx.save();
    ctx.globalAlpha = layer.opacity * (layer.fillOpacity ?? 1);
    ctx.globalCompositeOperation = getCompositeOperation(layer.blendMode);

    // Render Drop Shadow Layer Effect if enabled
    if (layer.effects?.dropShadow?.enabled) {
      const ds = layer.effects.dropShadow;
      ctx.save();
      const rad = (ds.angle * Math.PI) / 180;
      ctx.shadowOffsetX = Math.cos(rad) * ds.distance;
      ctx.shadowOffsetY = Math.sin(rad) * ds.distance;
      ctx.shadowBlur = ds.blur;
      ctx.shadowColor = ds.color;
      ctx.drawImage(layerImageSource, layer.x, layer.y);
      ctx.restore();
    }

    // Render Layer Image
    ctx.drawImage(layerImageSource, layer.x, layer.y);

    // Render Color Overlay Effect if enabled
    if (layer.effects?.colorOverlay?.enabled) {
      const co = layer.effects.colorOverlay;
      ctx.save();
      ctx.globalCompositeOperation = 'source-atop';
      ctx.fillStyle = co.color;
      ctx.globalAlpha = co.opacity;
      ctx.fillRect(layer.x, layer.y, layer.width, layer.height);
      ctx.restore();
    }

    ctx.restore();
  }
}

// Generate thumbnail for a layer (used in the Layers Panel)
export function generateLayerThumbnail(layer: Layer, size = 48): string {
  const thumbCanvas = document.createElement('canvas');
  thumbCanvas.width = size;
  thumbCanvas.height = size;
  const ctx = thumbCanvas.getContext('2d');
  if (!ctx) return '';

  // Draw checkerboard
  ctx.fillStyle = '#262626';
  ctx.fillRect(0, 0, size, size);
  ctx.fillStyle = '#1c1c1c';
  const sq = size / 4;
  for (let y = 0; y < size; y += sq * 2) {
    for (let x = 0; x < size; x += sq * 2) {
      ctx.fillRect(x, y, sq, sq);
      ctx.fillRect(x + sq, y + sq, sq, sq);
    }
  }

  // Draw scaled layer
  if (layer.canvas && layer.canvas.width > 0 && layer.canvas.height > 0) {
    const scale = Math.min(size / layer.canvas.width, size / layer.canvas.height);
    const dw = layer.canvas.width * scale;
    const dh = layer.canvas.height * scale;
    const dx = (size - dw) / 2;
    const dy = (size - dh) / 2;
    ctx.drawImage(layer.canvas, dx, dy, dw, dh);
  }

  return thumbCanvas.toDataURL();
}

// Draw Marching Ants selection outline on the workspace overlay canvas
export function drawSelectionOverlay(
  ctx: CanvasRenderingContext2D,
  selection: SelectionMask,
  dashOffset = 0
): void {
  if (!selection.active || !selection.maskCanvas) return;
  const width = selection.maskCanvas.width;
  const height = selection.maskCanvas.height;
  const sCtx = selection.maskCanvas.getContext('2d');
  if (!sCtx) return;

  // Render edge contour
  ctx.save();
  ctx.lineWidth = 1;
  ctx.setLineDash([4, 4]);

  // First black dash, then offset white dash for high visibility over any background
  ctx.lineDashOffset = dashOffset;
  ctx.strokeStyle = '#000000';
  ctx.strokeRect(
    selection.bounds?.x ?? 0,
    selection.bounds?.y ?? 0,
    selection.bounds?.width ?? width,
    selection.bounds?.height ?? height
  );

  ctx.strokeStyle = '#ffffff';
  ctx.lineDashOffset = dashOffset + 4;
  ctx.strokeRect(
    selection.bounds?.x ?? 0,
    selection.bounds?.y ?? 0,
    selection.bounds?.width ?? width,
    selection.bounds?.height ?? height
  );

  ctx.restore();
}

// Draw Photoshop transform bounding box with 8 handles + rotation anchor
export function drawTransformBoundingBox(
  ctx: CanvasRenderingContext2D,
  box: { x: number; y: number; width: number; height: number },
  zoom: number
): void {
  ctx.save();
  ctx.strokeStyle = '#38bdf8'; // Photoshop blue
  ctx.lineWidth = 1.5;
  ctx.strokeRect(box.x, box.y, box.width, box.height);

  // 8 handles (corners + midpoints)
  const hSize = Math.max(6, 8 / zoom);
  const half = hSize / 2;

  const points = [
    { x: box.x, y: box.y }, // Top-Left
    { x: box.x + box.width / 2, y: box.y }, // Top-Mid
    { x: box.x + box.width, y: box.y }, // Top-Right
    { x: box.x + box.width, y: box.y + box.height / 2 }, // Right-Mid
    { x: box.x + box.width, y: box.y + box.height }, // Bottom-Right
    { x: box.x + box.width / 2, y: box.y + box.height }, // Bottom-Mid
    { x: box.x, y: box.y + box.height }, // Bottom-Left
    { x: box.x, y: box.y + box.height / 2 }, // Left-Mid
  ];

  ctx.fillStyle = '#ffffff';
  ctx.strokeStyle = '#0284c7';
  ctx.lineWidth = 1;

  for (const pt of points) {
    ctx.fillRect(pt.x - half, pt.y - half, hSize, hSize);
    ctx.strokeRect(pt.x - half, pt.y - half, hSize, hSize);
  }

  // Center pivot point
  const cx = box.x + box.width / 2;
  const cy = box.y + box.height / 2;
  ctx.beginPath();
  ctx.arc(cx, cy, 3 / zoom, 0, Math.PI * 2);
  ctx.stroke();

  ctx.restore();
}
