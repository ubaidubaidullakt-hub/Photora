/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { SelectionMask } from '../types';

export function createEmptySelectionMask(width: number, height: number): SelectionMask {
  const maskCanvas = document.createElement('canvas');
  maskCanvas.width = width;
  maskCanvas.height = height;
  return {
    active: false,
    maskCanvas,
  };
}

// Select All (fills mask with opaque white)
export function createSelectAllMask(width: number, height: number): SelectionMask {
  const maskCanvas = document.createElement('canvas');
  maskCanvas.width = width;
  maskCanvas.height = height;
  const ctx = maskCanvas.getContext('2d');
  if (ctx) {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, width, height);
  }
  return {
    active: true,
    maskCanvas,
    bounds: { x: 0, y: 0, width, height },
  };
}

// Rectangular Marquee
export function createRectSelectionMask(
  width: number,
  height: number,
  rect: { x: number; y: number; width: number; height: number },
  feather = 0
): SelectionMask {
  const maskCanvas = document.createElement('canvas');
  maskCanvas.width = width;
  maskCanvas.height = height;
  const ctx = maskCanvas.getContext('2d');
  if (!ctx) return { active: false, maskCanvas };

  const x = Math.min(rect.x, rect.x + rect.width);
  const y = Math.min(rect.y, rect.y + rect.height);
  const w = Math.abs(rect.width);
  const h = Math.abs(rect.height);

  ctx.fillStyle = '#ffffff';
  if (feather > 0) {
    ctx.filter = `blur(${feather}px)`;
  }
  ctx.fillRect(x, y, w, h);
  ctx.filter = 'none';

  return {
    active: true,
    maskCanvas,
    bounds: { x, y, width: w, height: h },
  };
}

// Elliptical Marquee
export function createEllipseSelectionMask(
  width: number,
  height: number,
  rect: { x: number; y: number; width: number; height: number },
  feather = 0
): SelectionMask {
  const maskCanvas = document.createElement('canvas');
  maskCanvas.width = width;
  maskCanvas.height = height;
  const ctx = maskCanvas.getContext('2d');
  if (!ctx) return { active: false, maskCanvas };

  const x = Math.min(rect.x, rect.x + rect.width);
  const y = Math.min(rect.y, rect.y + rect.height);
  const w = Math.abs(rect.width);
  const h = Math.abs(rect.height);
  const cx = x + w / 2;
  const cy = y + h / 2;

  ctx.fillStyle = '#ffffff';
  if (feather > 0) {
    ctx.filter = `blur(${feather}px)`;
  }
  ctx.beginPath();
  ctx.ellipse(cx, cy, Math.max(1, w / 2), Math.max(1, h / 2), 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.filter = 'none';

  return {
    active: true,
    maskCanvas,
    bounds: { x, y, width: w, height: h },
  };
}

// Polygon / Freehand Lasso Mask
export function createPolygonSelectionMask(
  width: number,
  height: number,
  points: { x: number; y: number }[],
  feather = 0
): SelectionMask {
  const maskCanvas = document.createElement('canvas');
  maskCanvas.width = width;
  maskCanvas.height = height;
  const ctx = maskCanvas.getContext('2d');
  if (!ctx || points.length < 3) return { active: false, maskCanvas };

  ctx.fillStyle = '#ffffff';
  if (feather > 0) {
    ctx.filter = `blur(${feather}px)`;
  }
  ctx.beginPath();
  ctx.moveTo(points[0].x, points[0].y);
  for (let i = 1; i < points.length; i++) {
    ctx.lineTo(points[i].x, points[i].y);
  }
  ctx.closePath();
  ctx.fill();
  ctx.filter = 'none';

  return {
    active: true,
    maskCanvas,
  };
}

// Invert Selection
export function invertSelectionMask(selection: SelectionMask): SelectionMask {
  const width = selection.maskCanvas.width;
  const height = selection.maskCanvas.height;
  const newCanvas = document.createElement('canvas');
  newCanvas.width = width;
  newCanvas.height = height;
  const ctx = newCanvas.getContext('2d');
  if (!ctx) return selection;

  ctx.drawImage(selection.maskCanvas, 0, 0);
  const imgData = ctx.getImageData(0, 0, width, height);
  const data = imgData.data;

  for (let i = 0; i < data.length; i += 4) {
    const val = 255 - data[i];
    data[i] = val;
    data[i + 1] = val;
    data[i + 2] = val;
    data[i + 3] = val > 0 ? 255 : 0;
  }
  ctx.putImageData(imgData, 0, 0);

  return {
    active: true,
    maskCanvas: newCanvas,
  };
}

// Expand or Contract Selection
export function expandContractSelection(
  selection: SelectionMask,
  pixels: number
): SelectionMask {
  if (pixels === 0 || !selection.active) return selection;
  const width = selection.maskCanvas.width;
  const height = selection.maskCanvas.height;
  const srcCtx = selection.maskCanvas.getContext('2d');
  const targetCanvas = document.createElement('canvas');
  targetCanvas.width = width;
  targetCanvas.height = height;
  const targetCtx = targetCanvas.getContext('2d');
  if (!srcCtx || !targetCtx) return selection;

  const srcData = srcCtx.getImageData(0, 0, width, height).data;
  const outImg = targetCtx.createImageData(width, height);
  const outData = outImg.data;
  const radius = Math.abs(pixels);
  const isExpand = pixels > 0;

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      let matched = !isExpand;
      for (let dy = -radius; dy <= radius && !matched; dy++) {
        for (let dx = -radius; dx <= radius; dx++) {
          if (dx * dx + dy * dy <= radius * radius) {
            const px = Math.min(width - 1, Math.max(0, x + dx));
            const py = Math.min(height - 1, Math.max(0, y + dy));
            const val = srcData[(py * width + px) * 4];
            if (isExpand && val > 128) {
              matched = true;
              break;
            } else if (!isExpand && val <= 128) {
              matched = true;
              break;
            }
          }
        }
      }

      const outVal = isExpand ? (matched ? 255 : 0) : matched ? 0 : 255;
      const idx = (y * width + x) * 4;
      outData[idx] = outVal;
      outData[idx + 1] = outVal;
      outData[idx + 2] = outVal;
      outData[idx + 3] = outVal;
    }
  }

  targetCtx.putImageData(outImg, 0, 0);
  return {
    active: true,
    maskCanvas: targetCanvas,
  };
}

// Check if pixel (x, y) is inside selection mask
export function isPointSelected(
  selection: SelectionMask | null,
  x: number,
  y: number
): boolean {
  if (!selection || !selection.active) return true;
  const ctx = selection.maskCanvas.getContext('2d');
  if (!ctx) return true;
  x = Math.floor(x);
  y = Math.floor(y);
  if (x < 0 || x >= selection.maskCanvas.width || y < 0 || y >= selection.maskCanvas.height) {
    return false;
  }
  const pixel = ctx.getImageData(x, y, 1, 1).data;
  return pixel[0] > 128;
}
