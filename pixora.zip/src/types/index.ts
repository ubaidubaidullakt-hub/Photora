/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type BlendMode =
  | 'normal'
  | 'multiply'
  | 'screen'
  | 'overlay'
  | 'darken'
  | 'lighten'
  | 'color-dodge'
  | 'color-burn'
  | 'hard-light'
  | 'soft-light'
  | 'difference'
  | 'exclusion'
  | 'hue'
  | 'saturation'
  | 'color'
  | 'luminosity';

export type ToolType =
  // Navigation
  | 'move'
  | 'hand'
  | 'zoom'
  | 'rotateView'
  // Selection
  | 'rectMarquee'
  | 'ellipseMarquee'
  | 'lasso'
  | 'polygonalLasso'
  | 'magicWand'
  | 'quickSelect'
  | 'colorRange'
  // Crop & Slice
  | 'crop'
  | 'perspectiveCrop'
  // Retouching
  | 'cloneStamp'
  | 'healingBrush'
  | 'spotHealing'
  | 'patch'
  | 'blur'
  | 'sharpen'
  | 'smudge'
  | 'dodge'
  | 'burn'
  | 'sponge'
  | 'redEye'
  // Painting
  | 'brush'
  | 'pencil'
  | 'airbrush'
  | 'eraser'
  | 'backgroundEraser'
  | 'magicEraser'
  | 'colorReplacement'
  // Fill & Gradient
  | 'bucket'
  | 'gradient'
  // Vector & Shapes
  | 'pen'
  | 'freeformPen'
  | 'shapeRect'
  | 'shapeRoundedRect'
  | 'shapeEllipse'
  | 'shapePolygon'
  | 'shapeLine'
  // Text
  | 'textHorizontal'
  | 'textVertical'
  // Sampler
  | 'eyedropper'
  | 'colorSampler';

export interface GradientStop {
  offset: number; // 0 to 1
  color: string;
}

export interface GradientOpacityStop {
  offset: number; // 0 to 1
  opacity: number; // 0 to 1
}

export type GradientType = 'linear' | 'radial' | 'angle' | 'reflected' | 'diamond';

export interface GradientConfig {
  type: GradientType;
  colorStops: GradientStop[];
  opacityStops: GradientOpacityStop[];
  reverse: boolean;
}

export interface PathPoint {
  x: number;
  y: number;
  handleIn?: { x: number; y: number };
  handleOut?: { x: number; y: number };
}

export interface VectorShapeData {
  shapeType: 'rect' | 'rounded-rect' | 'ellipse' | 'polygon' | 'line' | 'path';
  fillColor: string;
  strokeColor: string;
  strokeWidth: number;
  cornerRadius?: number;
  polygonSides?: number;
  points?: PathPoint[];
  closed?: boolean;
}

export interface TextLayerData {
  text: string;
  fontFamily: string;
  fontSize: number;
  color: string;
  align: 'left' | 'center' | 'right';
  bold: boolean;
  italic: boolean;
  underline: boolean;
  lineHeight: number;
  letterSpacing: number;
  isVertical?: boolean;
}

export interface AdjustmentSettings {
  type:
    | 'brightnessContrast'
    | 'levels'
    | 'curves'
    | 'hueSaturation'
    | 'vibrance'
    | 'colorBalance'
    | 'temperatureTint'
    | 'blackAndWhite'
    | 'invert'
    | 'threshold'
    | 'posterize'
    | 'photoFilter'
    | 'gradientMap'
    | 'shadowsHighlights'
    | 'desaturate';
  brightness?: number; // -100 to 100
  contrast?: number; // -100 to 100
  exposure?: number; // -5 to 5
  levels?: {
    inBlack: number; // 0 to 255
    inWhite: number; // 0 to 255
    gamma: number; // 0.1 to 10
    outBlack: number; // 0 to 255
    outWhite: number; // 0 to 255
  };
  curves?: { x: number; y: number }[]; // 0-255 control points
  hue?: number; // -180 to 180
  saturation?: number; // -100 to 100
  lightness?: number; // -100 to 100
  vibrance?: number; // -100 to 100
  colorBalance?: {
    cyanRed: number; // -100 to 100
    magentaGreen: number; // -100 to 100
    yellowBlue: number; // -100 to 100
  };
  temperature?: number; // -100 to 100
  tint?: number; // -100 to 100
  threshold?: number; // 1 to 255
  posterize?: number; // 2 to 64
  photoFilter?: {
    color: string;
    density: number; // 0 to 100
  };
}

export interface LayerEffects {
  dropShadow?: {
    enabled: boolean;
    color: string;
    opacity: number; // 0 to 1
    angle: number; // 0 to 360
    distance: number;
    blur: number;
    spread: number;
  };
  innerShadow?: {
    enabled: boolean;
    color: string;
    opacity: number;
    angle: number;
    distance: number;
    blur: number;
  };
  outerGlow?: {
    enabled: boolean;
    color: string;
    opacity: number;
    blur: number;
  };
  innerGlow?: {
    enabled: boolean;
    color: string;
    opacity: number;
    blur: number;
  };
  stroke?: {
    enabled: boolean;
    color: string;
    width: number;
    position: 'outside' | 'inside' | 'center';
  };
  colorOverlay?: {
    enabled: boolean;
    color: string;
    opacity: number;
  };
}

export interface Layer {
  id: string;
  name: string;
  type: 'pixel' | 'text' | 'shape' | 'adjustment' | 'group';
  visible: boolean;
  locked: boolean;
  opacity: number; // 0 to 1
  fillOpacity: number; // 0 to 1
  blendMode: BlendMode;
  x: number;
  y: number;
  width: number;
  height: number;
  canvas: HTMLCanvasElement;
  maskCanvas?: HTMLCanvasElement;
  maskEnabled: boolean;
  maskInverted: boolean;
  maskLinked: boolean;
  maskDensity: number; // 0 to 1
  maskFeather: number; // 0 to 50px
  textData?: TextLayerData;
  shapeData?: VectorShapeData;
  adjustmentData?: AdjustmentSettings;
  effects?: LayerEffects;
  isBackground?: boolean;
  parentId?: string;
  collapsed?: boolean;
  editingTarget?: 'layer' | 'mask'; // which thumbnail is active for painting
}

export interface SelectionMask {
  active: boolean;
  maskCanvas: HTMLCanvasElement;
  bounds?: { x: number; y: number; width: number; height: number };
}

export interface Guide {
  id: string;
  orientation: 'horizontal' | 'vertical';
  position: number;
}

export interface HistoryStep {
  id: string;
  name: string;
  timestamp: number;
  layersSnapshot: {
    id: string;
    name: string;
    type: Layer['type'];
    visible: boolean;
    locked: boolean;
    opacity: number;
    blendMode: BlendMode;
    x: number;
    y: number;
    width: number;
    height: number;
    dataUrl: string;
    maskDataUrl?: string;
    textData?: TextLayerData;
    shapeData?: VectorShapeData;
    adjustmentData?: AdjustmentSettings;
    effects?: LayerEffects;
  }[];
  activeLayerId: string;
  width: number;
  height: number;
}

export interface TimelineFrame {
  id: string;
  duration: number; // seconds
  layerStates: {
    [layerId: string]: {
      visible: boolean;
      opacity: number;
    };
  };
}

export interface DocumentState {
  id: string;
  name: string;
  width: number;
  height: number;
  resolution: number; // DPI, default 72 or 300
  colorMode: 'RGB';
  layers: Layer[];
  activeLayerId: string;
  selection: SelectionMask | null;
  history: HistoryStep[];
  historyIndex: number;
  zoom: number;
  pan: { x: number; y: number };
  rotation: number;
  guides: Guide[];
  rulersVisible: boolean;
  gridVisible: boolean;
  snapToGrid: boolean;
  snapToGuides: boolean;
  frames: TimelineFrame[];
  activeFrameIndex: number;
  isPlayingTimeline: boolean;
}

export interface ToolSettings {
  brushSize: number;
  brushHardness: number; // 0 (soft) to 1 (hard)
  brushOpacity: number; // 0 to 1
  brushFlow: number; // 0 to 1
  brushSpacing: number; // 0.1 to 1
  tolerance: number; // 0 to 255 for wand/bucket
  contiguous: boolean;
  sampleAllLayers: boolean;
  feather: number;
  antiAlias: boolean;
  cropPreset: string;
  gradient: GradientConfig;
  activeColor: string; // foreground
  backgroundColor: string; // background
  cloneSource: { x: number; y: number; layerId?: string } | null;
  eraserSize: number;
  eraserOpacity: number;
  retouchMode: 'normal' | 'shadows' | 'midtones' | 'highlights';
  retouchExposure: number; // 0 to 1
}

export type ActiveModal =
  | null
  | 'newDoc'
  | 'openImage'
  | 'export'
  | 'adjustments'
  | 'filters'
  | 'layerStyles'
  | 'gradientEditor'
  | 'shortcuts'
  | 'projectZip'
  | 'automatedTests'
  | 'imageSize'
  | 'canvasSize'
  | 'colorRange'
  | 'saveSelection'
  | 'loadSelection';
