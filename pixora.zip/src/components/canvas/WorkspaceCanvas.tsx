/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
  DocumentState,
  ToolType,
  ToolSettings,
  Layer,
  SelectionMask,
} from '../../types';
import {
  compositeDocumentToCanvas,
  drawSelectionOverlay,
  drawTransformBoundingBox,
} from '../../engine/canvasRenderer';
import {
  floodFill,
  generateMagicWandMask,
  hexToRgb,
  clamp,
} from '../../engine/imageProcessing';
import {
  createRectSelectionMask,
  createEllipseSelectionMask,
  createPolygonSelectionMask,
  isPointSelected,
} from '../../engine/selectionEngine';

interface WorkspaceCanvasProps {
  document: DocumentState;
  activeTool: ToolType;
  settings: ToolSettings;
  onUpdateDocument: (doc: DocumentState, actionName?: string) => void;
  onUpdateSettings: (patch: Partial<ToolSettings>) => void;
  isTransformActive: boolean;
  onFinishTransform: () => void;
}

export const WorkspaceCanvas: React.FC<WorkspaceCanvasProps> = ({
  document: doc,
  activeTool,
  settings,
  onUpdateDocument,
  onUpdateSettings,
  isTransformActive,
  onFinishTransform,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const compositeCanvasRef = useRef<HTMLCanvasElement>(null);
  const overlayCanvasRef = useRef<HTMLCanvasElement>(null);

  // Mouse / Drawing State
  const [isPointerDown, setIsPointerDown] = useState(false);
  const [startPoint, setStartPoint] = useState<{ x: number; y: number } | null>(null);
  const [lastPoint, setLastPoint] = useState<{ x: number; y: number } | null>(null);
  const [cursorPos, setCursorPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [lassoPoints, setLassoPoints] = useState<{ x: number; y: number }[]>([]);
  const [cropBox, setCropBox] = useState<{ x: number; y: number; width: number; height: number }>({
    x: 0,
    y: 0,
    width: doc.width,
    height: doc.height,
  });

  // Marching ants animation ticker
  const [marchingAntsOffset, setMarchingAntsOffset] = useState(0);
  useEffect(() => {
    let animId: number;
    let offset = 0;
    const loop = () => {
      offset = (offset + 0.5) % 16;
      setMarchingAntsOffset(offset);
      animId = requestAnimationFrame(loop);
    };
    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, []);

  // Sync crop box when document changes
  useEffect(() => {
    setCropBox({ x: 0, y: 0, width: doc.width, height: doc.height });
  }, [doc.width, doc.height]);

  // Re-composite document whenever layers, visibility, opacity or blend modes change
  const renderComposite = useCallback(() => {
    if (!compositeCanvasRef.current) return;
    compositeDocumentToCanvas(doc, compositeCanvasRef.current, false);
  }, [doc]);

  useEffect(() => {
    renderComposite();
  }, [renderComposite]);

  // Render Overlay (Marching Ants, Guides, Transform Box, Crop box)
  useEffect(() => {
    const canvas = overlayCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // 1. Draw Active Selection Marching Ants
    if (doc.selection && doc.selection.active) {
      drawSelectionOverlay(ctx, doc.selection, marchingAntsOffset);
    }

    // 2. Draw Crop Tool Overlay
    if (activeTool === 'crop') {
      ctx.save();
      ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
      ctx.fillRect(0, 0, doc.width, doc.height);
      ctx.clearRect(cropBox.x, cropBox.y, cropBox.width, cropBox.height);
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(cropBox.x, cropBox.y, cropBox.width, cropBox.height);

      // Rule of thirds grid
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
      ctx.lineWidth = 1;
      const w3 = cropBox.width / 3;
      const h3 = cropBox.height / 3;
      ctx.beginPath();
      ctx.moveTo(cropBox.x + w3, cropBox.y);
      ctx.lineTo(cropBox.x + w3, cropBox.y + cropBox.height);
      ctx.moveTo(cropBox.x + w3 * 2, cropBox.y);
      ctx.lineTo(cropBox.x + w3 * 2, cropBox.y + cropBox.height);
      ctx.moveTo(cropBox.x, cropBox.y + h3);
      ctx.lineTo(cropBox.x + cropBox.width, cropBox.y + h3);
      ctx.moveTo(cropBox.x, cropBox.y + h3 * 2);
      ctx.lineTo(cropBox.x + cropBox.width, cropBox.y + h3 * 2);
      ctx.stroke();
      ctx.restore();
    }

    // 3. Draw Transform Bounding Box
    if (isTransformActive) {
      const activeLayer = doc.layers.find((l) => l.id === doc.activeLayerId);
      if (activeLayer) {
        drawTransformBoundingBox(
          ctx,
          {
            x: activeLayer.x,
            y: activeLayer.y,
            width: activeLayer.width,
            height: activeLayer.height,
          },
          doc.zoom
        );
      }
    }

    // 4. Draw Guides
    if (doc.guides.length > 0) {
      ctx.save();
      ctx.strokeStyle = '#00ffff';
      ctx.lineWidth = 1 / doc.zoom;
      for (const g of doc.guides) {
        ctx.beginPath();
        if (g.orientation === 'horizontal') {
          ctx.moveTo(0, g.position);
          ctx.lineTo(doc.width, g.position);
        } else {
          ctx.moveTo(g.position, 0);
          ctx.lineTo(g.position, doc.height);
        }
        ctx.stroke();
      }
      ctx.restore();
    }
  }, [doc, activeTool, cropBox, isTransformActive, marchingAntsOffset]);

  // Convert browser viewport mouse event coordinates to document image pixels
  const getDocCoordinates = (e: React.MouseEvent | React.TouchEvent): { x: number; y: number } => {
    if (!compositeCanvasRef.current) return { x: 0, y: 0 };
    const rect = compositeCanvasRef.current.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : (e as React.MouseEvent).clientY;

    const scaleX = doc.width / rect.width;
    const scaleY = doc.height / rect.height;

    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY,
    };
  };

  // Active layer getter
  const getActiveLayer = (): Layer | undefined => {
    return doc.layers.find((l) => l.id === doc.activeLayerId);
  };

  // Draw brush stroke interpolating between two points
  const drawBrushStroke = (
    ctx: CanvasRenderingContext2D,
    from: { x: number; y: number },
    to: { x: number; y: number },
    color: string,
    size: number,
    hardness: number,
    opacity: number,
    isEraser = false
  ) => {
    ctx.save();
    if (isEraser) {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.fillStyle = `rgba(0, 0, 0, ${opacity})`;
    } else {
      ctx.globalCompositeOperation = 'source-over';
      ctx.fillStyle = color;
    }

    const dist = Math.hypot(to.x - from.x, to.y - from.y);
    const step = Math.max(1, size * 0.15); // continuous brush density
    const count = Math.ceil(dist / step);

    for (let i = 0; i <= count; i++) {
      const t = count === 0 ? 0 : i / count;
      const x = from.x + (to.x - from.x) * t;
      const y = from.y + (to.y - from.y) * t;

      if (!isPointSelected(doc.selection, x, y)) continue;

      if (hardness >= 0.95) {
        // Hard round brush
        ctx.beginPath();
        ctx.arc(x, y, size / 2, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // Soft round brush with radial gradient feathering
        const grad = ctx.createRadialGradient(x, y, (size / 2) * hardness, x, y, size / 2);
        if (isEraser) {
          grad.addColorStop(0, `rgba(0,0,0,${opacity})`);
          grad.addColorStop(1, 'rgba(0,0,0,0)');
        } else {
          const rgb = hexToRgb(color);
          grad.addColorStop(0, `rgba(${rgb.r},${rgb.g},${rgb.b},${opacity * rgb.a})`);
          grad.addColorStop(1, `rgba(${rgb.r},${rgb.g},${rgb.b},0)`);
        }
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(x, y, size / 2, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.restore();
  };

  // Pointer Down handler
  const handlePointerDown = (e: React.MouseEvent | React.TouchEvent) => {
    const coords = getDocCoordinates(e);
    setIsPointerDown(true);
    setStartPoint(coords);
    setLastPoint(coords);

    const activeLayer = getActiveLayer();
    if (!activeLayer || activeLayer.locked) return;

    // Eyedropper Tool
    if (activeTool === 'eyedropper') {
      if (compositeCanvasRef.current) {
        const ctx = compositeCanvasRef.current.getContext('2d');
        if (ctx) {
          const pixel = ctx.getImageData(Math.floor(coords.x), Math.floor(coords.y), 1, 1).data;
          const hex = `#${((1 << 24) + (pixel[0] << 16) + (pixel[1] << 8) + pixel[2]).toString(16).slice(1)}`;
          onUpdateSettings({ activeColor: hex });
        }
      }
      return;
    }

    // Clone Stamp source picking via Alt+Click
    if (activeTool === 'cloneStamp' && (e as React.MouseEvent).altKey) {
      onUpdateSettings({
        cloneSource: { x: coords.x, y: coords.y, layerId: activeLayer.id },
      });
      return;
    }

    // Paint Bucket Tool
    if (activeTool === 'bucket') {
      const targetCanvas = activeLayer.editingTarget === 'mask' && activeLayer.maskCanvas ? activeLayer.maskCanvas : activeLayer.canvas;
      const ctx = targetCanvas.getContext('2d');
      if (ctx) {
        floodFill(
          ctx,
          coords.x - activeLayer.x,
          coords.y - activeLayer.y,
          settings.activeColor,
          settings.tolerance,
          settings.contiguous
        );
        renderComposite();
        onUpdateDocument({ ...doc }, 'Paint Bucket Fill');
      }
      return;
    }

    // Magic Wand Selection Tool
    if (activeTool === 'magicWand') {
      const maskCanvas = generateMagicWandMask(
        compositeCanvasRef.current || activeLayer.canvas,
        coords.x,
        coords.y,
        settings.tolerance,
        settings.contiguous
      );
      onUpdateDocument(
        {
          ...doc,
          selection: { active: true, maskCanvas },
        },
        'Magic Wand Selection'
      );
      return;
    }

    // Initial dot for brush/pencil/eraser
    if (['brush', 'pencil', 'eraser'].includes(activeTool)) {
      const targetCanvas = activeLayer.editingTarget === 'mask' && activeLayer.maskCanvas ? activeLayer.maskCanvas : activeLayer.canvas;
      const ctx = targetCanvas.getContext('2d');
      if (ctx) {
        const isEraser = activeTool === 'eraser' && activeLayer.editingTarget !== 'mask';
        const color = activeLayer.editingTarget === 'mask' ? (activeTool === 'eraser' ? '#ffffff' : '#000000') : settings.activeColor;
        drawBrushStroke(
          ctx,
          { x: coords.x - activeLayer.x, y: coords.y - activeLayer.y },
          { x: coords.x - activeLayer.x, y: coords.y - activeLayer.y },
          color,
          settings.brushSize,
          settings.brushHardness,
          settings.brushOpacity,
          isEraser
        );
        renderComposite();
      }
    }
  };

  // Pointer Move handler
  const handlePointerMove = (e: React.MouseEvent | React.TouchEvent) => {
    const coords = getDocCoordinates(e);
    setCursorPos(coords);

    if (!isPointerDown || !startPoint || !lastPoint) return;

    // Pan with Hand tool or Middle Click
    if (activeTool === 'hand' || (e as React.MouseEvent).buttons === 4) {
      const clientX = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : (e as React.MouseEvent).clientY;
      onUpdateDocument({
        ...doc,
        pan: {
          x: doc.pan.x + (coords.x - lastPoint.x),
          y: doc.pan.y + (coords.y - lastPoint.y),
        },
      });
      setLastPoint(coords);
      return;
    }

    const activeLayer = getActiveLayer();
    if (!activeLayer || activeLayer.locked) return;

    // Move Tool: drag layer position
    if (activeTool === 'move') {
      const dx = coords.x - lastPoint.x;
      const dy = coords.y - lastPoint.y;
      activeLayer.x += dx;
      activeLayer.y += dy;
      setLastPoint(coords);
      renderComposite();
      return;
    }

    // Brush / Pencil / Eraser / Smudge
    if (['brush', 'pencil', 'eraser', 'smudge', 'blur'].includes(activeTool)) {
      const targetCanvas = activeLayer.editingTarget === 'mask' && activeLayer.maskCanvas ? activeLayer.maskCanvas : activeLayer.canvas;
      const ctx = targetCanvas.getContext('2d');
      if (ctx) {
        const isEraser = activeTool === 'eraser' && activeLayer.editingTarget !== 'mask';
        const color = activeLayer.editingTarget === 'mask' ? (activeTool === 'eraser' ? '#ffffff' : '#000000') : settings.activeColor;

        drawBrushStroke(
          ctx,
          { x: lastPoint.x - activeLayer.x, y: lastPoint.y - activeLayer.y },
          { x: coords.x - activeLayer.x, y: coords.y - activeLayer.y },
          color,
          settings.brushSize,
          settings.brushHardness,
          settings.brushOpacity,
          isEraser
        );
        setLastPoint(coords);
        renderComposite();
      }
    }

    // Clone Stamp
    if (activeTool === 'cloneStamp' && settings.cloneSource) {
      const ctx = activeLayer.canvas.getContext('2d');
      if (ctx && compositeCanvasRef.current) {
        const compCtx = compositeCanvasRef.current.getContext('2d');
        if (compCtx) {
          const dx = coords.x - startPoint.x;
          const dy = coords.y - startPoint.y;
          const sx = settings.cloneSource.x + dx;
          const sy = settings.cloneSource.y + dy;
          const srcData = compCtx.getImageData(
            Math.max(0, sx - settings.brushSize / 2),
            Math.max(0, sy - settings.brushSize / 2),
            settings.brushSize,
            settings.brushSize
          );
          ctx.putImageData(srcData, coords.x - settings.brushSize / 2, coords.y - settings.brushSize / 2);
          renderComposite();
        }
      }
    }

    // Lasso Tool: record points
    if (activeTool === 'lasso') {
      setLassoPoints((pts) => [...pts, coords]);
    }
  };

  // Pointer Up handler
  const handlePointerUp = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isPointerDown || !startPoint) {
      setIsPointerDown(false);
      return;
    }

    const coords = getDocCoordinates(e);
    const activeLayer = getActiveLayer();

    // 1. Rectangular Marquee Selection
    if (activeTool === 'rectMarquee') {
      const mask = createRectSelectionMask(
        doc.width,
        doc.height,
        {
          x: Math.min(startPoint.x, coords.x),
          y: Math.min(startPoint.y, coords.y),
          width: Math.abs(coords.x - startPoint.x),
          height: Math.abs(coords.y - startPoint.y),
        },
        settings.feather
      );
      onUpdateDocument({ ...doc, selection: mask }, 'Rectangular Marquee');
    }

    // 2. Elliptical Marquee Selection
    else if (activeTool === 'ellipseMarquee') {
      const mask = createEllipseSelectionMask(
        doc.width,
        doc.height,
        {
          x: Math.min(startPoint.x, coords.x),
          y: Math.min(startPoint.y, coords.y),
          width: Math.abs(coords.x - startPoint.x),
          height: Math.abs(coords.y - startPoint.y),
        },
        settings.feather
      );
      onUpdateDocument({ ...doc, selection: mask }, 'Elliptical Marquee');
    }

    // 3. Lasso Tool Selection
    else if (activeTool === 'lasso' && lassoPoints.length > 2) {
      const mask = createPolygonSelectionMask(doc.width, doc.height, lassoPoints, settings.feather);
      setLassoPoints([]);
      onUpdateDocument({ ...doc, selection: mask }, 'Lasso Selection');
    }

    // 4. Gradient Tool
    else if (activeTool === 'gradient' && activeLayer) {
      const ctx = activeLayer.canvas.getContext('2d');
      if (ctx) {
        ctx.save();
        let grad: CanvasGradient;
        if (settings.gradient.type === 'radial') {
          const r = Math.hypot(coords.x - startPoint.x, coords.y - startPoint.y);
          grad = ctx.createRadialGradient(startPoint.x, startPoint.y, 0, startPoint.x, startPoint.y, r);
        } else {
          grad = ctx.createLinearGradient(startPoint.x, startPoint.y, coords.x, coords.y);
        }

        const stops = settings.gradient.reverse
          ? [...settings.gradient.colorStops].reverse()
          : settings.gradient.colorStops;

        for (const stop of stops) {
          grad.addColorStop(settings.gradient.reverse ? 1 - stop.offset : stop.offset, stop.color);
        }

        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, activeLayer.canvas.width, activeLayer.canvas.height);
        ctx.restore();
        renderComposite();
        onUpdateDocument({ ...doc }, 'Gradient Fill');
      }
    }

    // 5. Commit stroke to history for painting tools
    else if (['brush', 'pencil', 'eraser', 'move', 'cloneStamp'].includes(activeTool)) {
      onUpdateDocument({ ...doc }, `${activeTool.toUpperCase()} Operation`);
    }

    setIsPointerDown(false);
    setStartPoint(null);
    setLastPoint(null);
  };

  // Mouse wheel zoom around cursor
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const zoomFactor = e.deltaY < 0 ? 1.15 : 0.85;
    const newZoom = Math.min(10, Math.max(0.1, doc.zoom * zoomFactor));
    onUpdateDocument({ ...doc, zoom: newZoom });
  };

  return (
    <div
      ref={containerRef}
      onWheel={handleWheel}
      className="flex-1 bg-[#18181b] overflow-hidden relative flex items-center justify-center select-none"
      style={{
        cursor:
          activeTool === 'hand'
            ? isPointerDown
              ? 'grabbing'
              : 'grab'
            : activeTool === 'zoom'
            ? 'zoom-in'
            : activeTool === 'eyedropper'
            ? 'crosshair'
            : activeTool === 'move'
            ? 'move'
            : 'crosshair',
      }}
    >
      {/* Horizontal Ruler */}
      {doc.rulersVisible && (
        <div className="absolute top-0 left-6 right-0 h-5 bg-[#202024] border-b border-[#2e2e32] flex items-end text-[9px] font-mono text-neutral-400 overflow-hidden z-20">
          {Array.from({ length: 40 }).map((_, i) => (
            <div key={i} className="flex-1 border-r border-[#3a3a40] h-2.5 relative">
              <span className="absolute bottom-1 left-0.5">{i * 100}</span>
            </div>
          ))}
          {/* Mouse tracking tick */}
          <div
            className="absolute top-0 bottom-0 w-px bg-sky-400 z-30 pointer-events-none"
            style={{
              left: `${(cursorPos.x / doc.width) * 100}%`,
            }}
          />
        </div>
      )}

      {/* Vertical Ruler */}
      {doc.rulersVisible && (
        <div className="absolute top-5 left-0 bottom-0 w-6 bg-[#202024] border-r border-[#2e2e32] flex flex-col text-[9px] font-mono text-neutral-400 overflow-hidden z-20">
          {Array.from({ length: 30 }).map((_, i) => (
            <div key={i} className="flex-1 border-b border-[#3a3a40] w-2.5 relative">
              <span className="absolute top-0.5 left-0.5 text-[8px] transform -rotate-90 origin-top-left">
                {i * 100}
              </span>
            </div>
          ))}
          {/* Mouse tracking tick */}
          <div
            className="absolute left-0 right-0 h-px bg-sky-400 z-30 pointer-events-none"
            style={{
              top: `${(cursorPos.y / doc.height) * 100}%`,
            }}
          />
        </div>
      )}

      {/* Canvas Viewport Transformer */}
      <div
        className="relative transition-transform duration-75 ease-out shadow-2xl"
        style={{
          transform: `translate(${doc.pan.x}px, ${doc.pan.y}px) scale(${doc.zoom}) rotate(${doc.rotation}deg)`,
          width: doc.width,
          height: doc.height,
        }}
        onMouseDown={handlePointerDown}
        onMouseMove={handlePointerMove}
        onMouseUp={handlePointerUp}
        onTouchStart={handlePointerDown}
        onTouchMove={handlePointerMove}
        onTouchEnd={handlePointerUp}
      >
        {/* Transparency Checkerboard Background */}
        <div className="absolute inset-0 canvas-transparency-grid pointer-events-none" />

        {/* Composite Layer Canvas */}
        <canvas
          ref={compositeCanvasRef}
          width={doc.width}
          height={doc.height}
          className="absolute inset-0 block w-full h-full"
        />

        {/* Marching Ants / UI Overlay Canvas */}
        <canvas
          ref={overlayCanvasRef}
          width={doc.width}
          height={doc.height}
          className="absolute inset-0 block w-full h-full pointer-events-none z-10"
        />
      </div>

      {/* Coordinate & Zoom Readout Bar in Bottom Left */}
      <div className="absolute bottom-2 left-8 bg-[#202024]/90 backdrop-blur-xs border border-[#38383f] px-2.5 py-1 rounded text-[11px] font-mono text-neutral-400 flex items-center gap-3 z-30">
        <div>
          X: <span className="text-neutral-200">{Math.round(cursorPos.x)}</span> Y:{' '}
          <span className="text-neutral-200">{Math.round(cursorPos.y)}</span> px
        </div>
        <div className="w-px h-3 bg-[#38383f]" />
        <div>
          Zoom: <span className="text-sky-400">{Math.round(doc.zoom * 100)}%</span>
        </div>
        <div className="w-px h-3 bg-[#38383f]" />
        <div>
          Doc: <span className="text-neutral-200">{doc.width} × {doc.height}</span> px
        </div>
      </div>
    </div>
  );
};
