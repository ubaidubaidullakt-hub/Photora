/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { GradientConfig, GradientStop } from '../../types';
import { Sliders, X, Check, Plus, Trash2 } from 'lucide-react';

interface GradientEditorModalProps {
  currentConfig: GradientConfig;
  onClose: () => void;
  onApplyGradient: (config: GradientConfig) => void;
}

export const GradientEditorModal: React.FC<GradientEditorModalProps> = ({
  currentConfig,
  onClose,
  onApplyGradient,
}) => {
  const [stops, setStops] = useState<GradientStop[]>(currentConfig.colorStops);
  const [selectedStopIdx, setSelectedStopIdx] = useState(0);

  const presets: { name: string; stops: GradientStop[] }[] = [
    {
      name: 'Foreground to Transparent',
      stops: [
        { offset: 0, color: '#000000' },
        { offset: 1, color: '#ffffff' },
      ],
    },
    {
      name: 'Sunset Glow',
      stops: [
        { offset: 0, color: '#f43f5e' },
        { offset: 0.5, color: '#f59e0b' },
        { offset: 1, color: '#38bdf8' },
      ],
    },
    {
      name: 'Cyberpunk Neon',
      stops: [
        { offset: 0, color: '#8b5cf6' },
        { offset: 0.5, color: '#ec4899' },
        { offset: 1, color: '#06b6d4' },
      ],
    },
    {
      name: 'Emerald Aurora',
      stops: [
        { offset: 0, color: '#064e3b' },
        { offset: 0.5, color: '#10b981' },
        { offset: 1, color: '#a7f3d0' },
      ],
    },
  ];

  const handleAddStop = () => {
    const newStop: GradientStop = { offset: 0.5, color: '#38bdf8' };
    const newStops = [...stops, newStop].sort((a, b) => a.offset - b.offset);
    setStops(newStops);
    setSelectedStopIdx(newStops.indexOf(newStop));
  };

  const handleDeleteStop = (idx: number) => {
    if (stops.length <= 2) return;
    const filtered = stops.filter((_, i) => i !== idx);
    setStops(filtered);
    setSelectedStopIdx(Math.max(0, idx - 1));
  };

  const handleApply = () => {
    onApplyGradient({
      ...currentConfig,
      colorStops: stops,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 font-sans select-none">
      <div className="bg-[#242429] border border-[#38383f] rounded-lg shadow-2xl w-full max-w-md overflow-hidden text-neutral-200 text-xs">
        {/* Header */}
        <div className="px-4 py-3 bg-[#1d1d21] border-b border-[#2e2e32] flex items-center justify-between">
          <div className="flex items-center gap-2 font-semibold text-neutral-100 text-sm">
            <Sliders className="w-4 h-4 text-sky-400" />
            <span>Gradient Preset Editor</span>
          </div>
          <button onClick={onClose} className="p-1 hover:text-white text-neutral-400">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4">
          {/* Presets */}
          <div className="space-y-1">
            <label className="text-neutral-400 font-medium">Presets:</label>
            <div className="grid grid-cols-2 gap-2">
              {presets.map((p, i) => (
                <button
                  key={i}
                  onClick={() => setStops(p.stops)}
                  className="p-1.5 rounded bg-[#1c1c20] hover:bg-[#28282e] border border-[#38383f] space-y-1 text-left cursor-pointer"
                >
                  <div
                    className="w-full h-4 rounded border border-neutral-700"
                    style={{
                      background: `linear-gradient(to right, ${p.stops
                        .map((s) => `${s.color} ${s.offset * 100}%`)
                        .join(', ')})`,
                    }}
                  />
                  <div className="text-[10px] text-neutral-400 truncate">{p.name}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Gradient Preview Bar */}
          <div className="space-y-2 pt-2 border-t border-[#2e2e32]">
            <label className="text-neutral-400 font-medium">Gradient Ramp:</label>
            <div
              className="w-full h-8 rounded border border-[#38383f] shadow-inner"
              style={{
                background: `linear-gradient(to right, ${stops
                  .map((s) => `${s.color} ${s.offset * 100}%`)
                  .join(', ')})`,
              }}
            />
          </div>

          {/* Color Stop Controls */}
          <div className="space-y-2 pt-2 border-t border-[#2e2e32]">
            <div className="flex items-center justify-between">
              <span className="text-neutral-400 font-medium">Stops Management:</span>
              <button
                onClick={handleAddStop}
                className="flex items-center gap-1 px-2 py-0.5 rounded bg-[#2b2b32] hover:bg-[#35353d] text-sky-400 font-medium"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Stop</span>
              </button>
            </div>

            <div className="space-y-2 max-h-36 overflow-y-auto">
              {stops.map((stop, idx) => (
                <div
                  key={idx}
                  onClick={() => setSelectedStopIdx(idx)}
                  className={`flex items-center justify-between p-2 rounded border cursor-pointer ${
                    selectedStopIdx === idx
                      ? 'border-sky-400 bg-[#2b2b32]'
                      : 'border-[#38383f] bg-[#18181b]'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={stop.color}
                      onChange={(e) => {
                        const updated = [...stops];
                        updated[idx].color = e.target.value;
                        setStops(updated);
                      }}
                      className="w-6 h-6 rounded border border-neutral-700 bg-transparent cursor-pointer"
                    />
                    <span className="font-mono text-neutral-300">{stop.color}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-neutral-500 font-mono text-[11px]">
                      {Math.round(stop.offset * 100)}%
                    </span>
                    {stops.length > 2 && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteStop(idx);
                        }}
                        className="hover:text-rose-400 text-neutral-500"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 py-3 bg-[#1d1d21] border-t border-[#2e2e32] flex items-center justify-end gap-2">
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded bg-neutral-700 hover:bg-neutral-600 text-white font-medium cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={handleApply}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded bg-sky-500 hover:bg-sky-400 text-neutral-950 font-semibold cursor-pointer"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Apply Gradient</span>
          </button>
        </div>
      </div>
    </div>
  );
};
