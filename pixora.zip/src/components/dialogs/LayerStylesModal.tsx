/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { DocumentState, LayerEffects } from '../../types';
import { Sliders, X, Check } from 'lucide-react';

interface LayerStylesModalProps {
  document: DocumentState;
  onClose: () => void;
  onApplyStyles: (effects: LayerEffects) => void;
}

export const LayerStylesModal: React.FC<LayerStylesModalProps> = ({
  document: doc,
  onClose,
  onApplyStyles,
}) => {
  const activeLayer = doc.layers.find((l) => l.id === doc.activeLayerId);
  const [effects, setEffects] = useState<LayerEffects>(
    activeLayer?.effects || {
      dropShadow: {
        enabled: true,
        color: '#000000',
        opacity: 0.65,
        angle: 120,
        distance: 10,
        blur: 15,
        spread: 0,
      },
      colorOverlay: {
        enabled: false,
        color: '#38bdf8',
        opacity: 0.5,
      },
      stroke: {
        enabled: false,
        color: '#000000',
        width: 3,
        position: 'outside',
      },
    }
  );

  const [activeTab, setActiveTab] = useState<'dropShadow' | 'colorOverlay' | 'stroke'>('dropShadow');

  const handleApply = () => {
    onApplyStyles(effects);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 font-sans select-none">
      <div className="bg-[#242429] border border-[#38383f] rounded-lg shadow-2xl w-full max-w-lg overflow-hidden text-neutral-200 text-xs flex flex-col">
        {/* Header */}
        <div className="px-4 py-3 bg-[#1d1d21] border-b border-[#2e2e32] flex items-center justify-between">
          <div className="flex items-center gap-2 font-semibold text-neutral-100 text-sm">
            <span className="font-mono text-sky-400 font-bold">fx</span>
            <span>Layer Styles (Blending Options)</span>
          </div>
          <button onClick={onClose} className="p-1 hover:text-white text-neutral-400">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Layout: Left tabs + Right settings */}
        <div className="flex-1 flex overflow-hidden min-h-[280px]">
          {/* Left Tabs */}
          <div className="w-44 bg-[#1b1b1f] border-r border-[#2e2e32] p-2 space-y-1">
            {[
              { id: 'dropShadow', name: 'Drop Shadow', key: 'dropShadow' as const },
              { id: 'colorOverlay', name: 'Color Overlay', key: 'colorOverlay' as const },
              { id: 'stroke', name: 'Stroke', key: 'stroke' as const },
            ].map((tab) => (
              <div
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center justify-between px-2.5 py-1.5 rounded cursor-pointer ${
                  activeTab === tab.id ? 'bg-[#2b2b32] text-white font-medium' : 'text-neutral-400 hover:bg-[#222226]'
                }`}
              >
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={!!effects[tab.key]?.enabled}
                    onChange={(e) =>
                      setEffects({
                        ...effects,
                        [tab.key]: { ...(effects[tab.key] as any), enabled: e.target.checked },
                      })
                    }
                    onClick={(e) => e.stopPropagation()}
                    className="rounded border-[#38383f] bg-[#18181b] text-sky-500"
                  />
                  <span>{tab.name}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Right Tab Content */}
          <div className="flex-1 p-4 space-y-4 overflow-y-auto">
            {activeTab === 'dropShadow' && effects.dropShadow && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-neutral-400">Shadow Color:</span>
                  <input
                    type="color"
                    value={effects.dropShadow.color}
                    onChange={(e) =>
                      setEffects({
                        ...effects,
                        dropShadow: { ...effects.dropShadow!, color: e.target.value },
                      })
                    }
                    className="w-8 h-6 rounded border border-[#38383f] bg-transparent cursor-pointer"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-neutral-400">
                    <span>Opacity:</span>
                    <span className="font-mono">{Math.round(effects.dropShadow.opacity * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={effects.dropShadow.opacity}
                    onChange={(e) =>
                      setEffects({
                        ...effects,
                        dropShadow: { ...effects.dropShadow!, opacity: Number(e.target.value) },
                      })
                    }
                    className="w-full"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-neutral-400">
                    <span>Angle:</span>
                    <span className="font-mono">{effects.dropShadow.angle}°</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="360"
                    value={effects.dropShadow.angle}
                    onChange={(e) =>
                      setEffects({
                        ...effects,
                        dropShadow: { ...effects.dropShadow!, angle: Number(e.target.value) },
                      })
                    }
                    className="w-full"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-neutral-400">
                    <span>Distance:</span>
                    <span className="font-mono">{effects.dropShadow.distance}px</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={effects.dropShadow.distance}
                    onChange={(e) =>
                      setEffects({
                        ...effects,
                        dropShadow: { ...effects.dropShadow!, distance: Number(e.target.value) },
                      })
                    }
                    className="w-full"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-neutral-400">
                    <span>Blur (Size):</span>
                    <span className="font-mono">{effects.dropShadow.blur}px</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={effects.dropShadow.blur}
                    onChange={(e) =>
                      setEffects({
                        ...effects,
                        dropShadow: { ...effects.dropShadow!, blur: Number(e.target.value) },
                      })
                    }
                    className="w-full"
                  />
                </div>
              </div>
            )}

            {activeTab === 'colorOverlay' && effects.colorOverlay && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-neutral-400">Overlay Color:</span>
                  <input
                    type="color"
                    value={effects.colorOverlay.color}
                    onChange={(e) =>
                      setEffects({
                        ...effects,
                        colorOverlay: { ...effects.colorOverlay!, color: e.target.value },
                      })
                    }
                    className="w-8 h-6 rounded border border-[#38383f] bg-transparent cursor-pointer"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-neutral-400">
                    <span>Opacity:</span>
                    <span className="font-mono">{Math.round(effects.colorOverlay.opacity * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={effects.colorOverlay.opacity}
                    onChange={(e) =>
                      setEffects({
                        ...effects,
                        colorOverlay: { ...effects.colorOverlay!, opacity: Number(e.target.value) },
                      })
                    }
                    className="w-full"
                  />
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 py-3 bg-[#1d1d21] border-t border-[#2e2e32] flex items-center justify-end gap-2">
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded bg-neutral-700 hover:bg-neutral-600 text-white font-medium cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={handleApply}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded bg-sky-500 hover:bg-sky-400 text-neutral-950 font-semibold cursor-pointer"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Apply Styles</span>
          </button>
        </div>
      </div>
    </div>
  );
};
