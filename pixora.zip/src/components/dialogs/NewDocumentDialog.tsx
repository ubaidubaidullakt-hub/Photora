/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { FilePlus, X, Check } from 'lucide-react';

interface NewDocumentDialogProps {
  onClose: () => void;
  onCreate: (name: string, width: number, height: number, resolution: number, bg: string) => void;
}

export const NewDocumentDialog: React.FC<NewDocumentDialogProps> = ({ onClose, onCreate }) => {
  const [name, setName] = useState('Untitled-1');
  const [width, setWidth] = useState(1200);
  const [height, setHeight] = useState(800);
  const [resolution, setResolution] = useState(72);
  const [bgColor, setBgColor] = useState('white');

  const presets = [
    { label: 'Default Web (1200 × 800)', w: 1200, h: 800, dpi: 72 },
    { label: 'Full HD 1080p (1920 × 1080)', w: 1920, h: 1080, dpi: 72 },
    { label: 'Square Post (1080 × 1080)', w: 1080, h: 1080, dpi: 72 },
    { label: 'Story / Vertical (1080 × 1920)', w: 1080, h: 1920, dpi: 72 },
    { label: '4K Ultra HD (3840 × 2160)', w: 3840, h: 2160, dpi: 72 },
    { label: 'Print Letter 300 DPI (2550 × 3300)', w: 2550, h: 3300, dpi: 300 },
  ];

  const handleApplyPreset = (w: number, h: number, dpi: number) => {
    setWidth(w);
    setHeight(h);
    setResolution(dpi);
  };

  const handleCreate = () => {
    onCreate(name, width, height, resolution, bgColor);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 font-sans select-none">
      <div className="bg-[#242429] border border-[#38383f] rounded-lg shadow-2xl w-full max-w-md overflow-hidden text-neutral-200 text-xs">
        {/* Header */}
        <div className="px-4 py-3 bg-[#1d1d21] border-b border-[#2e2e32] flex items-center justify-between">
          <div className="flex items-center gap-2 font-semibold text-neutral-100 text-sm">
            <FilePlus className="w-4 h-4 text-sky-400" />
            <span>New Document</span>
          </div>
          <button onClick={onClose} className="p-1 hover:text-white text-neutral-400">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 space-y-4">
          {/* Document Name */}
          <div className="space-y-1">
            <label className="text-neutral-400 font-medium">Document Name:</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-[#18181b] border border-[#38383f] rounded px-3 py-1.5 text-neutral-100 outline-none"
            />
          </div>

          {/* Quick Presets */}
          <div className="space-y-1">
            <label className="text-neutral-400 font-medium">Standard Presets:</label>
            <div className="grid grid-cols-2 gap-1.5">
              {presets.map((p, i) => (
                <button
                  key={i}
                  onClick={() => handleApplyPreset(p.w, p.h, p.dpi)}
                  className="px-2 py-1.5 rounded bg-[#1c1c20] hover:bg-[#28282e] border border-[#38383f] text-left text-neutral-300 transition-colors"
                >
                  <div className="font-medium text-[11px] truncate">{p.label.split(' (')[0]}</div>
                  <div className="text-[10px] text-neutral-500 font-mono">
                    {p.w} × {p.h} px
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Dimensions */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-neutral-400 font-medium">Width:</label>
              <div className="flex items-center gap-1 bg-[#18181b] border border-[#38383f] px-2 py-1 rounded">
                <input
                  type="number"
                  value={width}
                  onChange={(e) => setWidth(Math.max(10, Number(e.target.value)))}
                  className="w-full bg-transparent outline-none font-mono text-neutral-200"
                />
                <span className="text-neutral-500">px</span>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-neutral-400 font-medium">Height:</label>
              <div className="flex items-center gap-1 bg-[#18181b] border border-[#38383f] px-2 py-1 rounded">
                <input
                  type="number"
                  value={height}
                  onChange={(e) => setHeight(Math.max(10, Number(e.target.value)))}
                  className="w-full bg-transparent outline-none font-mono text-neutral-200"
                />
                <span className="text-neutral-500">px</span>
              </div>
            </div>
          </div>

          {/* Resolution & Background */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-neutral-400 font-medium">Resolution:</label>
              <div className="flex items-center gap-1 bg-[#18181b] border border-[#38383f] px-2 py-1 rounded">
                <input
                  type="number"
                  value={resolution}
                  onChange={(e) => setResolution(Number(e.target.value))}
                  className="w-full bg-transparent outline-none font-mono text-neutral-200"
                />
                <span className="text-neutral-500">DPI</span>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-neutral-400 font-medium">Background:</label>
              <select
                value={bgColor}
                onChange={(e) => setBgColor(e.target.value)}
                className="w-full bg-[#18181b] border border-[#38383f] rounded px-2 py-1 text-neutral-200 outline-none"
              >
                <option value="white">White</option>
                <option value="black">Black</option>
                <option value="transparent">Transparent</option>
              </select>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 py-3 bg-[#1d1d21] border-t border-[#2e2e32] flex items-center justify-end gap-2">
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded bg-neutral-700 hover:bg-neutral-600 text-white font-medium cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={handleCreate}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded bg-sky-500 hover:bg-sky-400 text-neutral-950 font-semibold cursor-pointer"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Create Document</span>
          </button>
        </div>
      </div>
    </div>
  );
};
