/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { generateProjectZipBundle, triggerDownload } from '../../engine/importExport';
import { Package, Download, X, CheckCircle2, FileCode, Check } from 'lucide-react';

interface ProjectZipModalProps {
  onClose: () => void;
}

export const ProjectZipModal: React.FC<ProjectZipModalProps> = ({ onClose }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [downloaded, setDownloaded] = useState(false);

  const handleDownloadZip = async () => {
    setIsGenerating(true);
    try {
      const blob = await generateProjectZipBundle();
      triggerDownload(blob, 'PIXORA_COMPLETE_PROJECT.zip');
      setDownloaded(true);
    } catch (err) {
      console.error('ZIP generation failed:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 font-sans select-none">
      <div className="bg-[#242429] border border-[#38383f] rounded-lg shadow-2xl w-full max-w-lg overflow-hidden text-neutral-200 text-xs flex flex-col">
        {/* Header */}
        <div className="px-4 py-3 bg-[#1d1d21] border-b border-[#2e2e32] flex items-center justify-between">
          <div className="flex items-center gap-2 font-semibold text-neutral-100 text-sm">
            <Package className="w-4 h-4 text-sky-400" />
            <span>Complete Project ZIP Deliverable</span>
          </div>
          <button onClick={onClose} className="p-1 hover:text-white text-neutral-400">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4">
          <p className="text-neutral-300 leading-relaxed">
            Generate and download the complete <strong>PIXORA</strong> source code project bundle
            containing all application source files, configuration files, complete documentation, automated
            unit and integration tests, non-AI image algorithms, and build scripts.
          </p>

          <div className="bg-[#18181b] border border-[#38383f] rounded p-3 space-y-2 font-mono text-[11px] text-neutral-400">
            <div className="text-sky-400 font-bold mb-1 font-sans text-xs">Bundle Manifest:</div>
            <div className="flex items-center gap-2">
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span>All Source Code (/src, /engine, /components, /types)</span>
            </div>
            <div className="flex items-center gap-2">
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span>Full Project Configs (package.json, tsconfig.json, vite.config.ts)</span>
            </div>
            <div className="flex items-center gap-2">
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span>Complete Documentation (README.md, LICENSES.md)</span>
            </div>
            <div className="flex items-center gap-2">
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span>Automated Verification Test Suite &amp; Report</span>
            </div>
            <div className="flex items-center gap-2">
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span>100% Offline Non-AI Conventional Image Processing Math</span>
            </div>
          </div>

          {downloaded && (
            <div className="flex items-center gap-2 text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-3 py-2 rounded">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Project ZIP archive generated and download started successfully!</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-4 py-3 bg-[#1d1d21] border-t border-[#2e2e32] flex items-center justify-end gap-2">
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded bg-neutral-700 hover:bg-neutral-600 text-white font-medium cursor-pointer"
          >
            Close
          </button>
          <button
            onClick={handleDownloadZip}
            disabled={isGenerating}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded bg-sky-500 hover:bg-sky-400 text-neutral-950 font-semibold cursor-pointer disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isGenerating ? 'Packaging ZIP...' : 'Download PIXORA Project (.zip)'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
