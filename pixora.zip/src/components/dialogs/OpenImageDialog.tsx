/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState } from 'react';
import { Upload, X, FileImage, Layers } from 'lucide-react';

interface OpenImageDialogProps {
  onClose: () => void;
  onOpenAsDocument: (img: HTMLImageElement, filename: string) => void;
  onOpenAsLayer: (img: HTMLImageElement, filename: string) => void;
  onLoadProject: (projectJson: string) => void;
}

export const OpenImageDialog: React.FC<OpenImageDialogProps> = ({
  onClose,
  onOpenAsDocument,
  onOpenAsLayer,
  onLoadProject,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [openMode, setOpenMode] = useState<'doc' | 'layer'>('doc');
  const [dragActive, setDragActive] = useState(false);

  const processFile = (file: File) => {
    if (file.name.endsWith('.pixora') || file.type === 'application/json') {
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target?.result as string;
        onLoadProject(text);
        onClose();
      };
      reader.readAsText(file);
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        if (openMode === 'doc') {
          onOpenAsDocument(img, file.name);
        } else {
          onOpenAsLayer(img, file.name);
        }
        onClose();
      };
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 font-sans select-none">
      <div className="bg-[#242429] border border-[#38383f] rounded-lg shadow-2xl w-full max-w-md overflow-hidden text-neutral-200 text-xs">
        {/* Header */}
        <div className="px-4 py-3 bg-[#1d1d21] border-b border-[#2e2e32] flex items-center justify-between">
          <div className="flex items-center gap-2 font-semibold text-neutral-100 text-sm">
            <Upload className="w-4 h-4 text-sky-400" />
            <span>Open Image or Project</span>
          </div>
          <button onClick={onClose} className="p-1 hover:text-white text-neutral-400">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4">
          <div className="flex items-center gap-2 bg-[#1b1b1f] p-1 rounded border border-[#38383f]">
            <button
              onClick={() => setOpenMode('doc')}
              className={`flex-1 py-1.5 rounded text-center font-medium ${
                openMode === 'doc' ? 'bg-sky-500 text-neutral-950 font-semibold' : 'text-neutral-400 hover:text-white'
              }`}
            >
              Open as New Document
            </button>
            <button
              onClick={() => setOpenMode('layer')}
              className={`flex-1 py-1.5 rounded text-center font-medium ${
                openMode === 'layer' ? 'bg-sky-500 text-neutral-950 font-semibold' : 'text-neutral-400 hover:text-white'
              }`}
            >
              Add as New Layer
            </button>
          </div>

          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragActive(true);
            }}
            onDragLeave={() => setDragActive(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-lg p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-colors ${
              dragActive ? 'border-sky-400 bg-sky-500/10' : 'border-[#38383f] hover:border-neutral-400 bg-[#18181b]'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*,.pixora,application/json"
              onChange={handleFileChange}
              className="hidden"
            />
            <FileImage className="w-10 h-10 text-neutral-500 mb-2" />
            <span className="text-neutral-200 font-medium text-sm">
              Click to browse or drop image here
            </span>
            <span className="text-neutral-500 text-[11px] mt-1">
              Supports PNG, JPEG, WebP, SVG, GIF, BMP, and .pixora project files
            </span>
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 py-3 bg-[#1d1d21] border-t border-[#2e2e32] flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded bg-neutral-700 hover:bg-neutral-600 text-white font-medium cursor-pointer"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};
