/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AdjustmentSettings, DocumentState } from '../../types';
import { applyAdjustments } from '../../engine/imageProcessing';
import { Sliders, X, Check, RotateCcw } from 'lucide-react';

interface AdjustmentsModalProps {
  document: DocumentState;
  initialType?: AdjustmentSettings['type'];
  onClose: () => void;
  onApply: (settings: AdjustmentSettings) => void;
}

export const AdjustmentsModal: React.FC<AdjustmentsModalProps> = ({
  document: doc,
  initialType = 'brightnessContrast',
  onClose,
  onApply,
}) => {
  const [settings, setSettings] = useState<AdjustmentSettings>({
    type: initialType,
    brightness: 0,
    contrast: 0,
    hue: 0,
    saturation: 0,
    lightness: 0,
    vibrance: 0,
    levels: { inBlack: 0, inWhite: 255, gamma: 1.0, outBlack: 0, outWhite: 255 },
    colorBalance: { cyanRed: 0, magentaGreen: 0, yellowBlue: 0 },
    temperature: 0,
    tint: 0,
    threshold: 128,
    posterize: 4,
    photoFilter: { color: '#f59e0b', density: 25 },
  });

  const handleReset = () => {
    setSettings((prev) => ({
      ...prev,
      brightness: 0,
      contrast: 0,
      hue: 0,
      saturation: 0,
      lightness: 0,
      vibrance: 0,
      temperature: 0,
      tint: 0,
    }));
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 font-sans select-none">
      <div className="bg-[#242429] border border-[#38383f] rounded-lg shadow-2xl w-full max-w-md overflow-hidden text-neutral-200 text-xs">
        {/* Modal Header */}
        <div className="px-4 py-3 bg-[#1d1d21] border-b border-[#2e2e32] flex items-center justify-between">
          <div className="flex items-center gap-2 font-semibold text-neutral-100 text-sm">
            <Sliders className="w-4 h-4 text-sky-400" />
            <span>Image Adjustments</span>
          </div>
          <button onClick={onClose} className="p-1 hover:text-white text-neutral-400">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 space-y-4 max-h-[70vh] overflow-y-auto">
          {/* Adjustment Type Switcher */}
          <div className="space-y-1">
            <label className="text-neutral-400 font-medium">Adjustment Type:</label>
            <select
              value={settings.type}
              onChange={(e) =>
                setSettings({ ...settings, type: e.target.value as AdjustmentSettings['type'] })
              }
              className="w-full bg-[#18181b] border border-[#38383f] rounded px-3 py-1.5 text-neutral-200 outline-none"
            >
              <option value="brightnessContrast">Brightness &amp; Contrast</option>
              <option value="hueSaturation">Hue &amp; Saturation</option>
              <option value="vibrance">Vibrance</option>
              <option value="levels">Levels (Histogram Input/Output)</option>
              <option value="colorBalance">Color Balance</option>
              <option value="temperatureTint">Temperature &amp; Tint</option>
              <option value="blackAndWhite">Black &amp; White (Grayscale)</option>
              <option value="invert">Invert Colors</option>
              <option value="threshold">Threshold (1-Bit)</option>
              <option value="posterize">Posterize (Levels)</option>
              <option value="photoFilter">Photo Filter (Tint)</option>
            </select>
          </div>

          {/* Brightness & Contrast Controls */}
          {settings.type === 'brightnessContrast' && (
            <div className="space-y-3 pt-2">
              <div className="space-y-1">
                <div className="flex justify-between text-neutral-400">
                  <span>Brightness:</span>
                  <span className="font-mono">{settings.brightness}</span>
                </div>
                <input
                  type="range"
                  min="-100"
                  max="100"
                  value={settings.brightness}
                  onChange={(e) => setSettings({ ...settings, brightness: Number(e.target.value) })}
                  className="w-full"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-neutral-400">
                  <span>Contrast:</span>
                  <span className="font-mono">{settings.contrast}</span>
                </div>
                <input
                  type="range"
                  min="-100"
                  max="100"
                  value={settings.contrast}
                  onChange={(e) => setSettings({ ...settings, contrast: Number(e.target.value) })}
                  className="w-full"
                />
              </div>
            </div>
          )}

          {/* Hue / Saturation Controls */}
          {settings.type === 'hueSaturation' && (
            <div className="space-y-3 pt-2">
              <div className="space-y-1">
                <div className="flex justify-between text-neutral-400">
                  <span>Hue:</span>
                  <span className="font-mono">{settings.hue}°</span>
                </div>
                <input
                  type="range"
                  min="-180"
                  max="180"
                  value={settings.hue}
                  onChange={(e) => setSettings({ ...settings, hue: Number(e.target.value) })}
                  className="w-full"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-neutral-400">
                  <span>Saturation:</span>
                  <span className="font-mono">{settings.saturation}</span>
                </div>
                <input
                  type="range"
                  min="-100"
                  max="100"
                  value={settings.saturation}
                  onChange={(e) => setSettings({ ...settings, saturation: Number(e.target.value) })}
                  className="w-full"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-neutral-400">
                  <span>Lightness:</span>
                  <span className="font-mono">{settings.lightness}</span>
                </div>
                <input
                  type="range"
                  min="-100"
                  max="100"
                  value={settings.lightness}
                  onChange={(e) => setSettings({ ...settings, lightness: Number(e.target.value) })}
                  className="w-full"
                />
              </div>
            </div>
          )}

          {/* Vibrance Controls */}
          {settings.type === 'vibrance' && (
            <div className="space-y-3 pt-2">
              <div className="space-y-1">
                <div className="flex justify-between text-neutral-400">
                  <span>Vibrance:</span>
                  <span className="font-mono">{settings.vibrance}</span>
                </div>
                <input
                  type="range"
                  min="-100"
                  max="100"
                  value={settings.vibrance}
                  onChange={(e) => setSettings({ ...settings, vibrance: Number(e.target.value) })}
                  className="w-full"
                />
              </div>
            </div>
          )}

          {/* Levels Controls */}
          {settings.type === 'levels' && (
            <div className="space-y-3 pt-2">
              <div className="space-y-1">
                <div className="flex justify-between text-neutral-400">
                  <span>Input Black Point:</span>
                  <span className="font-mono">{settings.levels?.inBlack}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="250"
                  value={settings.levels?.inBlack}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      levels: { ...settings.levels!, inBlack: Number(e.target.value) },
                    })
                  }
                  className="w-full"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-neutral-400">
                  <span>Gamma (Midtones):</span>
                  <span className="font-mono">{settings.levels?.gamma?.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min="0.2"
                  max="3.0"
                  step="0.05"
                  value={settings.levels?.gamma}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      levels: { ...settings.levels!, gamma: Number(e.target.value) },
                    })
                  }
                  className="w-full"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-neutral-400">
                  <span>Input White Point:</span>
                  <span className="font-mono">{settings.levels?.inWhite}</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="255"
                  value={settings.levels?.inWhite}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      levels: { ...settings.levels!, inWhite: Number(e.target.value) },
                    })
                  }
                  className="w-full"
                />
              </div>
            </div>
          )}

          {/* Color Balance Controls */}
          {settings.type === 'colorBalance' && (
            <div className="space-y-3 pt-2">
              <div className="space-y-1">
                <div className="flex justify-between text-neutral-400">
                  <span>Cyan / Red:</span>
                  <span className="font-mono">{settings.colorBalance?.cyanRed}</span>
                </div>
                <input
                  type="range"
                  min="-100"
                  max="100"
                  value={settings.colorBalance?.cyanRed}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      colorBalance: { ...settings.colorBalance!, cyanRed: Number(e.target.value) },
                    })
                  }
                  className="w-full"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-neutral-400">
                  <span>Magenta / Green:</span>
                  <span className="font-mono">{settings.colorBalance?.magentaGreen}</span>
                </div>
                <input
                  type="range"
                  min="-100"
                  max="100"
                  value={settings.colorBalance?.magentaGreen}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      colorBalance: { ...settings.colorBalance!, magentaGreen: Number(e.target.value) },
                    })
                  }
                  className="w-full"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-neutral-400">
                  <span>Yellow / Blue:</span>
                  <span className="font-mono">{settings.colorBalance?.yellowBlue}</span>
                </div>
                <input
                  type="range"
                  min="-100"
                  max="100"
                  value={settings.colorBalance?.yellowBlue}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      colorBalance: { ...settings.colorBalance!, yellowBlue: Number(e.target.value) },
                    })
                  }
                  className="w-full"
                />
              </div>
            </div>
          )}

          {/* Temperature & Tint Controls */}
          {settings.type === 'temperatureTint' && (
            <div className="space-y-3 pt-2">
              <div className="space-y-1">
                <div className="flex justify-between text-neutral-400">
                  <span>Temperature (Cool / Warm):</span>
                  <span className="font-mono">{settings.temperature}</span>
                </div>
                <input
                  type="range"
                  min="-100"
                  max="100"
                  value={settings.temperature}
                  onChange={(e) => setSettings({ ...settings, temperature: Number(e.target.value) })}
                  className="w-full"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-neutral-400">
                  <span>Tint (Green / Magenta):</span>
                  <span className="font-mono">{settings.tint}</span>
                </div>
                <input
                  type="range"
                  min="-100"
                  max="100"
                  value={settings.tint}
                  onChange={(e) => setSettings({ ...settings, tint: Number(e.target.value) })}
                  className="w-full"
                />
              </div>
            </div>
          )}

          {/* Threshold Control */}
          {settings.type === 'threshold' && (
            <div className="space-y-1 pt-2">
              <div className="flex justify-between text-neutral-400">
                <span>Threshold Level:</span>
                <span className="font-mono">{settings.threshold}</span>
              </div>
              <input
                type="range"
                min="1"
                max="255"
                value={settings.threshold}
                onChange={(e) => setSettings({ ...settings, threshold: Number(e.target.value) })}
                className="w-full"
              />
            </div>
          )}

          {/* Posterize Control */}
          {settings.type === 'posterize' && (
            <div className="space-y-1 pt-2">
              <div className="flex justify-between text-neutral-400">
                <span>Color Levels:</span>
                <span className="font-mono">{settings.posterize}</span>
              </div>
              <input
                type="range"
                min="2"
                max="32"
                value={settings.posterize}
                onChange={(e) => setSettings({ ...settings, posterize: Number(e.target.value) })}
                className="w-full"
              />
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-4 py-3 bg-[#1d1d21] border-t border-[#2e2e32] flex items-center justify-between">
          <button
            onClick={handleReset}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#2a2a30] hover:bg-[#33333b] text-neutral-300 font-medium cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 rounded bg-neutral-700 hover:bg-neutral-600 text-white font-medium cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={() => onApply(settings)}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded bg-sky-500 hover:bg-sky-400 text-neutral-950 font-semibold cursor-pointer"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Apply Adjustment</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
