/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { DocumentState, Layer } from '../../types';
import {
  applyGaussianBlur,
  applyMotionBlur,
  applyRadialBlur,
  applyUnsharpMask,
  applyHighPass,
  applyAddNoise,
  applyTwirl,
  applyRipple,
  applyMosaic,
  applyEmboss,
  applyFindEdges,
  renderClouds,
  renderLensFlare,
} from '../../engine/imageProcessing';
import { Sparkles, X, Check } from 'lucide-react';

interface FilterDialogProps {
  document: DocumentState;
  initialFilter?: string;
  onClose: () => void;
  onApplyFilter: (filterType: string, params: any) => void;
}

export const FilterDialog: React.FC<FilterDialogProps> = ({
  document: doc,
  initialFilter = 'gaussianBlur',
  onClose,
  onApplyFilter,
}) => {
  const [filterType, setFilterType] = useState(initialFilter);
  const [radius, setRadius] = useState(5);
  const [amount, setAmount] = useState(50);
  const [angle, setAngle] = useState(45);
  const [distance, setDistance] = useState(15);
  const [blockSize, setBlockSize] = useState(12);

  const previewCanvasRef = useRef<HTMLCanvasElement>(null);

  const activeLayer = doc.layers.find((l) => l.id === doc.activeLayerId) || doc.layers[0];

  // Render live preview on preview canvas
  useEffect(() => {
    const canvas = previewCanvasRef.current;
    if (!canvas || !activeLayer) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Draw active layer to preview canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(activeLayer.canvas, 0, 0, canvas.width, canvas.height);

    if (filterType === 'clouds') {
      const clouds = renderClouds(canvas.width, canvas.height);
      ctx.putImageData(clouds, 0, 0);
      return;
    }

    if (filterType === 'lensFlare') {
      renderLensFlare(canvas, canvas.width / 2, canvas.height / 2, amount / 50);
      return;
    }

    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    let filtered: ImageData | null = null;

    switch (filterType) {
      case 'gaussianBlur':
        filtered = applyGaussianBlur(imgData, radius);
        break;
      case 'motionBlur':
        filtered = applyMotionBlur(imgData, distance, angle);
        break;
      case 'radialBlur':
        filtered = applyRadialBlur(imgData, amount);
        break;
      case 'unsharpMask':
        filtered = applyUnsharpMask(imgData, radius, amount);
        break;
      case 'highPass':
        filtered = applyHighPass(imgData, radius);
        break;
      case 'addNoise':
        filtered = applyAddNoise(imgData, amount, true);
        break;
      case 'twirl':
        filtered = applyTwirl(imgData, amount * 3.6);
        break;
      case 'ripple':
        filtered = applyRipple(imgData, radius * 2, 8);
        break;
      case 'mosaic':
        filtered = applyMosaic(imgData, blockSize);
        break;
      case 'emboss':
        filtered = applyEmboss(imgData);
        break;
      case 'findEdges':
        filtered = applyFindEdges(imgData);
        break;
    }

    if (filtered) {
      ctx.putImageData(filtered, 0, 0);
    }
  }, [filterType, radius, amount, angle, distance, blockSize, activeLayer]);

  const handleApply = () => {
    onApplyFilter(filterType, { radius, amount, angle, distance, blockSize });
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 font-sans select-none">
      <div className="bg-[#242429] border border-[#38383f] rounded-lg shadow-2xl w-full max-w-lg overflow-hidden text-neutral-200 text-xs">
        {/* Header */}
        <div className="px-4 py-3 bg-[#1d1d21] border-b border-[#2e2e32] flex items-center justify-between">
          <div className="flex items-center gap-2 font-semibold text-neutral-100 text-sm">
            <Sparkles className="w-4 h-4 text-sky-400" />
            <span>Filter Gallery &amp; Effects</span>
          </div>
          <button onClick={onClose} className="p-1 hover:text-white text-neutral-400">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 grid grid-cols-2 gap-4">
          {/* Left: Preview Canvas */}
          <div className="space-y-2">
            <label className="text-neutral-400 font-medium">Real-time Preview:</label>
            <div className="w-full h-48 bg-[#18181b] border border-[#38383f] rounded flex items-center justify-center overflow-hidden canvas-transparency-grid p-1">
              <canvas
                ref={previewCanvasRef}
                width={200}
                height={160}
                className="max-w-full max-h-full object-contain block"
              />
            </div>
          </div>

          {/* Right: Filter Selector & Sliders */}
          <div className="space-y-4">
            <div className="space-y-1">
              <label className="text-neutral-400 font-medium">Select Filter:</label>
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="w-full bg-[#18181b] border border-[#38383f] rounded px-2.5 py-1.5 text-neutral-200 outline-none"
              >
                <optgroup label="Blur Filters">
                  <option value="gaussianBlur">Gaussian Blur</option>
                  <option value="motionBlur">Motion Blur</option>
                  <option value="radialBlur">Radial Blur</option>
                </optgroup>
                <optgroup label="Sharpen Filters">
                  <option value="unsharpMask">Unsharp Mask (Sharpen)</option>
                  <option value="highPass">High Pass Filter</option>
                </optgroup>
                <optgroup label="Distortion &amp; Noise">
                  <option value="addNoise">Add Noise</option>
                  <option value="twirl">Twirl Distortion</option>
                  <option value="ripple">Ripple Distortion</option>
                  <option value="mosaic">Mosaic Pixelation</option>
                </optgroup>
                <optgroup label="Stylize &amp; Render">
                  <option value="emboss">Emboss</option>
                  <option value="findEdges">Find Edges (Sobel)</option>
                  <option value="clouds">Procedural Clouds</option>
                  <option value="lensFlare">Lens Flare</option>
                </optgroup>
              </select>
            </div>

            {/* Sliders depending on active filter */}
            {['gaussianBlur', 'highPass', 'ripple'].includes(filterType) && (
              <div className="space-y-1">
                <div className="flex justify-between text-neutral-400">
                  <span>Radius:</span>
                  <span className="font-mono">{radius}px</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="30"
                  value={radius}
                  onChange={(e) => setRadius(Number(e.target.value))}
                  className="w-full"
                />
              </div>
            )}

            {filterType === 'motionBlur' && (
              <>
                <div className="space-y-1">
                  <div className="flex justify-between text-neutral-400">
                    <span>Distance:</span>
                    <span className="font-mono">{distance}px</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="50"
                    value={distance}
                    onChange={(e) => setDistance(Number(e.target.value))}
                    className="w-full"
                  />
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-neutral-400">
                    <span>Angle:</span>
                    <span className="font-mono">{angle}°</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="360"
                    value={angle}
                    onChange={(e) => setAngle(Number(e.target.value))}
                    className="w-full"
                  />
                </div>
              </>
            )}

            {['radialBlur', 'unsharpMask', 'addNoise', 'twirl', 'lensFlare'].includes(filterType) && (
              <div className="space-y-1">
                <div className="flex justify-between text-neutral-400">
                  <span>Amount:</span>
                  <span className="font-mono">{amount}%</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="100"
                  value={amount}
                  onChange={(e) => setAmount(Number(e.target.value))}
                  className="w-full"
                />
              </div>
            )}

            {filterType === 'mosaic' && (
              <div className="space-y-1">
                <div className="flex justify-between text-neutral-400">
                  <span>Cell Size:</span>
                  <span className="font-mono">{blockSize}px</span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="40"
                  value={blockSize}
                  onChange={(e) => setBlockSize(Number(e.target.value))}
                  className="w-full"
                />
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 py-3 bg-[#1d1d21] border-t border-[#2e2e32] flex items-center justify-end gap-2">
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded bg-neutral-700 hover:bg-neutral-600 text-white font-medium cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={handleApply}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded bg-sky-500 hover:bg-sky-400 text-neutral-950 font-semibold cursor-pointer"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Apply Filter</span>
          </button>
        </div>
      </div>
    </div>
  );
};
