/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Keyboard, X } from 'lucide-react';

interface KeyboardShortcutsModalProps {
  onClose: () => void;
}

export const KeyboardShortcutsModal: React.FC<KeyboardShortcutsModalProps> = ({ onClose }) => {
  const shortcuts = [
    { key: 'V', desc: 'Move Tool' },
    { key: 'M', desc: 'Marquee Selection (Rect / Ellipse)' },
    { key: 'L', desc: 'Lasso Selection (Freehand / Polygonal)' },
    { key: 'W', desc: 'Magic Wand / Quick Selection' },
    { key: 'C', desc: 'Crop Tool' },
    { key: 'I', desc: 'Eyedropper Tool' },
    { key: 'J', desc: 'Spot Healing Brush' },
    { key: 'S', desc: 'Clone Stamp Tool (Alt+Click to sample)' },
    { key: 'B', desc: 'Brush / Pencil Tool' },
    { key: 'E', desc: 'Eraser Tool' },
    { key: 'G', desc: 'Paint Bucket / Gradient Tool' },
    { key: 'R', desc: 'Blur / Sharpen / Smudge Tool' },
    { key: 'O', desc: 'Dodge / Burn / Sponge Tool' },
    { key: 'P', desc: 'Pen Tool' },
    { key: 'T', desc: 'Horizontal Type Tool' },
    { key: 'U', desc: 'Vector Shape Tool' },
    { key: 'H', desc: 'Hand Tool' },
    { key: 'Z', desc: 'Zoom Tool' },
    { key: 'X', desc: 'Swap Foreground and Background Colors' },
    { key: 'D', desc: 'Reset Colors to Default Black and White' },
    { key: 'Ctrl + Z', desc: 'Undo' },
    { key: 'Ctrl + Shift + Z', desc: 'Redo' },
    { key: 'Ctrl + S', desc: 'Export / Save Project' },
    { key: 'Ctrl + O', desc: 'Open Image' },
    { key: 'Ctrl + N', desc: 'New Document' },
    { key: 'Ctrl + A', desc: 'Select All' },
    { key: 'Ctrl + D', desc: 'Deselect Selection' },
    { key: 'Ctrl + Shift + I', desc: 'Inverse Selection' },
    { key: 'Ctrl + J', desc: 'Duplicate Active Layer' },
    { key: 'Ctrl + E', desc: 'Merge Down Layer' },
    { key: 'Ctrl + 0', desc: 'Fit Canvas on Screen' },
    { key: 'Ctrl + 1', desc: 'Actual Pixels (100% Zoom)' },
    { key: 'Ctrl + R', desc: 'Toggle Rulers' },
  ];

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 font-sans select-none">
      <div className="bg-[#242429] border border-[#38383f] rounded-lg shadow-2xl w-full max-w-xl overflow-hidden text-neutral-200 text-xs flex flex-col max-h-[80vh]">
        <div className="px-4 py-3 bg-[#1d1d21] border-b border-[#2e2e32] flex items-center justify-between">
          <div className="flex items-center gap-2 font-semibold text-neutral-100 text-sm">
            <Keyboard className="w-4 h-4 text-sky-400" />
            <span>Photoshop-Style Keyboard Shortcuts</span>
          </div>
          <button onClick={onClose} className="p-1 hover:text-white text-neutral-400">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 overflow-y-auto grid grid-cols-2 gap-2">
          {shortcuts.map((s, i) => (
            <div
              key={i}
              className="flex items-center justify-between p-2 rounded bg-[#1b1b1f] border border-[#38383f]"
            >
              <span className="text-neutral-300">{s.desc}</span>
              <kbd className="px-1.5 py-0.5 rounded bg-[#2b2b32] border border-[#44444d] font-mono text-[11px] text-sky-400 font-bold">
                {s.key}
              </kbd>
            </div>
          ))}
        </div>

        <div className="px-4 py-3 bg-[#1d1d21] border-t border-[#2e2e32] flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded bg-sky-500 hover:bg-sky-400 text-neutral-950 font-semibold cursor-pointer"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
};
