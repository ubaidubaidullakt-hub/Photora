/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { DocumentState } from '../../types';
import { exportDocument, ExportOptions } from '../../engine/importExport';
import { Download, X, FileImage, Lock, Unlock } from 'lucide-react';

interface ExportModalProps {
  document: DocumentState;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ document: doc, onClose }) => {
  const [format, setFormat] = useState<ExportOptions['format']>('png');
  const [quality, setQuality] = useState(0.92);
  const [width, setWidth] = useState(doc.width);
  const [height, setHeight] = useState(doc.height);
  const [lockAspect, setLockAspect] = useState(true);
  const [filename, setFilename] = useState(doc.name || 'Untitled');
  const [transparentBackground, setTransparentBackground] = useState(true);
  const [isExporting, setIsExporting] = useState(false);

  const aspectRatio = doc.width / doc.height;

  const handleWidthChange = (val: number) => {
    setWidth(val);
    if (lockAspect) {
      setHeight(Math.round(val / aspectRatio));
    }
  };

  const handleHeightChange = (val: number) => {
    setHeight(val);
    if (lockAspect) {
      setWidth(Math.round(val * aspectRatio));
    }
  };

  const handleExport = async () => {
    setIsExporting(true);
    try {
      await exportDocument(doc, {
        format,
        quality,
        width,
        height,
        filename,
        transparentBackground,
      });
      onClose();
    } catch (err) {
      console.error('Export failed:', err);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 font-sans select-none">
      <div className="bg-[#242429] border border-[#38383f] rounded-lg shadow-2xl w-full max-w-md overflow-hidden text-neutral-200 text-xs">
        {/* Header */}
        <div className="px-4 py-3 bg-[#1d1d21] border-b border-[#2e2e32] flex items-center justify-between">
          <div className="flex items-center gap-2 font-semibold text-neutral-100 text-sm">
            <Download className="w-4 h-4 text-sky-400" />
            <span>Export Document</span>
          </div>
          <button onClick={onClose} className="p-1 hover:text-white text-neutral-400">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 space-y-4">
          {/* Filename */}
          <div className="space-y-1">
            <label className="text-neutral-400 font-medium">Filename:</label>
            <input
              type="text"
              value={filename}
              onChange={(e) => setFilename(e.target.value)}
              className="w-full bg-[#18181b] border border-[#38383f] rounded px-3 py-1.5 text-neutral-100 outline-none"
            />
          </div>

          {/* Format */}
          <div className="space-y-1">
            <label className="text-neutral-400 font-medium">Format:</label>
            <select
              value={format}
              onChange={(e) => setFormat(e.target.value as ExportOptions['format'])}
              className="w-full bg-[#18181b] border border-[#38383f] rounded px-3 py-1.5 text-neutral-200 outline-none"
            >
              <option value="png">PNG (Lossless with Alpha Transparency)</option>
              <option value="jpeg">JPEG (Standard Compressed)</option>
              <option value="webp">WebP (Modern Web Compressed)</option>
              <option value="bmp">BMP (Standard Windows Bitmap)</option>
              <option value="svg">SVG (Scalable Vector &amp; Embedded Graphics)</option>
              <option value="pixora">PIXORA Editable Project (.pixora)</option>
            </select>
          </div>

          {/* Dimensions */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-neutral-400 font-medium">
              <span>Export Dimensions:</span>
              <button
                onClick={() => setLockAspect(!lockAspect)}
                className="flex items-center gap-1 text-[11px] text-sky-400 hover:text-sky-300"
              >
                {lockAspect ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                <span>{lockAspect ? 'Aspect Ratio Locked' : 'Unlocked'}</span>
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="flex items-center gap-1 bg-[#18181b] border border-[#38383f] px-2 py-1 rounded">
                <span className="text-neutral-500 font-mono">W:</span>
                <input
                  type="number"
                  value={width}
                  onChange={(e) => handleWidthChange(Number(e.target.value))}
                  className="w-full bg-transparent outline-none font-mono text-neutral-200 text-right"
                />
                <span className="text-neutral-500">px</span>
              </div>
              <div className="flex items-center gap-1 bg-[#18181b] border border-[#38383f] px-2 py-1 rounded">
                <span className="text-neutral-500 font-mono">H:</span>
                <input
                  type="number"
                  value={height}
                  onChange={(e) => handleHeightChange(Number(e.target.value))}
                  className="w-full bg-transparent outline-none font-mono text-neutral-200 text-right"
                />
                <span className="text-neutral-500">px</span>
              </div>
            </div>
          </div>

          {/* Quality Slider (for JPEG / WebP) */}
          {['jpeg', 'webp'].includes(format) && (
            <div className="space-y-1 pt-1">
              <div className="flex justify-between text-neutral-400">
                <span>Image Quality:</span>
                <span className="font-mono">{Math.round(quality * 100)}%</span>
              </div>
              <input
                type="range"
                min="0.1"
                max="1"
                step="0.05"
                value={quality}
                onChange={(e) => setQuality(Number(e.target.value))}
                className="w-full"
              />
            </div>
          )}

          {/* Transparency Option (for PNG / WebP) */}
          {['png', 'webp'].includes(format) && (
            <label className="flex items-center gap-2 cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={transparentBackground}
                onChange={(e) => setTransparentBackground(e.target.checked)}
                className="rounded border-[#38383f] bg-[#18181b] text-sky-500 focus:ring-0"
              />
              <span className="text-neutral-300">Preserve Transparent Background</span>
            </label>
          )}
        </div>

        {/* Footer */}
        <div className="px-4 py-3 bg-[#1d1d21] border-t border-[#2e2e32] flex items-center justify-end gap-2">
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded bg-neutral-700 hover:bg-neutral-600 text-white font-medium cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={handleExport}
            disabled={isExporting}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded bg-sky-500 hover:bg-sky-400 text-neutral-950 font-semibold cursor-pointer disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isExporting ? 'Exporting...' : 'Export & Download'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
