/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { DocumentState } from '../../types';
import { restoreHistoryStep } from '../../engine/historyEngine';
import { History, RotateCcw, RotateCw } from 'lucide-react';

interface HistoryPanelProps {
  document: DocumentState;
  onUpdateDocument: (doc: DocumentState) => void;
}

export const HistoryPanel: React.FC<HistoryPanelProps> = ({
  document: doc,
  onUpdateDocument,
}) => {
  const handleJumpToStep = async (index: number) => {
    const restored = await restoreHistoryStep(doc, index);
    onUpdateDocument(restored);
  };

  return (
    <div className="flex flex-col h-full bg-[#202024] text-xs text-neutral-300 select-none font-sans">
      <div className="px-3 py-2 border-b border-[#2e2e32] flex items-center justify-between text-neutral-400 font-medium">
        <span className="flex items-center gap-1.5 text-neutral-200">
          <History className="w-3.5 h-3.5 text-sky-400" />
          <span>History States</span>
        </span>
        <span className="text-[10px] text-neutral-500 font-mono">
          {doc.historyIndex + 1} / {doc.history.length}
        </span>
      </div>

      <div className="flex-1 overflow-y-auto divide-y divide-[#28282e]">
        {doc.history.map((step, idx) => {
          const isActive = idx === doc.historyIndex;
          const isUndone = idx > doc.historyIndex;

          return (
            <div
              key={step.id}
              onClick={() => handleJumpToStep(idx)}
              className={`flex items-center justify-between px-3 py-1.5 cursor-pointer transition-colors ${
                isActive
                  ? 'bg-sky-600/30 text-sky-300 font-semibold border-l-2 border-sky-400'
                  : isUndone
                  ? 'text-neutral-500 opacity-60 hover:bg-[#25252a]'
                  : 'text-neutral-300 hover:bg-[#25252a]'
              }`}
            >
              <span className="truncate">{step.name}</span>
              <span className="text-[10px] font-mono text-neutral-500">#{idx + 1}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
