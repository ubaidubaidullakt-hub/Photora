/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useEffect } from 'react';
import { DocumentState } from '../../types';
import { compositeDocumentToCanvas } from '../../engine/canvasRenderer';
import { Eye, EyeOff } from 'lucide-react';

interface ChannelsPanelProps {
  document: DocumentState;
}

export const ChannelsPanel: React.FC<ChannelsPanelProps> = ({ document: doc }) => {
  const histogramRef = useRef<HTMLCanvasElement>(null);

  // Compute live histogram from document composite
  useEffect(() => {
    const canvas = document.createElement('canvas');
    canvas.width = Math.min(200, doc.width);
    canvas.height = Math.min(150, doc.height);
    compositeDocumentToCanvas(doc, canvas, true);

    const ctx = canvas.getContext('2d');
    const hCanvas = histogramRef.current;
    if (!ctx || !hCanvas) return;

    const hCtx = hCanvas.getContext('2d');
    if (!hCtx) return;

    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
    const rHist = new Uint32Array(256);
    const gHist = new Uint32Array(256);
    const bHist = new Uint32Array(256);

    for (let i = 0; i < imgData.length; i += 4) {
      rHist[imgData[i]]++;
      gHist[imgData[i + 1]]++;
      bHist[imgData[i + 2]]++;
    }

    let maxVal = 1;
    for (let i = 0; i < 256; i++) {
      if (rHist[i] > maxVal) maxVal = rHist[i];
      if (gHist[i] > maxVal) maxVal = gHist[i];
      if (bHist[i] > maxVal) maxVal = bHist[i];
    }

    // Render histogram chart
    hCtx.clearRect(0, 0, hCanvas.width, hCanvas.height);
    hCtx.fillStyle = '#18181b';
    hCtx.fillRect(0, 0, hCanvas.width, hCanvas.height);

    const barW = hCanvas.width / 256;
    for (let i = 0; i < 256; i++) {
      const rh = (rHist[i] / maxVal) * (hCanvas.height - 4);
      const gh = (gHist[i] / maxVal) * (hCanvas.height - 4);
      const bh = (bHist[i] / maxVal) * (hCanvas.height - 4);

      hCtx.fillStyle = 'rgba(239, 68, 68, 0.4)';
      hCtx.fillRect(i * barW, hCanvas.height - rh, barW, rh);

      hCtx.fillStyle = 'rgba(34, 197, 94, 0.4)';
      hCtx.fillRect(i * barW, hCanvas.height - gh, barW, gh);

      hCtx.fillStyle = 'rgba(59, 130, 246, 0.4)';
      hCtx.fillRect(i * barW, hCanvas.height - bh, barW, bh);
    }
  }, [doc]);

  return (
    <div className="flex flex-col h-full bg-[#202024] text-xs text-neutral-300 p-3 select-none font-sans gap-3">
      {/* Histogram Display */}
      <div className="space-y-1.5">
        <div className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">
          Histogram
        </div>
        <div className="w-full h-24 bg-[#18181b] border border-[#38383f] rounded overflow-hidden p-1">
          <canvas ref={histogramRef} width={240} height={88} className="w-full h-full block" />
        </div>
      </div>

      {/* Channels List */}
      <div className="space-y-1 pt-2 border-t border-[#2e2e32]">
        <div className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider mb-2">
          Color Channels
        </div>

        {[
          { id: 'rgb', name: 'RGB', shortcut: 'Ctrl+2', color: 'bg-white' },
          { id: 'r', name: 'Red', shortcut: 'Ctrl+3', color: 'bg-rose-500' },
          { id: 'g', name: 'Green', shortcut: 'Ctrl+4', color: 'bg-emerald-500' },
          { id: 'b', name: 'Blue', shortcut: 'Ctrl+5', color: 'bg-sky-500' },
          { id: 'a', name: 'Alpha', shortcut: 'Ctrl+6', color: 'bg-neutral-400' },
        ].map((ch) => (
          <div
            key={ch.id}
            className="flex items-center justify-between px-2.5 py-1.5 rounded hover:bg-[#28282e] cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <Eye className="w-3.5 h-3.5 text-neutral-400" />
              <div className={`w-3 h-3 rounded-full ${ch.color}`} />
              <span className="font-medium text-neutral-200">{ch.name}</span>
            </div>
            <span className="text-[10px] font-mono text-neutral-500">{ch.shortcut}</span>
          </div>
        ))}
      </div>
    </div>
  );
};
