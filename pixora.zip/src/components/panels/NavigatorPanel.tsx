/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useEffect } from 'react';
import { DocumentState } from '../../types';
import { compositeDocumentToCanvas } from '../../engine/canvasRenderer';
import { ZoomIn, ZoomOut, Maximize2 } from 'lucide-react';

interface NavigatorPanelProps {
  document: DocumentState;
  onUpdateZoom: (zoom: number) => void;
  onResetZoom: () => void;
}

export const NavigatorPanel: React.FC<NavigatorPanelProps> = ({
  document: doc,
  onUpdateZoom,
  onResetZoom,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    compositeDocumentToCanvas(doc, canvas, true);
  }, [doc]);

  return (
    <div className="flex flex-col h-full bg-[#202024] text-xs text-neutral-300 p-3 gap-3 select-none font-sans">
      <div className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">
        Navigator Minimap
      </div>

      {/* Minimap Canvas with red viewport rectangle indicator */}
      <div className="w-full h-32 bg-[#18181b] border border-[#38383f] rounded overflow-hidden flex items-center justify-center p-1 relative">
        <canvas
          ref={canvasRef}
          width={220}
          height={120}
          className="max-w-full max-h-full object-contain block"
        />
        {/* Red Viewport Outline */}
        <div className="absolute inset-2 border border-red-500/70 pointer-events-none" />
      </div>

      {/* Zoom Controls Slider */}
      <div className="flex items-center gap-2 pt-1">
        <ZoomOut className="w-3.5 h-3.5 text-neutral-400" />
        <input
          type="range"
          min="0.1"
          max="5"
          step="0.05"
          value={doc.zoom}
          onChange={(e) => onUpdateZoom(Number(e.target.value))}
          className="flex-1 cursor-pointer"
        />
        <ZoomIn className="w-3.5 h-3.5 text-neutral-400" />
        <span className="font-mono text-neutral-200 w-12 text-right">
          {Math.round(doc.zoom * 100)}%
        </span>
      </div>

      <button
        onClick={onResetZoom}
        className="w-full py-1 rounded bg-[#2a2a30] hover:bg-[#32323a] text-neutral-200 font-medium transition-colors cursor-pointer"
      >
        Fit to Screen
      </button>
    </div>
  );
};
