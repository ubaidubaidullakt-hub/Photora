/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { DocumentState, Layer } from '../../types';
import { Sliders, Maximize, Move } from 'lucide-react';

interface PropertiesPanelProps {
  document: DocumentState;
  onUpdateDocument: (doc: DocumentState, actionName?: string) => void;
}

export const PropertiesPanel: React.FC<PropertiesPanelProps> = ({
  document: doc,
  onUpdateDocument,
}) => {
  const activeLayer = doc.layers.find((l) => l.id === doc.activeLayerId);

  if (!activeLayer) {
    return (
      <div className="p-4 text-neutral-500 text-center text-xs">
        No active layer selected
      </div>
    );
  }

  const handleUpdateLayer = (patch: Partial<Layer>) => {
    const updated = doc.layers.map((l) =>
      l.id === activeLayer.id ? { ...l, ...patch } : l
    );
    onUpdateDocument({ ...doc, layers: updated });
  };

  return (
    <div className="flex flex-col h-full bg-[#202024] text-xs text-neutral-300 p-3 gap-4 font-sans select-none overflow-y-auto">
      {/* Layer Coordinates & Dimensions */}
      <div className="space-y-2">
        <div className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">
          Transform &amp; Position
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div className="flex items-center gap-2 bg-[#18181b] border border-[#38383f] px-2 py-1 rounded">
            <span className="text-neutral-500 font-mono">X:</span>
            <input
              type="number"
              value={Math.round(activeLayer.x)}
              onChange={(e) => handleUpdateLayer({ x: Number(e.target.value) })}
              className="w-full bg-transparent outline-none font-mono text-neutral-200 text-right"
            />
            <span className="text-neutral-500">px</span>
          </div>

          <div className="flex items-center gap-2 bg-[#18181b] border border-[#38383f] px-2 py-1 rounded">
            <span className="text-neutral-500 font-mono">Y:</span>
            <input
              type="number"
              value={Math.round(activeLayer.y)}
              onChange={(e) => handleUpdateLayer({ y: Number(e.target.value) })}
              className="w-full bg-transparent outline-none font-mono text-neutral-200 text-right"
            />
            <span className="text-neutral-500">px</span>
          </div>

          <div className="flex items-center gap-2 bg-[#18181b] border border-[#38383f] px-2 py-1 rounded">
            <span className="text-neutral-500 font-mono">W:</span>
            <input
              type="number"
              value={Math.round(activeLayer.width)}
              onChange={(e) => handleUpdateLayer({ width: Math.max(1, Number(e.target.value)) })}
              className="w-full bg-transparent outline-none font-mono text-neutral-200 text-right"
            />
            <span className="text-neutral-500">px</span>
          </div>

          <div className="flex items-center gap-2 bg-[#18181b] border border-[#38383f] px-2 py-1 rounded">
            <span className="text-neutral-500 font-mono">H:</span>
            <input
              type="number"
              value={Math.round(activeLayer.height)}
              onChange={(e) => handleUpdateLayer({ height: Math.max(1, Number(e.target.value)) })}
              className="w-full bg-transparent outline-none font-mono text-neutral-200 text-right"
            />
            <span className="text-neutral-500">px</span>
          </div>
        </div>
      </div>

      {/* Layer Mask Controls (if mask exists) */}
      {activeLayer.maskCanvas && (
        <div className="space-y-3 pt-2 border-t border-[#2e2e32]">
          <div className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">
            Layer Mask Properties
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-neutral-400">
              <span>Mask Density:</span>
              <span className="font-mono">{Math.round(activeLayer.maskDensity * 100)}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={activeLayer.maskDensity}
              onChange={(e) => handleUpdateLayer({ maskDensity: Number(e.target.value) })}
              className="w-full cursor-pointer"
            />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-neutral-400">
              <span>Mask Feather:</span>
              <span className="font-mono">{activeLayer.maskFeather}px</span>
            </div>
            <input
              type="range"
              min="0"
              max="50"
              value={activeLayer.maskFeather}
              onChange={(e) => handleUpdateLayer({ maskFeather: Number(e.target.value) })}
              className="w-full cursor-pointer"
            />
          </div>
        </div>
      )}
    </div>
  );
};
