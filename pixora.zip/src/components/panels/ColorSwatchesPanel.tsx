/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { hexToRgb } from '../../engine/imageProcessing';
import { Plus } from 'lucide-react';

interface ColorSwatchesPanelProps {
  foregroundColor: string;
  backgroundColor: string;
  onChangeForegroundColor: (color: string) => void;
  onChangeBackgroundColor: (color: string) => void;
}

export const ColorSwatchesPanel: React.FC<ColorSwatchesPanelProps> = ({
  foregroundColor,
  backgroundColor,
  onChangeForegroundColor,
  onChangeBackgroundColor,
}) => {
  const [swatches, setSwatches] = useState<string[]>([
    '#000000',
    '#ffffff',
    '#ef4444',
    '#f97316',
    '#f59e0b',
    '#eab308',
    '#84cc16',
    '#22c55e',
    '#10b981',
    '#06b6d4',
    '#0ea5e9',
    '#3b82f6',
    '#6366f1',
    '#8b5cf6',
    '#a855f7',
    '#d946ef',
    '#ec4899',
    '#f43f5e',
    '#78716c',
    '#18181b',
  ]);

  const rgb = hexToRgb(foregroundColor);

  const handleAddSwatch = () => {
    if (!swatches.includes(foregroundColor)) {
      setSwatches([...swatches, foregroundColor]);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#202024] text-xs text-neutral-300 p-3 gap-4 select-none font-sans overflow-y-auto">
      {/* Primary Color Picker */}
      <div className="space-y-2">
        <div className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">
          Color Spectrum
        </div>
        <div className="flex items-center gap-3">
          <input
            type="color"
            value={foregroundColor}
            onChange={(e) => onChangeForegroundColor(e.target.value)}
            className="w-16 h-14 rounded border border-[#38383f] bg-transparent cursor-pointer"
          />
          <div className="space-y-1 flex-1">
            <div className="flex items-center gap-1.5 bg-[#18181b] border border-[#38383f] px-2 py-1 rounded">
              <span className="text-neutral-500 font-mono">HEX:</span>
              <input
                type="text"
                value={foregroundColor.toUpperCase()}
                onChange={(e) => onChangeForegroundColor(e.target.value)}
                className="w-full bg-transparent outline-none font-mono text-neutral-200"
              />
            </div>
            <div className="grid grid-cols-3 gap-1 text-[11px] font-mono text-neutral-400">
              <div className="bg-[#18181b] border border-[#38383f] px-1 py-0.5 rounded text-center">
                R: <span className="text-neutral-200">{rgb.r}</span>
              </div>
              <div className="bg-[#18181b] border border-[#38383f] px-1 py-0.5 rounded text-center">
                G: <span className="text-neutral-200">{rgb.g}</span>
              </div>
              <div className="bg-[#18181b] border border-[#38383f] px-1 py-0.5 rounded text-center">
                B: <span className="text-neutral-200">{rgb.b}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Swatches Grid */}
      <div className="space-y-2 pt-2 border-t border-[#2e2e32]">
        <div className="flex items-center justify-between text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">
          <span>Swatches</span>
          <button
            onClick={handleAddSwatch}
            className="p-1 hover:text-white rounded hover:bg-[#28282e]"
            title="Add current color to swatches"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-5 gap-1.5">
          {swatches.map((color, i) => (
            <button
              key={i}
              onClick={() => onChangeForegroundColor(color)}
              className="w-7 h-7 rounded-xs border border-[#38383f] hover:scale-110 transition-transform cursor-pointer shadow-xs"
              style={{ backgroundColor: color }}
              title={color}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
