/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import { DocumentState, TimelineFrame } from '../../types';
import { Play, Square, Plus, Trash2, Copy, Repeat } from 'lucide-react';

interface TimelinePanelProps {
  document: DocumentState;
  onUpdateDocument: (doc: DocumentState, actionName?: string) => void;
}

export const TimelinePanel: React.FC<TimelinePanelProps> = ({
  document: doc,
  onUpdateDocument,
}) => {
  // Playback timer effect
  useEffect(() => {
    if (!doc.isPlayingTimeline || doc.frames.length <= 1) return;
    const currentFrame = doc.frames[doc.activeFrameIndex] || doc.frames[0];
    const timer = setTimeout(() => {
      const nextIndex = (doc.activeFrameIndex + 1) % doc.frames.length;
      onUpdateDocument({ ...doc, activeFrameIndex: nextIndex });
    }, (currentFrame.duration || 0.2) * 1000);

    return () => clearTimeout(timer);
  }, [doc.isPlayingTimeline, doc.activeFrameIndex, doc.frames]);

  const togglePlayback = () => {
    onUpdateDocument({
      ...doc,
      isPlayingTimeline: !doc.isPlayingTimeline,
    });
  };

  const handleAddFrame = () => {
    const newFrame: TimelineFrame = {
      id: 'frame_' + Date.now(),
      duration: 0.2,
      layerStates: {},
    };
    onUpdateDocument(
      {
        ...doc,
        frames: [...doc.frames, newFrame],
        activeFrameIndex: doc.frames.length,
      },
      'Add Animation Frame'
    );
  };

  const handleDeleteFrame = (index: number) => {
    if (doc.frames.length <= 1) return;
    const filtered = doc.frames.filter((_, i) => i !== index);
    onUpdateDocument(
      {
        ...doc,
        frames: filtered,
        activeFrameIndex: Math.max(0, index - 1),
      },
      'Delete Frame'
    );
  };

  const handleSelectFrame = (index: number) => {
    onUpdateDocument({ ...doc, activeFrameIndex: index });
  };

  const handleChangeDuration = (index: number, duration: number) => {
    const updated = doc.frames.map((f, i) => (i === index ? { ...f, duration } : f));
    onUpdateDocument({ ...doc, frames: updated });
  };

  return (
    <div className="h-32 bg-[#202024] border-t border-[#2e2e32] flex flex-col text-xs text-neutral-300 select-none font-sans">
      {/* Top Controls Bar */}
      <div className="h-8 px-3 border-b border-[#2e2e32] flex items-center justify-between bg-[#1b1b1f]">
        <div className="flex items-center gap-2">
          <button
            onClick={togglePlayback}
            className="flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-sky-500 hover:bg-sky-400 text-neutral-950 font-bold cursor-pointer"
          >
            {doc.isPlayingTimeline ? (
              <>
                <Square className="w-3 h-3 fill-current" />
                <span>Stop</span>
              </>
            ) : (
              <>
                <Play className="w-3 h-3 fill-current" />
                <span>Play</span>
              </>
            )}
          </button>

          <span className="text-[11px] text-neutral-400 font-mono">
            Frame {doc.activeFrameIndex + 1} of {doc.frames.length}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleAddFrame}
            className="flex items-center gap-1 px-2 py-0.5 rounded bg-[#2a2a30] hover:bg-[#34343d] text-neutral-200 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Frame</span>
          </button>
        </div>
      </div>

      {/* Frame Strip */}
      <div className="flex-1 overflow-x-auto p-2 flex items-center gap-2">
        {doc.frames.map((frame, idx) => {
          const isActive = idx === doc.activeFrameIndex;
          return (
            <div
              key={frame.id}
              onClick={() => handleSelectFrame(idx)}
              className={`w-20 h-20 rounded bg-[#18181b] border flex flex-col items-center justify-between p-1.5 cursor-pointer shrink-0 transition-colors ${
                isActive ? 'border-sky-400 ring-1 ring-sky-400/50 bg-[#25252b]' : 'border-[#38383f] hover:border-neutral-500'
              }`}
            >
              <div className="w-full flex items-center justify-between text-[10px] text-neutral-400 font-mono">
                <span>#{idx + 1}</span>
                {doc.frames.length > 1 && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteFrame(idx);
                    }}
                    className="hover:text-rose-400"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                )}
              </div>

              <div className="text-[11px] font-medium text-neutral-200">
                {frame.duration}s
              </div>

              <select
                value={frame.duration}
                onChange={(e) => handleChangeDuration(idx, Number(e.target.value))}
                onClick={(e) => e.stopPropagation()}
                className="w-full bg-[#18181b] border border-[#38383f] rounded text-[9px] text-neutral-300 outline-none"
              >
                <option value={0.1}>0.1 sec</option>
                <option value={0.2}>0.2 sec</option>
                <option value={0.5}>0.5 sec</option>
                <option value={1.0}>1.0 sec</option>
              </select>
            </div>
          );
        })}
      </div>
    </div>
  );
};
