/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Layer,
  BlendMode,
  DocumentState,
  ActiveModal,
} from '../../types';
import { BLEND_MODE_DISPLAY_NAMES } from '../../engine/blendModes';
import { generateLayerThumbnail } from '../../engine/canvasRenderer';
import {
  Eye,
  EyeOff,
  Lock,
  Unlock,
  Trash2,
  Copy,
  Plus,
  Folder,
  Sliders,
  Sparkles,
  ChevronDown,
  Layers as LayersIcon,
  Square,
  Type,
  Image as ImageIcon,
} from 'lucide-react';

interface LayersPanelProps {
  document: DocumentState;
  onUpdateDocument: (doc: DocumentState, actionName?: string) => void;
  onOpenModal: (modal: ActiveModal) => void;
}

export const LayersPanel: React.FC<LayersPanelProps> = ({
  document: doc,
  onUpdateDocument,
  onOpenModal,
}) => {
  const [editingLayerId, setEditingLayerId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState('');

  const activeLayer = doc.layers.find((l) => l.id === doc.activeLayerId) || doc.layers[0];

  // Change active layer
  const handleSelectLayer = (layerId: string, target: 'layer' | 'mask' = 'layer') => {
    const updated = doc.layers.map((l) => {
      if (l.id === layerId) {
        return { ...l, editingTarget: target };
      }
      return l;
    });
    onUpdateDocument({
      ...doc,
      layers: updated,
      activeLayerId: layerId,
    });
  };

  // Toggle layer visibility
  const handleToggleVisibility = (layerId: string) => {
    const updated = doc.layers.map((l) =>
      l.id === layerId ? { ...l, visible: !l.visible } : l
    );
    onUpdateDocument({ ...doc, layers: updated }, 'Toggle Layer Visibility');
  };

  // Toggle layer lock
  const handleToggleLock = (layerId: string) => {
    const updated = doc.layers.map((l) =>
      l.id === layerId ? { ...l, locked: !l.locked } : l
    );
    onUpdateDocument({ ...doc, layers: updated }, 'Toggle Layer Lock');
  };

  // Update blend mode
  const handleChangeBlendMode = (mode: BlendMode) => {
    if (!activeLayer) return;
    const updated = doc.layers.map((l) =>
      l.id === activeLayer.id ? { ...l, blendMode: mode } : l
    );
    onUpdateDocument({ ...doc, layers: updated }, `Set Blend Mode: ${mode}`);
  };

  // Update opacity
  const handleChangeOpacity = (opacity: number) => {
    if (!activeLayer) return;
    const updated = doc.layers.map((l) =>
      l.id === activeLayer.id ? { ...l, opacity } : l
    );
    onUpdateDocument({ ...doc, layers: updated });
  };

  // Add new blank pixel layer
  const handleAddLayer = () => {
    const canvas = document.createElement('canvas');
    canvas.width = doc.width;
    canvas.height = doc.height;
    const newLayer: Layer = {
      id: 'layer_' + Date.now(),
      name: `Layer ${doc.layers.length + 1}`,
      type: 'pixel',
      visible: true,
      locked: false,
      opacity: 1,
      fillOpacity: 1,
      blendMode: 'normal',
      x: 0,
      y: 0,
      width: doc.width,
      height: doc.height,
      canvas,
      maskEnabled: false,
      maskInverted: false,
      maskLinked: true,
      maskDensity: 1,
      maskFeather: 0,
    };
    onUpdateDocument(
      {
        ...doc,
        layers: [newLayer, ...doc.layers], // Add to top of stack
        activeLayerId: newLayer.id,
      },
      'New Layer'
    );
  };

  // Duplicate active layer
  const handleDuplicateLayer = () => {
    if (!activeLayer) return;
    const canvas = document.createElement('canvas');
    canvas.width = activeLayer.canvas.width;
    canvas.height = activeLayer.canvas.height;
    const ctx = canvas.getContext('2d');
    if (ctx) ctx.drawImage(activeLayer.canvas, 0, 0);

    const dupLayer: Layer = {
      ...activeLayer,
      id: 'layer_' + Date.now(),
      name: `${activeLayer.name} Copy`,
      canvas,
      x: activeLayer.x + 10,
      y: activeLayer.y + 10,
    };

    onUpdateDocument(
      {
        ...doc,
        layers: [dupLayer, ...doc.layers],
        activeLayerId: dupLayer.id,
      },
      'Duplicate Layer'
    );
  };

  // Delete active layer
  const handleDeleteLayer = () => {
    if (doc.layers.length <= 1) return; // Prevent deleting last layer
    const filtered = doc.layers.filter((l) => l.id !== activeLayer?.id);
    onUpdateDocument(
      {
        ...doc,
        layers: filtered,
        activeLayerId: filtered[0].id,
      },
      'Delete Layer'
    );
  };

  // Add Layer Mask to active layer
  const handleAddMask = () => {
    if (!activeLayer || activeLayer.maskCanvas) return;
    const maskCanvas = document.createElement('canvas');
    maskCanvas.width = activeLayer.width;
    maskCanvas.height = activeLayer.height;
    const mCtx = maskCanvas.getContext('2d');
    if (mCtx) {
      // Default: reveal all (opaque white)
      mCtx.fillStyle = '#ffffff';
      mCtx.fillRect(0, 0, maskCanvas.width, maskCanvas.height);
    }

    const updated = doc.layers.map((l) =>
      l.id === activeLayer.id
        ? {
            ...l,
            maskCanvas,
            maskEnabled: true,
            editingTarget: 'mask' as const,
          }
        : l
    );
    onUpdateDocument({ ...doc, layers: updated }, 'Add Layer Mask');
  };

  // Start renaming layer
  const handleStartRename = (layer: Layer) => {
    setEditingLayerId(layer.id);
    setEditingName(layer.name);
  };

  // Submit layer rename
  const handleFinishRename = (layerId: string) => {
    if (editingName.trim()) {
      const updated = doc.layers.map((l) =>
        l.id === layerId ? { ...l, name: editingName.trim() } : l
      );
      onUpdateDocument({ ...doc, layers: updated });
    }
    setEditingLayerId(null);
  };

  return (
    <div className="flex flex-col h-full bg-[#202024] text-xs text-neutral-300 select-none font-sans">
      {/* Top Header: Blend Mode & Opacity */}
      <div className="p-2 border-b border-[#2e2e32] flex items-center justify-between gap-2">
        <select
          value={activeLayer?.blendMode || 'normal'}
          onChange={(e) => handleChangeBlendMode(e.target.value as BlendMode)}
          className="bg-[#18181b] border border-[#38383f] rounded px-2 py-1 text-xs text-neutral-200 outline-none flex-1 font-medium cursor-pointer"
        >
          {Object.entries(BLEND_MODE_DISPLAY_NAMES).map(([key, name]) => (
            <option key={key} value={key}>
              {name}
            </option>
          ))}
        </select>

        <div className="flex items-center gap-1.5 w-24">
          <span className="text-neutral-400 text-[10px]">Opacity:</span>
          <input
            type="number"
            min="0"
            max="100"
            value={Math.round((activeLayer?.opacity ?? 1) * 100)}
            onChange={(e) => handleChangeOpacity(Number(e.target.value) / 100)}
            className="w-10 px-1 py-0.5 bg-[#18181b] border border-[#38383f] rounded font-mono text-center text-neutral-200 text-xs"
          />
          <span className="text-neutral-400 text-[10px]">%</span>
        </div>
      </div>

      {/* Layer List Stack (Rendered top-to-bottom) */}
      <div className="flex-1 overflow-y-auto divide-y divide-[#2a2a30]">
        {doc.layers.map((layer) => {
          const isActive = layer.id === doc.activeLayerId;
          const isMaskActive = isActive && layer.editingTarget === 'mask';
          const isLayerActive = isActive && layer.editingTarget !== 'mask';

          return (
            <div
              key={layer.id}
              onClick={() => handleSelectLayer(layer.id, 'layer')}
              className={`flex items-center gap-2 px-2.5 py-1.5 transition-colors cursor-pointer ${
                isActive ? 'bg-[#2b2b32] text-white' : 'hover:bg-[#25252a]'
              }`}
            >
              {/* Eye Visibility Toggle */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleToggleVisibility(layer.id);
                }}
                className="text-neutral-400 hover:text-white"
                title={layer.visible ? 'Hide Layer' : 'Show Layer'}
              >
                {layer.visible ? (
                  <Eye className="w-3.5 h-3.5" />
                ) : (
                  <EyeOff className="w-3.5 h-3.5 text-neutral-600" />
                )}
              </button>

              {/* Layer Thumbnail */}
              <div
                onClick={(e) => {
                  e.stopPropagation();
                  handleSelectLayer(layer.id, 'layer');
                }}
                className={`w-9 h-9 rounded-xs bg-[#18181b] border overflow-hidden shrink-0 flex items-center justify-center ${
                  isLayerActive ? 'border-sky-400 ring-1 ring-sky-400/50' : 'border-[#3f3f46]'
                }`}
              >
                <img
                  src={generateLayerThumbnail(layer, 36)}
                  alt={layer.name}
                  className="w-full h-full object-contain"
                />
              </div>

              {/* Layer Mask Thumbnail (if exists) */}
              {layer.maskCanvas && (
                <div
                  onClick={(e) => {
                    e.stopPropagation();
                    handleSelectLayer(layer.id, 'mask');
                  }}
                  className={`w-9 h-9 rounded-xs bg-black border overflow-hidden shrink-0 flex items-center justify-center relative ${
                    isMaskActive ? 'border-sky-400 ring-1 ring-sky-400/50' : 'border-[#3f3f46]'
                  }`}
                  title="Layer Mask (Click to paint on mask)"
                >
                  <img
                    src={layer.maskCanvas.toDataURL()}
                    alt="Mask"
                    className="w-full h-full object-contain"
                  />
                  <div className="absolute bottom-0 right-0 w-2 h-2 bg-sky-500 rounded-tl-xs" />
                </div>
              )}

              {/* Layer Name & Type */}
              <div className="flex-1 min-w-0">
                {editingLayerId === layer.id ? (
                  <input
                    type="text"
                    value={editingName}
                    autoFocus
                    onChange={(e) => setEditingName(e.target.value)}
                    onBlur={() => handleFinishRename(layer.id)}
                    onKeyDown={(e) => e.key === 'Enter' && handleFinishRename(layer.id)}
                    className="w-full bg-[#18181b] px-1 py-0.5 rounded text-neutral-100 outline-none border border-sky-500"
                  />
                ) : (
                  <div
                    onDoubleClick={() => handleStartRename(layer)}
                    className="truncate font-medium flex items-center gap-1.5"
                  >
                    <span>{layer.name}</span>
                    {layer.effects?.dropShadow?.enabled && (
                      <span className="text-[10px] text-sky-400 font-mono font-bold">fx</span>
                    )}
                  </div>
                )}
                <div className="text-[10px] text-neutral-500 capitalize flex items-center gap-1">
                  <span>{layer.type}</span>
                  {layer.blendMode !== 'normal' && (
                    <>
                      <span>·</span>
                      <span className="text-neutral-400">{BLEND_MODE_DISPLAY_NAMES[layer.blendMode]}</span>
                    </>
                  )}
                </div>
              </div>

              {/* Lock Toggle */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleToggleLock(layer.id);
                }}
                className={`p-1 rounded ${
                  layer.locked ? 'text-amber-400' : 'text-neutral-500 hover:text-white'
                }`}
                title={layer.locked ? 'Unlock Layer' : 'Lock Layer'}
              >
                {layer.locked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3 h-3" />}
              </button>
            </div>
          );
        })}
      </div>

      {/* Bottom Action Bar */}
      <div className="h-9 px-2 border-t border-[#2e2e32] bg-[#1d1d21] flex items-center justify-between text-neutral-400">
        <button
          onClick={() => onOpenModal('layerStyles')}
          className="p-1 hover:text-white rounded hover:bg-[#2b2b32] font-mono font-bold text-xs"
          title="Layer Styles (fx)"
        >
          fx
        </button>

        <button
          onClick={handleAddMask}
          className="p-1 hover:text-white rounded hover:bg-[#2b2b32]"
          title="Add Layer Mask"
        >
          <Square className="w-3.5 h-3.5 stroke-[2]" />
        </button>

        <button
          onClick={() => onOpenModal('adjustments')}
          className="p-1 hover:text-white rounded hover:bg-[#2b2b32]"
          title="New Adjustment Layer"
        >
          <Sliders className="w-3.5 h-3.5" />
        </button>

        <button
          onClick={handleDuplicateLayer}
          className="p-1 hover:text-white rounded hover:bg-[#2b2b32]"
          title="Duplicate Layer"
        >
          <Copy className="w-3.5 h-3.5" />
        </button>

        <button
          onClick={handleAddLayer}
          className="p-1 hover:text-white rounded hover:bg-[#2b2b32]"
          title="New Blank Layer"
        >
          <Plus className="w-4 h-4" />
        </button>

        <button
          onClick={handleDeleteLayer}
          disabled={doc.layers.length <= 1}
          className="p-1 hover:text-rose-400 rounded hover:bg-[#2b2b32] disabled:opacity-30 disabled:hover:text-neutral-400"
          title="Delete Layer"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
