/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  DocumentState,
  ToolType,
  ToolSettings,
  ActiveModal,
} from '../../types';
import {
  Undo,
  Redo,
  Layers as LayersIcon,
  Sliders,
  Download,
  Plus,
  Brush,
  Eraser,
  Move,
  Square,
  Wand2,
  PaintBucket,
  Maximize2,
  Pipette,
  Package,
  CheckCircle2,
  MoreVertical,
} from 'lucide-react';
import { LayersPanel } from '../panels/LayersPanel';
import { PropertiesPanel } from '../panels/PropertiesPanel';

interface MobileWorkspaceProps {
  document: DocumentState;
  activeTool: ToolType;
  settings: ToolSettings;
  onSelectTool: (tool: ToolType) => void;
  onUpdateDocument: (doc: DocumentState, actionName?: string) => void;
  onUpdateSettings: (patch: Partial<ToolSettings>) => void;
  onOpenModal: (modal: ActiveModal) => void;
  onUndo: () => void;
  onRedo: () => void;
  canUndo: boolean;
  canRedo: boolean;
}

export const MobileWorkspace: React.FC<MobileWorkspaceProps> = ({
  document: doc,
  activeTool,
  settings,
  onSelectTool,
  onUpdateDocument,
  onUpdateSettings,
  onOpenModal,
  onUndo,
  onRedo,
  canUndo,
  canRedo,
}) => {
  const [activeDrawer, setActiveDrawer] = useState<'layers' | 'properties' | null>(null);

  const mobileTools: { id: ToolType; label: string; icon: React.ReactNode }[] = [
    { id: 'brush', label: 'Brush', icon: <Brush className="w-5 h-5" /> },
    { id: 'eraser', label: 'Eraser', icon: <Eraser className="w-5 h-5" /> },
    { id: 'move', label: 'Move', icon: <Move className="w-5 h-5" /> },
    { id: 'rectMarquee', label: 'Select', icon: <Square className="w-5 h-5" /> },
    { id: 'magicWand', label: 'Wand', icon: <Wand2 className="w-5 h-5" /> },
    { id: 'bucket', label: 'Fill', icon: <PaintBucket className="w-5 h-5" /> },
    { id: 'eyedropper', label: 'Sample', icon: <Pipette className="w-5 h-5" /> },
  ];

  return (
    <>
      {/* Compact Top Mobile Header */}
      <div className="h-12 bg-[#202024] border-b border-[#2e2e32] flex items-center justify-between px-3 text-neutral-200 z-40 select-none">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded bg-sky-500/20 border border-sky-400/40 flex items-center justify-center text-xs text-sky-400 font-black">
            Px
          </div>
          <span className="font-bold text-sm tracking-wide text-neutral-100">PIXORA</span>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={onUndo}
            disabled={!canUndo}
            className="p-2 rounded hover:bg-[#2b2b32] text-neutral-300 disabled:opacity-30"
            title="Undo"
          >
            <Undo className="w-4 h-4" />
          </button>
          <button
            onClick={onRedo}
            disabled={!canRedo}
            className="p-2 rounded hover:bg-[#2b2b32] text-neutral-300 disabled:opacity-30"
            title="Redo"
          >
            <Redo className="w-4 h-4" />
          </button>

          <button
            onClick={() => onOpenModal('automatedTests')}
            className="p-2 rounded hover:bg-[#2b2b32] text-emerald-400"
            title="Automated Tests"
          >
            <CheckCircle2 className="w-4 h-4" />
          </button>

          <button
            onClick={() => onOpenModal('projectZip')}
            className="p-2 rounded hover:bg-[#2b2b32] text-sky-400"
            title="Download ZIP"
          >
            <Package className="w-4 h-4" />
          </button>

          <button
            onClick={() => onOpenModal('export')}
            className="px-3 py-1 bg-sky-500 text-neutral-950 font-bold rounded text-xs ml-1"
          >
            Export
          </button>
        </div>
      </div>

      {/* Floating Bottom Action Drawer Toggles */}
      <div className="fixed bottom-16 right-4 flex flex-col gap-2 z-40">
        <button
          onClick={() => setActiveDrawer(activeDrawer === 'layers' ? null : 'layers')}
          className={`w-11 h-11 rounded-full flex items-center justify-center shadow-xl border cursor-pointer ${
            activeDrawer === 'layers'
              ? 'bg-sky-500 text-neutral-950 border-sky-400'
              : 'bg-[#202024] text-neutral-200 border-[#38383f]'
          }`}
          title="Layers"
        >
          <LayersIcon className="w-5 h-5" />
        </button>

        <button
          onClick={() => setActiveDrawer(activeDrawer === 'properties' ? null : 'properties')}
          className={`w-11 h-11 rounded-full flex items-center justify-center shadow-xl border cursor-pointer ${
            activeDrawer === 'properties'
              ? 'bg-sky-500 text-neutral-950 border-sky-400'
              : 'bg-[#202024] text-neutral-200 border-[#38383f]'
          }`}
          title="Properties"
        >
          <Sliders className="w-5 h-5" />
        </button>
      </div>

      {/* Mobile Slide-Up Drawer for Layers / Properties */}
      {activeDrawer && (
        <div className="fixed inset-x-0 bottom-16 top-1/2 bg-[#202024] border-t border-[#38383f] z-40 flex flex-col shadow-2xl rounded-t-xl overflow-hidden animate-in slide-in-from-bottom duration-200">
          <div className="h-9 px-4 bg-[#1b1b1f] border-b border-[#2e2e32] flex items-center justify-between text-xs font-semibold text-neutral-300">
            <span className="capitalize">{activeDrawer} Panel</span>
            <button
              onClick={() => setActiveDrawer(null)}
              className="text-neutral-400 hover:text-white font-bold"
            >
              ✕
            </button>
          </div>
          <div className="flex-1 overflow-y-auto">
            {activeDrawer === 'layers' && (
              <LayersPanel
                document={doc}
                onUpdateDocument={onUpdateDocument}
                onOpenModal={onOpenModal}
              />
            )}
            {activeDrawer === 'properties' && (
              <PropertiesPanel document={doc} onUpdateDocument={onUpdateDocument} />
            )}
          </div>
        </div>
      )}

      {/* Bottom Contextual Tool Dock */}
      <div className="h-16 bg-[#202024] border-t border-[#2e2e32] flex items-center px-2 z-40 select-none overflow-x-auto gap-1">
        {mobileTools.map((t) => {
          const isActive = activeTool === t.id;
          return (
            <button
              key={t.id}
              onClick={() => onSelectTool(t.id)}
              className={`flex-1 min-w-[56px] h-12 rounded-lg flex flex-col items-center justify-center gap-0.5 transition-colors cursor-pointer ${
                isActive
                  ? 'bg-sky-500/20 text-sky-400 font-bold border border-sky-400/40'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {t.icon}
              <span className="text-[10px] leading-tight">{t.label}</span>
            </button>
          );
        })}

        {/* Foreground Color Picker Circle */}
        <div className="min-w-[48px] h-12 flex flex-col items-center justify-center">
          <input
            type="color"
            value={settings.activeColor}
            onChange={(e) => onUpdateSettings({ activeColor: e.target.value })}
            className="w-7 h-7 rounded-full border border-white/50 cursor-pointer bg-transparent"
          />
          <span className="text-[9px] text-neutral-400 mt-0.5">Color</span>
        </div>
      </div>
    </>
  );
};
