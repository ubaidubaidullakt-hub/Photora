/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Move,
  Square,
  Circle,
  Lasso,
  Wand2,
  Crop,
  Pipette,
  Bandage,
  Stamp,
  Brush,
  Pencil,
  Eraser,
  PaintBucket,
  Pen,
  Type,
  Hand,
  ZoomIn,
  RotateCw,
  Sparkles,
  Droplet,
  Sun,
  Flame,
  ArrowRightLeft,
  ChevronRight,
} from 'lucide-react';
import { ToolType } from '../../types';

interface ToolbarProps {
  activeTool: ToolType;
  onSelectTool: (tool: ToolType) => void;
  foregroundColor: string;
  backgroundColor: string;
  onSwapColors: () => void;
  onResetColors: () => void;
  onChangeForegroundColor: (color: string) => void;
  onChangeBackgroundColor: (color: string) => void;
}

interface ToolItem {
  id: ToolType;
  name: string;
  shortcut: string;
  icon: React.ReactNode;
  group?: ToolType[];
}

export const Toolbar: React.FC<ToolbarProps> = ({
  activeTool,
  onSelectTool,
  foregroundColor,
  backgroundColor,
  onSwapColors,
  onResetColors,
  onChangeForegroundColor,
  onChangeBackgroundColor,
}) => {
  const [activeFlyout, setActiveFlyout] = useState<string | null>(null);

  const tools: ToolItem[] = [
    { id: 'move', name: 'Move Tool', shortcut: 'V', icon: <Move className="w-4 h-4" /> },
    {
      id: 'rectMarquee',
      name: 'Rectangular Marquee',
      shortcut: 'M',
      icon: <Square className="w-4 h-4" />,
      group: ['rectMarquee', 'ellipseMarquee'],
    },
    {
      id: 'lasso',
      name: 'Lasso Tool',
      shortcut: 'L',
      icon: <Lasso className="w-4 h-4" />,
      group: ['lasso', 'polygonalLasso'],
    },
    {
      id: 'magicWand',
      name: 'Magic Wand Tool',
      shortcut: 'W',
      icon: <Wand2 className="w-4 h-4" />,
      group: ['magicWand', 'quickSelect'],
    },
    { id: 'crop', name: 'Crop Tool', shortcut: 'C', icon: <Crop className="w-4 h-4" /> },
    { id: 'eyedropper', name: 'Eyedropper Tool', shortcut: 'I', icon: <Pipette className="w-4 h-4" /> },
    {
      id: 'spotHealing',
      name: 'Spot Healing Brush',
      shortcut: 'J',
      icon: <Bandage className="w-4 h-4" />,
      group: ['spotHealing', 'healingBrush'],
    },
    { id: 'cloneStamp', name: 'Clone Stamp Tool', shortcut: 'S', icon: <Stamp className="w-4 h-4" /> },
    {
      id: 'brush',
      name: 'Brush Tool',
      shortcut: 'B',
      icon: <Brush className="w-4 h-4" />,
      group: ['brush', 'pencil'],
    },
    {
      id: 'eraser',
      name: 'Eraser Tool',
      shortcut: 'E',
      icon: <Eraser className="w-4 h-4" />,
      group: ['eraser', 'magicEraser'],
    },
    {
      id: 'bucket',
      name: 'Paint Bucket Tool',
      shortcut: 'G',
      icon: <PaintBucket className="w-4 h-4" />,
      group: ['bucket', 'gradient'],
    },
    {
      id: 'blur',
      name: 'Blur Tool',
      shortcut: 'R',
      icon: <Droplet className="w-4 h-4" />,
      group: ['blur', 'sharpen', 'smudge'],
    },
    {
      id: 'dodge',
      name: 'Dodge Tool',
      shortcut: 'O',
      icon: <Sun className="w-4 h-4" />,
      group: ['dodge', 'burn', 'sponge'],
    },
    { id: 'pen', name: 'Pen Tool', shortcut: 'P', icon: <Pen className="w-4 h-4" /> },
    { id: 'textHorizontal', name: 'Horizontal Type Tool', shortcut: 'T', icon: <Type className="w-4 h-4" /> },
    {
      id: 'shapeRect',
      name: 'Rectangle Tool',
      shortcut: 'U',
      icon: <Square className="w-4 h-4 stroke-[2.5]" />,
      group: ['shapeRect', 'shapeRoundedRect', 'shapeEllipse', 'shapePolygon', 'shapeLine'],
    },
    { id: 'hand', name: 'Hand Tool', shortcut: 'H', icon: <Hand className="w-4 h-4" /> },
    { id: 'zoom', name: 'Zoom Tool', shortcut: 'Z', icon: <ZoomIn className="w-4 h-4" /> },
  ];

  return (
    <div className="w-12 bg-[#202024] border-r border-[#2e2e32] flex flex-col items-center py-2 select-none z-30 shrink-0">
      {/* Tool Buttons Grid */}
      <div className="flex flex-col gap-1 w-full items-center">
        {tools.map((tool) => {
          const isSelected = activeTool === tool.id || (tool.group && tool.group.includes(activeTool));

          return (
            <div key={tool.id} className="relative group">
              <button
                onClick={() => {
                  onSelectTool(tool.id);
                  setActiveFlyout(null);
                }}
                onContextMenu={(e) => {
                  e.preventDefault();
                  if (tool.group) {
                    setActiveFlyout(activeFlyout === tool.id ? null : tool.id);
                  }
                }}
                className={`w-8 h-8 rounded flex items-center justify-center relative transition-colors cursor-pointer ${
                  isSelected
                    ? 'bg-[#3b82f6] text-white shadow-sm'
                    : 'text-neutral-400 hover:bg-[#2c2c31] hover:text-neutral-100'
                }`}
                title={`${tool.name} (${tool.shortcut}) — Right click for alternatives`}
              >
                {tool.icon}
                {/* Tiny corner arrow indicating tool group flyout */}
                {tool.group && (
                  <span className="absolute bottom-0.5 right-0.5 w-0 h-0 border-l-[3.5px] border-l-transparent border-b-[3.5px] border-b-neutral-400 group-hover:border-b-white" />
                )}
              </button>

              {/* Flyout Submenu for tool groups */}
              {tool.group && activeFlyout === tool.id && (
                <div
                  className="absolute left-full top-0 ml-1 bg-[#26262b] border border-[#38383f] rounded shadow-2xl py-1 z-50 text-neutral-200 w-44"
                  onMouseLeave={() => setActiveFlyout(null)}
                >
                  {tool.group.map((subId) => (
                    <button
                      key={subId}
                      onClick={() => {
                        onSelectTool(subId);
                        setActiveFlyout(null);
                      }}
                      className={`w-full text-left px-3 py-1.5 text-xs flex items-center justify-between hover:bg-sky-600 hover:text-white capitalize ${
                        activeTool === subId ? 'text-sky-400 font-semibold' : ''
                      }`}
                    >
                      <span>{subId.replace(/([A-Z])/g, ' $1')}</span>
                      {activeTool === subId && <span>✓</span>}
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="flex-1" />

      {/* Photoshop Color Chips Swatch (Foreground / Background) */}
      <div className="relative w-8 h-8 mb-4 mt-2">
        {/* Reset colors button (D) */}
        <button
          onClick={onResetColors}
          className="absolute -top-3.5 -left-1 text-[9px] font-mono text-neutral-400 hover:text-white cursor-pointer"
          title="Reset Colors to Black & White (D)"
        >
          ■□
        </button>

        {/* Swap colors button (X) */}
        <button
          onClick={onSwapColors}
          className="absolute -top-3.5 -right-1 text-neutral-400 hover:text-white cursor-pointer"
          title="Swap Foreground and Background (X)"
        >
          <ArrowRightLeft className="w-3 h-3" />
        </button>

        {/* Background Color Chip */}
        <div
          className="absolute bottom-0 right-0 w-5 h-5 rounded-xs border border-[#3f3f46] shadow-xs cursor-pointer z-0 overflow-hidden"
          title="Background Color (Click to change)"
        >
          <input
            type="color"
            value={backgroundColor}
            onChange={(e) => onChangeBackgroundColor(e.target.value)}
            className="w-8 h-8 -top-1.5 -left-1.5 absolute cursor-pointer opacity-0"
          />
          <div className="w-full h-full" style={{ backgroundColor }} />
        </div>

        {/* Foreground Color Chip */}
        <div
          className="absolute top-0 left-0 w-5 h-5 rounded-xs border border-white/60 shadow-md cursor-pointer z-10 overflow-hidden"
          title="Foreground Color (Click to change)"
        >
          <input
            type="color"
            value={foregroundColor}
            onChange={(e) => onChangeForegroundColor(e.target.value)}
            className="w-8 h-8 -top-1.5 -left-1.5 absolute cursor-pointer opacity-0"
          />
          <div className="w-full h-full" style={{ backgroundColor: foregroundColor }} />
        </div>
      </div>
    </div>
  );
};
