/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  FileText,
  FolderOpen,
  Save,
  Download,
  RotateCcw,
  RotateCw,
  Maximize2,
  Sliders,
  Sparkles,
  HelpCircle,
  CheckCircle2,
  Package,
  Layers,
  Eye,
  Scissors,
  Copy,
  FlipHorizontal,
  FlipVertical,
} from 'lucide-react';
import { ActiveModal } from '../../types';

interface HeaderMenuProps {
  onOpenModal: (modal: ActiveModal) => void;
  onUndo: () => void;
  onRedo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  onTriggerFilter: (filterType: string) => void;
  onTriggerAdjustment: (adjType: string) => void;
  onNewLayer: () => void;
  onDuplicateLayer: () => void;
  onDeleteLayer: () => void;
  onMergeDown: () => void;
  onFlattenImage: () => void;
  onSelectAll: () => void;
  onDeselect: () => void;
  onInverseSelection: () => void;
  onRotateCanvas: (deg: number) => void;
  onFlipCanvas: (dir: 'h' | 'v') => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onZoomFit: () => void;
  onZoomActual: () => void;
  onToggleRulers: () => void;
  onToggleGrid: () => void;
  rulersVisible: boolean;
  gridVisible: boolean;
  activePanel: string;
  onTogglePanel: (panelName: string) => void;
  documentName: string;
  zoom: number;
}

export const HeaderMenu: React.FC<HeaderMenuProps> = ({
  onOpenModal,
  onUndo,
  onRedo,
  canUndo,
  canRedo,
  onTriggerFilter,
  onTriggerAdjustment,
  onNewLayer,
  onDuplicateLayer,
  onDeleteLayer,
  onMergeDown,
  onFlattenImage,
  onSelectAll,
  onDeselect,
  onInverseSelection,
  onRotateCanvas,
  onFlipCanvas,
  onZoomIn,
  onZoomOut,
  onZoomFit,
  onZoomActual,
  onToggleRulers,
  onToggleGrid,
  rulersVisible,
  gridVisible,
  activePanel,
  onTogglePanel,
  documentName,
  zoom,
}) => {
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [activeSubmenu, setActiveSubmenu] = useState<string | null>(null);
  const menuBarRef = useRef<HTMLDivElement>(null);

  // Close menus on click outside
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (menuBarRef.current && !menuBarRef.current.contains(e.target as Node)) {
        setActiveMenu(null);
        setActiveSubmenu(null);
      }
    }
    window.addEventListener('mousedown', handleClickOutside);
    return () => window.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleMenuClick = (name: string) => {
    setActiveMenu(activeMenu === name ? null : name);
    setActiveSubmenu(null);
  };

  const handleMenuHover = (name: string) => {
    if (activeMenu !== null) {
      setActiveMenu(name);
      setActiveSubmenu(null);
    }
  };

  const closeMenus = () => {
    setActiveMenu(null);
    setActiveSubmenu(null);
  };

  return (
    <div
      ref={menuBarRef}
      className="h-9 bg-[#202023] border-b border-[#2e2e32] flex items-center justify-between px-3 text-xs select-none z-50 text-neutral-300 font-sans"
    >
      {/* Left: Brand + Menus */}
      <div className="flex items-center gap-1">
        {/* Brand Lockup */}
        <div className="flex items-center gap-1.5 pr-3 mr-1 border-r border-[#333338] font-bold text-sky-400 tracking-wider">
          <div className="w-5 h-5 rounded bg-sky-500/20 border border-sky-400/40 flex items-center justify-center text-[10px] text-sky-300 font-black">
            Px
          </div>
          <span className="text-neutral-100">PIXORA</span>
        </div>

        {/* File Menu */}
        <div className="relative">
          <button
            onClick={() => handleMenuClick('file')}
            onMouseEnter={() => handleMenuHover('file')}
            className={`px-2.5 py-1 rounded hover:bg-[#2d2d32] ${
              activeMenu === 'file' ? 'bg-[#2d2d32] text-white' : ''
            }`}
          >
            File
          </button>
          {activeMenu === 'file' && (
            <div className="absolute left-0 top-full mt-0.5 w-56 bg-[#26262b] border border-[#38383f] rounded shadow-2xl py-1 z-50 text-neutral-200">
              <button
                onClick={() => {
                  onOpenModal('newDoc');
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>New Document...</span>
                <span className="text-[10px] text-neutral-400">Ctrl+N</span>
              </button>
              <button
                onClick={() => {
                  onOpenModal('openImage');
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>Open Image...</span>
                <span className="text-[10px] text-neutral-400">Ctrl+O</span>
              </button>
              <div className="h-px bg-[#38383f] my-1" />
              <button
                onClick={() => {
                  onOpenModal('export');
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>Export As (PNG/JPG/WebP)...</span>
                <span className="text-[10px] text-neutral-400">Ctrl+Shift+E</span>
              </button>
              <button
                onClick={() => {
                  onOpenModal('projectZip');
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 text-sky-400 hover:bg-sky-600 hover:text-white font-medium"
              >
                <span>Download Complete Project ZIP</span>
                <Package className="w-3.5 h-3.5" />
              </button>
              <div className="h-px bg-[#38383f] my-1" />
              <button
                onClick={() => {
                  onOpenModal('imageSize');
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>Document Properties...</span>
              </button>
            </div>
          )}
        </div>

        {/* Edit Menu */}
        <div className="relative">
          <button
            onClick={() => handleMenuClick('edit')}
            onMouseEnter={() => handleMenuHover('edit')}
            className={`px-2.5 py-1 rounded hover:bg-[#2d2d32] ${
              activeMenu === 'edit' ? 'bg-[#2d2d32] text-white' : ''
            }`}
          >
            Edit
          </button>
          {activeMenu === 'edit' && (
            <div className="absolute left-0 top-full mt-0.5 w-56 bg-[#26262b] border border-[#38383f] rounded shadow-2xl py-1 z-50 text-neutral-200">
              <button
                disabled={!canUndo}
                onClick={() => {
                  onUndo();
                  closeMenus();
                }}
                className={`w-full flex items-center justify-between px-3 py-1.5 ${
                  canUndo ? 'hover:bg-sky-600 hover:text-white' : 'opacity-40 cursor-not-allowed'
                }`}
              >
                <span>Undo</span>
                <span className="text-[10px] text-neutral-400">Ctrl+Z</span>
              </button>
              <button
                disabled={!canRedo}
                onClick={() => {
                  onRedo();
                  closeMenus();
                }}
                className={`w-full flex items-center justify-between px-3 py-1.5 ${
                  canRedo ? 'hover:bg-sky-600 hover:text-white' : 'opacity-40 cursor-not-allowed'
                }`}
              >
                <span>Redo</span>
                <span className="text-[10px] text-neutral-400">Ctrl+Shift+Z</span>
              </button>
              <div className="h-px bg-[#38383f] my-1" />
              <button
                onClick={() => {
                  onOpenModal('layerStyles');
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>Layer Styles (fx)...</span>
              </button>
              <button
                onClick={() => {
                  onOpenModal('gradientEditor');
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>Gradient Preset Editor...</span>
              </button>
            </div>
          )}
        </div>

        {/* Image Menu */}
        <div className="relative">
          <button
            onClick={() => handleMenuClick('image')}
            onMouseEnter={() => handleMenuHover('image')}
            className={`px-2.5 py-1 rounded hover:bg-[#2d2d32] ${
              activeMenu === 'image' ? 'bg-[#2d2d32] text-white' : ''
            }`}
          >
            Image
          </button>
          {activeMenu === 'image' && (
            <div className="absolute left-0 top-full mt-0.5 w-60 bg-[#26262b] border border-[#38383f] rounded shadow-2xl py-1 z-50 text-neutral-200">
              <div
                className="relative group"
                onMouseEnter={() => setActiveSubmenu('adjustments')}
              >
                <div className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white cursor-pointer">
                  <span>Adjustments</span>
                  <span className="text-neutral-400">▸</span>
                </div>
                {activeSubmenu === 'adjustments' && (
                  <div className="absolute left-full top-0 w-52 bg-[#26262b] border border-[#38383f] rounded shadow-2xl py-1 text-neutral-200">
                    <button
                      onClick={() => {
                        onTriggerAdjustment('brightnessContrast');
                        closeMenus();
                      }}
                      className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
                    >
                      Brightness / Contrast...
                    </button>
                    <button
                      onClick={() => {
                        onTriggerAdjustment('levels');
                        closeMenus();
                      }}
                      className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
                    >
                      Levels (Histogram)...
                    </button>
                    <button
                      onClick={() => {
                        onTriggerAdjustment('curves');
                        closeMenus();
                      }}
                      className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
                    >
                      Curves (Spline)...
                    </button>
                    <button
                      onClick={() => {
                        onTriggerAdjustment('hueSaturation');
                        closeMenus();
                      }}
                      className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
                    >
                      Hue / Saturation...
                    </button>
                    <button
                      onClick={() => {
                        onTriggerAdjustment('vibrance');
                        closeMenus();
                      }}
                      className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
                    >
                      Vibrance...
                    </button>
                    <button
                      onClick={() => {
                        onTriggerAdjustment('colorBalance');
                        closeMenus();
                      }}
                      className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
                    >
                      Color Balance...
                    </button>
                    <button
                      onClick={() => {
                        onTriggerAdjustment('temperatureTint');
                        closeMenus();
                      }}
                      className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
                    >
                      Temperature &amp; Tint...
                    </button>
                    <div className="h-px bg-[#38383f] my-1" />
                    <button
                      onClick={() => {
                        onTriggerAdjustment('blackAndWhite');
                        closeMenus();
                      }}
                      className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
                    >
                      Black &amp; White
                    </button>
                    <button
                      onClick={() => {
                        onTriggerAdjustment('invert');
                        closeMenus();
                      }}
                      className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
                    >
                      Invert
                    </button>
                    <button
                      onClick={() => {
                        onTriggerAdjustment('threshold');
                        closeMenus();
                      }}
                      className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
                    >
                      Threshold...
                    </button>
                    <button
                      onClick={() => {
                        onTriggerAdjustment('posterize');
                        closeMenus();
                      }}
                      className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
                    >
                      Posterize...
                    </button>
                    <button
                      onClick={() => {
                        onTriggerAdjustment('photoFilter');
                        closeMenus();
                      }}
                      className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
                    >
                      Photo Filter...
                    </button>
                  </div>
                )}
              </div>
              <div className="h-px bg-[#38383f] my-1" />
              <button
                onClick={() => {
                  onRotateCanvas(90);
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>Rotate Canvas 90° Clockwise</span>
                <RotateCw className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => {
                  onRotateCanvas(-90);
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>Rotate Canvas 90° Counter-CW</span>
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => {
                  onRotateCanvas(180);
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>Rotate Canvas 180°</span>
              </button>
              <button
                onClick={() => {
                  onFlipCanvas('h');
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>Flip Canvas Horizontal</span>
                <FlipHorizontal className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => {
                  onFlipCanvas('v');
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>Flip Canvas Vertical</span>
                <FlipVertical className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>

        {/* Layer Menu */}
        <div className="relative">
          <button
            onClick={() => handleMenuClick('layer')}
            onMouseEnter={() => handleMenuHover('layer')}
            className={`px-2.5 py-1 rounded hover:bg-[#2d2d32] ${
              activeMenu === 'layer' ? 'bg-[#2d2d32] text-white' : ''
            }`}
          >
            Layer
          </button>
          {activeMenu === 'layer' && (
            <div className="absolute left-0 top-full mt-0.5 w-56 bg-[#26262b] border border-[#38383f] rounded shadow-2xl py-1 z-50 text-neutral-200">
              <button
                onClick={() => {
                  onNewLayer();
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>New Layer</span>
                <span className="text-[10px] text-neutral-400">Ctrl+Shift+N</span>
              </button>
              <button
                onClick={() => {
                  onDuplicateLayer();
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>Duplicate Layer</span>
                <span className="text-[10px] text-neutral-400">Ctrl+J</span>
              </button>
              <button
                onClick={() => {
                  onDeleteLayer();
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>Delete Layer</span>
                <span className="text-[10px] text-neutral-400">Delete</span>
              </button>
              <div className="h-px bg-[#38383f] my-1" />
              <button
                onClick={() => {
                  onMergeDown();
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>Merge Down</span>
                <span className="text-[10px] text-neutral-400">Ctrl+E</span>
              </button>
              <button
                onClick={() => {
                  onFlattenImage();
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>Flatten Image</span>
              </button>
            </div>
          )}
        </div>

        {/* Select Menu */}
        <div className="relative">
          <button
            onClick={() => handleMenuClick('select')}
            onMouseEnter={() => handleMenuHover('select')}
            className={`px-2.5 py-1 rounded hover:bg-[#2d2d32] ${
              activeMenu === 'select' ? 'bg-[#2d2d32] text-white' : ''
            }`}
          >
            Select
          </button>
          {activeMenu === 'select' && (
            <div className="absolute left-0 top-full mt-0.5 w-56 bg-[#26262b] border border-[#38383f] rounded shadow-2xl py-1 z-50 text-neutral-200">
              <button
                onClick={() => {
                  onSelectAll();
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>Select All</span>
                <span className="text-[10px] text-neutral-400">Ctrl+A</span>
              </button>
              <button
                onClick={() => {
                  onDeselect();
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>Deselect</span>
                <span className="text-[10px] text-neutral-400">Ctrl+D</span>
              </button>
              <button
                onClick={() => {
                  onInverseSelection();
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>Inverse Selection</span>
                <span className="text-[10px] text-neutral-400">Ctrl+Shift+I</span>
              </button>
            </div>
          )}
        </div>

        {/* Filter Menu */}
        <div className="relative">
          <button
            onClick={() => handleMenuClick('filter')}
            onMouseEnter={() => handleMenuHover('filter')}
            className={`px-2.5 py-1 rounded hover:bg-[#2d2d32] ${
              activeMenu === 'filter' ? 'bg-[#2d2d32] text-white' : ''
            }`}
          >
            Filter
          </button>
          {activeMenu === 'filter' && (
            <div className="absolute left-0 top-full mt-0.5 w-56 bg-[#26262b] border border-[#38383f] rounded shadow-2xl py-1 z-50 text-neutral-200">
              <button
                onClick={() => {
                  onOpenModal('filters');
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 text-sky-400 font-medium hover:bg-sky-600 hover:text-white"
              >
                <span>Filter Gallery...</span>
                <Sparkles className="w-3.5 h-3.5" />
              </button>
              <div className="h-px bg-[#38383f] my-1" />
              <button
                onClick={() => {
                  onTriggerFilter('gaussianBlur');
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                Gaussian Blur...
              </button>
              <button
                onClick={() => {
                  onTriggerFilter('motionBlur');
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                Motion Blur...
              </button>
              <button
                onClick={() => {
                  onTriggerFilter('radialBlur');
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                Radial Blur...
              </button>
              <button
                onClick={() => {
                  onTriggerFilter('unsharpMask');
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                Unsharp Mask (Sharpen)...
              </button>
              <button
                onClick={() => {
                  onTriggerFilter('highPass');
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                High Pass...
              </button>
              <button
                onClick={() => {
                  onTriggerFilter('addNoise');
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                Add Noise...
              </button>
              <button
                onClick={() => {
                  onTriggerFilter('twirl');
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                Twirl Distortion...
              </button>
              <button
                onClick={() => {
                  onTriggerFilter('ripple');
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                Ripple Distortion...
              </button>
              <button
                onClick={() => {
                  onTriggerFilter('mosaic');
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                Mosaic Pixelation...
              </button>
              <button
                onClick={() => {
                  onTriggerFilter('emboss');
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                Emboss Stylize...
              </button>
              <button
                onClick={() => {
                  onTriggerFilter('findEdges');
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                Find Edges...
              </button>
              <button
                onClick={() => {
                  onTriggerFilter('clouds');
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                Render Procedural Clouds
              </button>
              <button
                onClick={() => {
                  onTriggerFilter('lensFlare');
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                Render Lens Flare...
              </button>
            </div>
          )}
        </div>

        {/* View Menu */}
        <div className="relative">
          <button
            onClick={() => handleMenuClick('view')}
            onMouseEnter={() => handleMenuHover('view')}
            className={`px-2.5 py-1 rounded hover:bg-[#2d2d32] ${
              activeMenu === 'view' ? 'bg-[#2d2d32] text-white' : ''
            }`}
          >
            View
          </button>
          {activeMenu === 'view' && (
            <div className="absolute left-0 top-full mt-0.5 w-56 bg-[#26262b] border border-[#38383f] rounded shadow-2xl py-1 z-50 text-neutral-200">
              <button
                onClick={() => {
                  onZoomIn();
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>Zoom In</span>
                <span className="text-[10px] text-neutral-400">Ctrl++</span>
              </button>
              <button
                onClick={() => {
                  onZoomOut();
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>Zoom Out</span>
                <span className="text-[10px] text-neutral-400">Ctrl+-</span>
              </button>
              <button
                onClick={() => {
                  onZoomFit();
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>Fit on Screen</span>
                <span className="text-[10px] text-neutral-400">Ctrl+0</span>
              </button>
              <button
                onClick={() => {
                  onZoomActual();
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>100% Actual Pixels</span>
                <span className="text-[10px] text-neutral-400">Ctrl+1</span>
              </button>
              <div className="h-px bg-[#38383f] my-1" />
              <button
                onClick={() => {
                  onToggleRulers();
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>{rulersVisible ? '✓ Hide Rulers' : 'Show Rulers'}</span>
                <span className="text-[10px] text-neutral-400">Ctrl+R</span>
              </button>
              <button
                onClick={() => {
                  onToggleGrid();
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>{gridVisible ? '✓ Hide Grid' : 'Show Grid'}</span>
                <span className="text-[10px] text-neutral-400">Ctrl+'</span>
              </button>
            </div>
          )}
        </div>

        {/* Window Menu */}
        <div className="relative">
          <button
            onClick={() => handleMenuClick('window')}
            onMouseEnter={() => handleMenuHover('window')}
            className={`px-2.5 py-1 rounded hover:bg-[#2d2d32] ${
              activeMenu === 'window' ? 'bg-[#2d2d32] text-white' : ''
            }`}
          >
            Window
          </button>
          {activeMenu === 'window' && (
            <div className="absolute left-0 top-full mt-0.5 w-52 bg-[#26262b] border border-[#38383f] rounded shadow-2xl py-1 z-50 text-neutral-200">
              {['layers', 'properties', 'history', 'channels', 'color', 'navigator', 'timeline'].map(
                (p) => (
                  <button
                    key={p}
                    onClick={() => {
                      onTogglePanel(p);
                      closeMenus();
                    }}
                    className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white capitalize"
                  >
                    <span>{p}</span>
                    {activePanel === p && <span className="text-sky-400">✓</span>}
                  </button>
                )
              )}
            </div>
          )}
        </div>

        {/* Help Menu */}
        <div className="relative">
          <button
            onClick={() => handleMenuClick('help')}
            onMouseEnter={() => handleMenuHover('help')}
            className={`px-2.5 py-1 rounded hover:bg-[#2d2d32] ${
              activeMenu === 'help' ? 'bg-[#2d2d32] text-white' : ''
            }`}
          >
            Help
          </button>
          {activeMenu === 'help' && (
            <div className="absolute left-0 top-full mt-0.5 w-56 bg-[#26262b] border border-[#38383f] rounded shadow-2xl py-1 z-50 text-neutral-200">
              <button
                onClick={() => {
                  onOpenModal('shortcuts');
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-sky-600 hover:text-white"
              >
                <span>Keyboard Shortcuts Reference</span>
              </button>
              <button
                onClick={() => {
                  onOpenModal('automatedTests');
                  closeMenus();
                }}
                className="w-full flex items-center justify-between px-3 py-1.5 text-emerald-400 hover:bg-sky-600 hover:text-white"
              >
                <span>Automated Test Suite Runner</span>
                <CheckCircle2 className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Right: Active Document tab indicator & Quick actions */}
      <div className="flex items-center gap-3 text-neutral-400 text-[11px]">
        <div className="flex items-center gap-2 px-2.5 py-1 bg-[#18181b] rounded border border-[#2e2e32] text-neutral-300 font-mono">
          <span>{documentName}</span>
          <span className="text-neutral-500">@</span>
          <span className="text-sky-400">{Math.round(zoom * 100)}%</span>
        </div>

        <button
          onClick={() => onOpenModal('automatedTests')}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-medium transition-colors cursor-pointer"
          title="Run Comprehensive Automated Tests"
        >
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>Tests</span>
        </button>

        <button
          onClick={() => onOpenModal('projectZip')}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-sky-500/10 hover:bg-sky-500/20 text-sky-400 border border-sky-500/30 font-medium transition-colors cursor-pointer"
          title="Download Complete Project ZIP Package"
        >
          <Package className="w-3.5 h-3.5" />
          <span>Download ZIP</span>
        </button>

        <button
          onClick={() => onOpenModal('export')}
          className="px-3 py-1 rounded bg-sky-500 hover:bg-sky-400 text-neutral-950 font-semibold transition-colors cursor-pointer"
        >
          Export
        </button>
      </div>
    </div>
  );
};
