/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  ToolType,
  ToolSettings,
  BlendMode,
  GradientType,
  ActiveModal,
} from '../../types';
import {
  Sliders,
  Check,
  X,
  Type,
  Square,
  Circle,
  Maximize2,
  Minimize2,
  Bold,
  Italic,
  Underline,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Crosshair,
  ChevronDown,
} from 'lucide-react';

interface OptionsBarProps {
  activeTool: ToolType;
  settings: ToolSettings;
  onUpdateSettings: (patch: Partial<ToolSettings>) => void;
  onApplyCrop: () => void;
  onCancelCrop: () => void;
  onOpenModal: (modal: ActiveModal) => void;
  // Active text layer styling if text tool is active
  activeTextData?: {
    fontFamily: string;
    fontSize: number;
    color: string;
    align: 'left' | 'center' | 'right';
    bold: boolean;
    italic: boolean;
    underline: boolean;
  };
  onUpdateTextData?: (patch: any) => void;
}

export const OptionsBar: React.FC<OptionsBarProps> = ({
  activeTool,
  settings,
  onUpdateSettings,
  onApplyCrop,
  onCancelCrop,
  onOpenModal,
  activeTextData,
  onUpdateTextData,
}) => {
  return (
    <div className="h-9 bg-[#242429] border-b border-[#2e2e32] flex items-center px-3 text-xs text-neutral-300 gap-4 overflow-x-auto select-none font-sans whitespace-nowrap">
      {/* Tool Icon & Name Label */}
      <div className="flex items-center gap-1.5 font-medium text-neutral-400 pr-2 border-r border-[#333338]">
        <span className="capitalize text-sky-400 font-semibold">{activeTool}</span>
      </div>

      {/* 1. BRUSH / PENCIL / ERASER / SMUDGE / HEALING OPTIONS */}
      {[
        'brush',
        'pencil',
        'eraser',
        'spotHealing',
        'healingBrush',
        'cloneStamp',
        'blur',
        'sharpen',
        'smudge',
        'dodge',
        'burn',
        'sponge',
      ].includes(activeTool) && (
        <div className="flex items-center gap-4">
          {/* Size */}
          <div className="flex items-center gap-2">
            <span className="text-neutral-400">Size:</span>
            <input
              type="range"
              min="1"
              max="200"
              value={settings.brushSize}
              onChange={(e) => onUpdateSettings({ brushSize: Number(e.target.value) })}
              className="w-20 cursor-pointer"
            />
            <span className="font-mono w-7 text-right text-neutral-200">{settings.brushSize}px</span>
          </div>

          {/* Hardness (for brush/eraser) */}
          {['brush', 'eraser', 'cloneStamp', 'healingBrush'].includes(activeTool) && (
            <div className="flex items-center gap-2">
              <span className="text-neutral-400">Hardness:</span>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={settings.brushHardness}
                onChange={(e) => onUpdateSettings({ brushHardness: Number(e.target.value) })}
                className="w-16 cursor-pointer"
              />
              <span className="font-mono w-8 text-right text-neutral-200">
                {Math.round(settings.brushHardness * 100)}%
              </span>
            </div>
          )}

          {/* Opacity */}
          <div className="flex items-center gap-2">
            <span className="text-neutral-400">Opacity:</span>
            <input
              type="range"
              min="0.05"
              max="1"
              step="0.05"
              value={settings.brushOpacity}
              onChange={(e) => onUpdateSettings({ brushOpacity: Number(e.target.value) })}
              className="w-16 cursor-pointer"
            />
            <span className="font-mono w-8 text-right text-neutral-200">
              {Math.round(settings.brushOpacity * 100)}%
            </span>
          </div>

          {/* Flow */}
          {['brush', 'airbrush'].includes(activeTool) && (
            <div className="flex items-center gap-2">
              <span className="text-neutral-400">Flow:</span>
              <input
                type="range"
                min="0.05"
                max="1"
                step="0.05"
                value={settings.brushFlow}
                onChange={(e) => onUpdateSettings({ brushFlow: Number(e.target.value) })}
                className="w-16 cursor-pointer"
              />
              <span className="font-mono w-8 text-right text-neutral-200">
                {Math.round(settings.brushFlow * 100)}%
              </span>
            </div>
          )}

          {/* Clone Stamp Status */}
          {activeTool === 'cloneStamp' && (
            <div className="flex items-center gap-2 px-2 py-0.5 rounded bg-[#1c1c20] border border-[#38383f] text-neutral-300">
              <Crosshair className="w-3.5 h-3.5 text-sky-400" />
              <span>
                {settings.cloneSource
                  ? `Source: (${Math.round(settings.cloneSource.x)}, ${Math.round(settings.cloneSource.y)})`
                  : 'Alt+Click canvas to set source'}
              </span>
            </div>
          )}

          {/* Dodge / Burn Exposure */}
          {['dodge', 'burn'].includes(activeTool) && (
            <div className="flex items-center gap-2">
              <span className="text-neutral-400">Exposure:</span>
              <input
                type="range"
                min="0.05"
                max="1"
                step="0.05"
                value={settings.retouchExposure}
                onChange={(e) => onUpdateSettings({ retouchExposure: Number(e.target.value) })}
                className="w-16 cursor-pointer"
              />
              <span className="font-mono w-8 text-right text-neutral-200">
                {Math.round(settings.retouchExposure * 100)}%
              </span>
            </div>
          )}
        </div>
      )}

      {/* 2. SELECTION TOOLS OPTIONS */}
      {[
        'rectMarquee',
        'ellipseMarquee',
        'lasso',
        'polygonalLasso',
        'magicWand',
        'quickSelect',
      ].includes(activeTool) && (
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-neutral-400">Feather:</span>
            <input
              type="number"
              min="0"
              max="50"
              value={settings.feather}
              onChange={(e) => onUpdateSettings({ feather: Number(e.target.value) })}
              className="w-12 px-1.5 py-0.5 bg-[#1a1a1e] border border-[#38383f] rounded font-mono text-center text-neutral-200"
            />
            <span className="text-neutral-400">px</span>
          </div>

          {activeTool === 'magicWand' && (
            <>
              <div className="flex items-center gap-2">
                <span className="text-neutral-400">Tolerance:</span>
                <input
                  type="number"
                  min="0"
                  max="255"
                  value={settings.tolerance}
                  onChange={(e) => onUpdateSettings({ tolerance: Number(e.target.value) })}
                  className="w-12 px-1.5 py-0.5 bg-[#1a1a1e] border border-[#38383f] rounded font-mono text-center text-neutral-200"
                />
              </div>

              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.contiguous}
                  onChange={(e) => onUpdateSettings({ contiguous: e.target.checked })}
                  className="rounded border-[#38383f] bg-[#1a1a1e] text-sky-500 focus:ring-0"
                />
                <span>Contiguous</span>
              </label>
            </>
          )}
        </div>
      )}

      {/* 3. PAINT BUCKET OPTIONS */}
      {activeTool === 'bucket' && (
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-neutral-400">Tolerance:</span>
            <input
              type="number"
              min="0"
              max="255"
              value={settings.tolerance}
              onChange={(e) => onUpdateSettings({ tolerance: Number(e.target.value) })}
              className="w-12 px-1.5 py-0.5 bg-[#1a1a1e] border border-[#38383f] rounded font-mono text-center text-neutral-200"
            />
          </div>

          <label className="flex items-center gap-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={settings.contiguous}
              onChange={(e) => onUpdateSettings({ contiguous: e.target.checked })}
              className="rounded border-[#38383f] bg-[#1a1a1e] text-sky-500 focus:ring-0"
            />
            <span>Contiguous</span>
          </label>
        </div>
      )}

      {/* 4. GRADIENT TOOL OPTIONS */}
      {activeTool === 'gradient' && (
        <div className="flex items-center gap-4">
          <button
            onClick={() => onOpenModal('gradientEditor')}
            className="flex items-center gap-2 px-2.5 py-1 bg-[#1c1c20] hover:bg-[#28282e] border border-[#38383f] rounded cursor-pointer"
          >
            <div
              className="w-16 h-4 rounded border border-neutral-700"
              style={{
                background: `linear-gradient(to right, ${settings.gradient.colorStops
                  .map((s) => `${s.color} ${s.offset * 100}%`)
                  .join(', ')})`,
              }}
            />
            <ChevronDown className="w-3.5 h-3.5 text-neutral-400" />
          </button>

          <div className="flex items-center gap-1 bg-[#1a1a1e] p-0.5 rounded border border-[#38383f]">
            {(['linear', 'radial', 'angle', 'reflected', 'diamond'] as GradientType[]).map((type) => (
              <button
                key={type}
                onClick={() =>
                  onUpdateSettings({
                    gradient: { ...settings.gradient, type },
                  })
                }
                className={`px-2 py-0.5 rounded capitalize text-[11px] ${
                  settings.gradient.type === type ? 'bg-sky-500 text-neutral-950 font-semibold' : 'hover:text-white'
                }`}
              >
                {type}
              </button>
            ))}
          </div>

          <label className="flex items-center gap-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={settings.gradient.reverse}
              onChange={(e) =>
                onUpdateSettings({
                  gradient: { ...settings.gradient, reverse: e.target.checked },
                })
              }
              className="rounded border-[#38383f] bg-[#1a1a1e] text-sky-500 focus:ring-0"
            />
            <span>Reverse</span>
          </label>
        </div>
      )}

      {/* 5. CROP TOOL OPTIONS */}
      {activeTool === 'crop' && (
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-neutral-400">Ratio:</span>
            <select
              value={settings.cropPreset}
              onChange={(e) => onUpdateSettings({ cropPreset: e.target.value })}
              className="bg-[#1a1a1e] border border-[#38383f] rounded px-2 py-0.5 text-neutral-200 outline-none"
            >
              <option value="free">Free Form</option>
              <option value="1:1">1:1 Square</option>
              <option value="16:9">16:9 Landscape</option>
              <option value="4:3">4:3 Standard</option>
              <option value="9:16">9:16 Mobile</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onApplyCrop}
              className="flex items-center gap-1 px-3 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-medium cursor-pointer"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Apply</span>
            </button>
            <button
              onClick={onCancelCrop}
              className="flex items-center gap-1 px-3 py-1 rounded bg-neutral-700 hover:bg-neutral-600 text-white cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
              <span>Cancel</span>
            </button>
          </div>
        </div>
      )}

      {/* 6. TEXT TOOL OPTIONS */}
      {['textHorizontal', 'textVertical'].includes(activeTool) && (
        <div className="flex items-center gap-3">
          {/* Font Family */}
          <select
            value={activeTextData?.fontFamily || 'Plus Jakarta Sans'}
            onChange={(e) => onUpdateTextData?.({ fontFamily: e.target.value })}
            className="bg-[#1a1a1e] border border-[#38383f] rounded px-2 py-0.5 text-neutral-200 outline-none max-w-[140px]"
          >
            <option value="Plus Jakarta Sans">Plus Jakarta Sans</option>
            <option value="JetBrains Mono">JetBrains Mono</option>
            <option value="Arial">Arial</option>
            <option value="Georgia">Georgia</option>
            <option value="Impact">Impact</option>
            <option value="Times New Roman">Times New Roman</option>
            <option value="Courier New">Courier New</option>
          </select>

          {/* Font Size */}
          <div className="flex items-center gap-1">
            <span className="text-neutral-400">Size:</span>
            <input
              type="number"
              min="8"
              max="200"
              value={activeTextData?.fontSize || 36}
              onChange={(e) => onUpdateTextData?.({ fontSize: Number(e.target.value) })}
              className="w-14 px-1.5 py-0.5 bg-[#1a1a1e] border border-[#38383f] rounded font-mono text-center text-neutral-200"
            />
            <span className="text-neutral-400">pt</span>
          </div>

          {/* Styling buttons */}
          <div className="flex items-center gap-1 bg-[#1a1a1e] p-0.5 rounded border border-[#38383f]">
            <button
              onClick={() => onUpdateTextData?.({ bold: !activeTextData?.bold })}
              className={`p-1 rounded ${activeTextData?.bold ? 'bg-sky-500 text-neutral-950' : 'hover:text-white'}`}
            >
              <Bold className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onUpdateTextData?.({ italic: !activeTextData?.italic })}
              className={`p-1 rounded ${activeTextData?.italic ? 'bg-sky-500 text-neutral-950' : 'hover:text-white'}`}
            >
              <Italic className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onUpdateTextData?.({ underline: !activeTextData?.underline })}
              className={`p-1 rounded ${activeTextData?.underline ? 'bg-sky-500 text-neutral-950' : 'hover:text-white'}`}
            >
              <Underline className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Align */}
          <div className="flex items-center gap-1 bg-[#1a1a1e] p-0.5 rounded border border-[#38383f]">
            <button
              onClick={() => onUpdateTextData?.({ align: 'left' })}
              className={`p-1 rounded ${activeTextData?.align === 'left' ? 'bg-sky-500 text-neutral-950' : 'hover:text-white'}`}
            >
              <AlignLeft className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onUpdateTextData?.({ align: 'center' })}
              className={`p-1 rounded ${activeTextData?.align === 'center' ? 'bg-sky-500 text-neutral-950' : 'hover:text-white'}`}
            >
              <AlignCenter className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onUpdateTextData?.({ align: 'right' })}
              className={`p-1 rounded ${activeTextData?.align === 'right' ? 'bg-sky-500 text-neutral-950' : 'hover:text-white'}`}
            >
              <AlignRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Color */}
          <div className="flex items-center gap-1.5">
            <span className="text-neutral-400">Color:</span>
            <input
              type="color"
              value={activeTextData?.color || '#ffffff'}
              onChange={(e) => onUpdateTextData?.({ color: e.target.value })}
              className="w-6 h-6 rounded border border-[#38383f] cursor-pointer bg-transparent"
            />
          </div>
        </div>
      )}
    </div>
  );
};
